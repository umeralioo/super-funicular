// libshadowhook_nothing — required by ShadowHook's linker init.
// sh_linker.c:578-581 dlopens this exact name (RTLD_NOW) during
// sh_linker_hook_call_ctors_dtors() to run the soinfo offset scan.
// If it is missing from the APK, shadowhook_init fails with 12
// (INIT_LINKER) in EVERY mode. Keep this file empty; the .so just
// needs to exist in the app's lib dir.
__attribute__((visibility("default"))) void shadowhook_nothing_holder(void) {}
