LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE    := ffk_pro
LOCAL_SRC_FILES := ffk_pro.c \
                   bh/bh_array.c bh/bh_cfi.c bh/bh_dl.c bh/bh_dl_iterate.c \
                   bh/bh_dl_monitor.c bh/bh_elf.c bh/bh_elf_manager.c \
                   bh/bh_elf_relocator.c bh/bh_hub.c bh/bh_linker.c \
                   bh/bh_linker_mutex.c bh/bh_log.c bh/bh_recorder.c \
                   bh/bh_safe.c bh/bh_sleb128.c bh/bh_switch.c bh/bh_task.c \
                   bh/bh_task_manager.c bh/bh_trampo.c bh/bh_util.c bh/bytehook.c \
                   sh/arch/arm64/sh_a64.c sh/arch/arm64/sh_inst.c \
                   sh/arch/arm64/sh_glue.S sh/sh_elf.c sh/sh_enter.c \
                   sh/sh_hub.c sh/sh_island.c sh/sh_linker.c sh/sh_recorder.c \
                   sh/sh_safe.c sh/sh_switch.c sh/sh_task.c sh/sh_xdl.c \
                   sh/shadowhook.c sh/common/sh_errno.c sh/common/sh_log.c \
                   sh/common/sh_ref.c sh/common/sh_trampo.c sh/common/sh_util.c \
                   sh/common/bytesig.c \
                   sh/third_party/xdl/xdl.c sh/third_party/xdl/xdl_iterate.c \
                   sh/third_party/xdl/xdl_linker.c sh/third_party/xdl/xdl_lzma.c \
                   sh/third_party/xdl/xdl_util.c

LOCAL_C_INCLUDES := $(LOCAL_PATH)/bh/include \
                    $(LOCAL_PATH)/sh/include \
                    $(LOCAL_PATH)/sh/common \
                    $(LOCAL_PATH)/sh/third_party/xdl \
                    $(LOCAL_PATH)/bh/third_party/bsd \
                    $(LOCAL_PATH)/bh/third_party/lss \
                    $(LOCAL_PATH)/sh/third_party/bsd \
                    $(LOCAL_PATH)/sh/third_party/lss \
                    $(LOCAL_PATH)/sh \
                    $(LOCAL_PATH)/bh
                    

LOCAL_CFLAGS    := -O2 -Wall -Wextra -fvisibility=hidden \
                   -ffunction-sections -fdata-sections \
                   -DANDROID -DBH_CONFIG_STATIC

LOCAL_CPPFLAGS  := $(LOCAL_CFLAGS) -std=c++17

LOCAL_LDFLAGS   := -Wl,--gc-sections -Wl,--strip-all -latomic
LOCAL_LDLIBS    := -llog -ldl -lz

include $(BUILD_SHARED_LIBRARY)
