#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <android/log.h>
#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_android.h"

namespace {
static char g_lines[256][168];
static unsigned g_lens[256];
static unsigned g_w = 0;
static EGLBoolean (*g_oldSwap)(EGLDisplay, EGLSurface) = 0;
static int g_setup = 0;
static int g_arm = 0;
static int g_taken = 0;
}

extern "C" void ffkImguiPush(const char *s) {
    if (!s || !*s) return;
    unsigned k = __atomic_fetch_add(&g_w, 1, __ATOMIC_RELAXED) % 256;
    unsigned n = 0;
    while (n < 160 && s[n] && s[n] != '\n') {
        g_lines[k][n] = s[n];
        n++;
    }
    g_lines[k][n] = 0;
    g_lens[k] = n;
}

extern "C" void **ffkOldSwapAddr() { return (void **)&g_oldSwap; }

extern "C" void ffkShotArm() { __atomic_store_n(&g_arm, 1, __ATOMIC_RELAXED); }

static void ffkSetup(int w, int h) {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = NULL;
    io.LogFilename = NULL;
    io.DisplaySize = ImVec2((float)w, (float)h);
    ImGui::StyleColorsDark();
    ImGuiStyle &st = ImGui::GetStyle();
    st.WindowRounding = 0.0f;
    st.WindowBorderSize = 0.0f;
    ImGui_ImplOpenGL3_Init("#version 300 es");
    ImGui_ImplAndroid_Init(NULL);
}

extern "C" EGLBoolean ffkSwapBuffers(EGLDisplay dpy, EGLSurface surf) {
    int w = 0, h = 0;
    if (dpy && surf) {
        eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
        eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    }
    if (w > 0 && h > 0 && !g_setup) {
        g_setup = 1;
        ffkSetup(w, h);
    }
    if (g_setup && w > 0 && h > 0) {
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplAndroid_NewFrame(w, h);
        ImGui::NewFrame();
        ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2((float)w, (float)h * 0.38f), ImGuiCond_Always);
        ImGuiWindowFlags fl = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                              ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                              ImGuiWindowFlags_NoNav;
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0.72f));
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0, 1, 0, 1));
        if (ImGui::Begin("FFK", 0, fl)) {
            unsigned wcur = __atomic_load_n(&g_w, __ATOMIC_RELAXED);
            unsigned n = wcur > 120 ? 120 : wcur;
            unsigned start = wcur > n ? wcur - n : 0;
            for (unsigned i = start; i < wcur; i++) {
                unsigned k = i % 256;
                if (g_lens[k] == 0) continue;
                ImGui::TextUnformatted(g_lines[k]);
            }
            ImGui::SetScrollHereY(1.0f);
        }
        ImGui::End();
        ImGui::PopStyleColor(2);
        ImGui::EndFrame();
        ImGui::Render();
        ImGuiIO &io = ImGui::GetIO();
        glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    }
    if (__atomic_load_n(&g_arm, __ATOMIC_RELAXED) && w > 0 && h > 0 && w <= 4096 && h <= 4096) {
        __atomic_store_n(&g_arm, 0, __ATOMIC_RELAXED);
        if (g_taken < 4) {
            size_t sz = (size_t)w * (size_t)h * 4;
            unsigned char *px = (unsigned char *)malloc(sz);
            if (px) {
                glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px);
                extern void ffkSaveShot(const unsigned char *, int, int);
                ffkSaveShot(px, w, h);
                free(px);
                g_taken++;
            }
        }
    }
    {
        static unsigned sc = 0;
        unsigned c = ++sc;
        if (c <= 8 || c % 600 == 0) {
            int arm = __atomic_load_n(&g_arm, __ATOMIC_RELAXED);
            char b[128];
            snprintf(b, sizeof(b), "swapcall n=%u w=%d h=%d setup=%d arm=%d taken=%d", c, w, h, g_setup, arm, g_taken);
            __android_log_print(ANDROID_LOG_ERROR, "FFKX", "%s", b);
        }
    }
    if (g_oldSwap) return g_oldSwap(dpy, surf);
    return EGL_FALSE;
}
