#include <jni.h>
#include <android/log.h>
#include <string.h>
#include <stdio.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/ioctl.h>
#include <sys/un.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <signal.h>
#include <ucontext.h>
#if defined(__aarch64__)
_Static_assert(sizeof(((ucontext_t *)0)->uc_mcontext) >= 0x200, "arm64 sigcontext too small");
_Static_assert(sizeof(((ucontext_t *)0)->uc_mcontext.regs) == 31 * 8, "arm64 regs layout changed");
_Static_assert(sizeof(((ucontext_t *)0)->uc_mcontext.fault_address) == 8, "bionic fault_address layout changed");
#endif
#include <stdarg.h>
#include "bytehook.h"
#include "bh_elf.h"

#define TAG "FFKN"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static inline int mytid(void) {
    return (int)syscall(__NR_gettid);
}

static const char *apkPath__ = NULL;
static const char *repPath__ = NULL;

static void file_append(const char *line);
static void bh_poll_armed(void);
static void bh_late_newelf(void *elf, void *arg);
static struct { int tid; int id; } hk_[64];
static __thread int ffk_cur_hkid = 0;
static const char *hkNames[160] = {0};
static inline void hkEnter(int id) { int t = mytid(); unsigned k = ((unsigned)t) & 63; hk_[k].tid = t; hk_[k].id = id; ffk_cur_hkid = id; }
extern void bh_elf_manager_refresh(bool sync_clean, void (*cb)(void *, void *), void *arg);
extern void bh_task_hook_elf(void *task, void *elf);
extern void bh_elf_manager_iterate(void (*cb)(bh_elf_t *, void *), void *arg);
static void evlog(const char *s);
extern void ffkImguiPush(const char *s);
static void deathBt(char *out, size_t outn);
static void dumpAnogsFns(void);
void *(*old_dlsym)(void *, const char *);
int (*old_open)(const char *, int, mode_t);
ssize_t (*old_read)(int, void *, size_t);
ssize_t (*old_write)(int, const void *, size_t);
int (*old_close)(int);

static unsigned sockbits[32];
static unsigned sockcnt[1024];
static char sockpeer[1024][64];

static inline void trackAdd(int fd) {
    if (fd >= 0 && fd < 1024) sockbits[fd >> 5] |= 1u << (fd & 31);
}
static inline void trackDel(int fd) {
    if (fd >= 0 && fd < 1024) {
        sockbits[fd >> 5] &= ~(1u << (fd & 31));
        sockcnt[fd] = 0;
        sockpeer[fd][0] = 0;
    }
}
static inline int trackHas(int fd) {
    return fd >= 0 && fd < 1024 && ((sockbits[fd >> 5] >> (fd & 31)) & 1u);
}
static inline void trackPeer(int fd, const char *s) {
    if (fd >= 0 && fd < 1024 && s) {
        strncpy(sockpeer[fd], s, 63);
        sockpeer[fd][63] = 0;
    }
}
static inline unsigned trackBump(int fd) {
    if (fd < 0 || fd >= 1024) return 0;
    return __atomic_add_fetch(&sockcnt[fd], 1, __ATOMIC_RELAXED);
}

static void hex16(const unsigned char *p, long len, char *out) {
    static const char *h = "0123456789abcdef";
    long n = len > 16 ? 16 : len;
    for (long i = 0; i < n; i++) {
        out[i * 2] = h[p[i] >> 4];
        out[i * 2 + 1] = h[p[i] & 15];
    }
    out[n * 2] = 0;
}

static void dump_buf(const char *tag, const void *buf, size_t len);
static void dump_ioctl_report(const char *tag, int cmd, const void *buf, size_t max_dump) {
    if (!tag || !buf) return;

    size_t dump_len = 256;
    if (max_dump < dump_len) dump_len = max_dump;

    if (cmd == 0x46) {
        dump_len = max_dump > 1024 ? 1024 : max_dump;

        char mark[128];
        snprintf(mark, sizeof(mark), "IOCTL-X %s cmd=0x46 (report) EXTRA dump (%lu bytes)",
            tag, (unsigned long)dump_len);
        file_append(mark);
    }

    dump_buf(tag, buf, dump_len);
}
static int mem_readable(const void *p, size_t len) {
    unsigned long a = (unsigned long)p, e = a + len;
    if (!a || e < a || !len) return 0;
    for (unsigned long pg = a & ~0xFFFUL; pg < e; pg += 4096)
        if (msync((void *)pg, 4096, MS_ASYNC) != 0) return 0;
    return 1;
}

static int is_zero_fp(const unsigned char *fp, size_t n) {
    for (size_t i = 0; i < n; i++) {
        if (fp[i] != 0) return 0;
    }
    return 1;
}
static void modTag(unsigned long a, char *out, size_t outn);
static unsigned ror32ffk(unsigned v, int n) { return (v >> n) | (v << (32 - n)); }
static void sha256blkffk(const unsigned char *p, unsigned *h) {
    static const unsigned k[64] = {
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
    unsigned w[64];
    for (int i = 0; i < 16; i++)
        w[i] = ((unsigned)p[i*4] << 24) | ((unsigned)p[i*4+1] << 16) | ((unsigned)p[i*4+2] << 8) | p[i*4+3];
    for (int i = 16; i < 64; i++) {
        unsigned s0 = ror32ffk(w[i-15],7) ^ ror32ffk(w[i-15],18) ^ (w[i-15] >> 3);
        unsigned s1 = ror32ffk(w[i-2],17) ^ ror32ffk(w[i-2],19) ^ (w[i-2] >> 10);
        w[i] = w[i-16] + s0 + w[i-7] + s1;
    }
    unsigned a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
    for (int i = 0; i < 64; i++) {
        unsigned S1 = ror32ffk(e,6) ^ ror32ffk(e,11) ^ ror32ffk(e,25);
        unsigned ch = (e & f) ^ (~e & g);
        unsigned t1 = hh + S1 + ch + k[i] + w[i];
        unsigned S0 = ror32ffk(a,2) ^ ror32ffk(a,13) ^ ror32ffk(a,22);
        unsigned mj = (a & b) ^ (a & c) ^ (b & c);
        unsigned t2 = S0 + mj;
        hh=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
    }
    h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=hh;
}
static void sha256hexffk(const unsigned char *d, size_t n, char out[65]) {
    unsigned h[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    unsigned long long bitlen = (unsigned long long)n * 8ULL;
    unsigned char blk[64];
    size_t off = 0;
    while (off + 64 <= n) { sha256blkffk(d + off, h); off += 64; }
    size_t rem = n - off;
    for (size_t i = 0; i < 64; i++) blk[i] = 0;
    for (size_t i = 0; i < rem; i++) blk[i] = d[off + i];
    blk[rem] = 0x80;
    if (rem >= 56) { sha256blkffk(blk, h); for (int i = 0; i < 64; i++) blk[i] = 0; }
    for (int i = 0; i < 8; i++) blk[56+i] = (unsigned char)(bitlen >> (56 - i*8));
    sha256blkffk(blk, h);
    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 4; j++) {
            unsigned char v = (unsigned char)(h[i] >> (24 - j*8));
            out[i*8+j*2] = "0123456789abcdef"[v >> 4];
            out[i*8+j*2+1] = "0123456789abcdef"[v & 15];
        }
    out[64] = 0;
}
static size_t hashable_len(const void *p, size_t want) {
    if (!p || !want) return 0;
    if (want > 2048) want = 2048;
    unsigned long a = (unsigned long)p, e = a + want;
    if (!a || e < a) return 0;
    size_t rl = want;
    for (unsigned long pg = a & ~0xFFFUL; pg < e; pg += 4096)
        if (msync((void *)pg, 4096, MS_ASYNC) != 0) { rl = pg > a ? (size_t)(pg - a) : 0; break; }
    return rl;
}
static char rep_sha_ring[8][65];
static unsigned rep_sha_i = 0;
static char last_sha[20][65];
static void rep_sha_note(const unsigned char *d, size_t n, char out64[65]) {
    size_t hl = hashable_len(d, n);
    if (hl < 16) { if (out64) out64[0] = 0; return; }
    char tmp[65];
    sha256hexffk(d, hl, tmp);
    unsigned k = __sync_fetch_and_add(&rep_sha_i, 1) % 8;
    memcpy(rep_sha_ring[k], tmp, 65);
    if (out64) memcpy(out64, tmp, 65);
}

static void dump_buf(const char *tag, const void *buf, size_t len) {
    if (!tag || !buf || len == 0 || len > 8192) return;

    const unsigned char *p = (const unsigned char *)buf;
    unsigned long e = (unsigned long)p + len;
    size_t rl = len;
    for (unsigned long pg = (unsigned long)p & ~0xFFFUL; pg < e; pg += 4096) {
        if (msync((void *)pg, 4096, MS_ASYNC) != 0) {
            rl = pg > (unsigned long)p ? (size_t)(pg - (unsigned long)p) : 0;
            break;
        }
    }
    if (!rl) return;

    char line[300];
    size_t off = 0;
    while (off < rl) {
        size_t chunk = rl - off > 64 ? 64 : rl - off;
        char hx[129];
        char asc[65];
        for (size_t i = 0; i < chunk; i++) {
            unsigned char c = p[off + i];
            hx[i * 2] = "0123456789abcdef"[c >> 4];
            hx[i * 2 + 1] = "0123456789abcdef"[c & 15];
            asc[i] = (c >= 32 && c < 127) ? (char)c : '.';
        }
        hx[chunk * 2] = 0;
        asc[chunk] = 0;

        snprintf(line, sizeof(line), "%s +%04zx %s | %s", tag, off, hx, asc);
        file_append(line);
        off += chunk;
    }
}

static void annotate_buf(const char *tag, const void *buf, size_t len) {
    if (!tag || !buf || !len) return;
    size_t n = len > 128 ? 128 : len;
    if (!mem_readable(buf, n)) return;
    const unsigned char *p = (const unsigned char *)buf;
    char lb[256];
    for (size_t off = 0; off + 4 <= n; off += 16) {
        int pl = snprintf(lb, sizeof(lb), "%s-ANN +%04zx", tag, off);
        for (size_t q = off; q < off + 16 && q + 4 <= n && pl < (int)sizeof(lb) - 24; q += 4) {
            unsigned v;
            memcpy(&v, p + q, 4);
            int asc = 1;
            for (int b = 0; b < 4; b++) if (p[q+(size_t)b] < 32 || p[q+(size_t)b] >= 127) { asc = 0; break; }
            int ptr = ((v & 7) == 0 && v >= 0x10000UL && v < 0x800000000000UL);
            pl += snprintf(lb + pl, sizeof(lb) - (size_t)pl, " %08x%s", v, asc ? "=A" : (ptr ? "=P" : ""));
        }
        file_append(lb);
    }
    char sb[100];
    char ab[176];
    long st = -1;
    for (size_t i = 0; i <= n; i++) {
        int ok = (i < n && p[i] >= 32 && p[i] < 127);
        if (ok) { if (st < 0) st = (long)i; }
        else if (st >= 0) {
            if ((long)i - st >= 8) {
                long m = (long)i - st > 96 ? 96 : (long)i - st;
                memcpy(sb, p + st, (size_t)m);
                sb[m] = 0;
                snprintf(ab, sizeof(ab), "%s-STR +%04lx %s", tag, (unsigned long)st, sb);
                file_append(ab);
            }
            st = -1;
        }
    }
}
static int interesting(const char *p) {
    if (!p) return 0;
    if (strstr(p, "maps")) return 1;
    if (strstr(p, "task")) return 1;
    if (strstr(p, "status")) return 1;
    if (strstr(p, "cmdline")) return 1;
    if (strstr(p, "anogs")) return 1;
    if (strstr(p, "anort")) return 1;
    if (strstr(p, "ob_x")) return 1;
    if (strstr(p, "vm_rom")) return 1;
    if (strstr(p, "scan")) return 1;
    if (strstr(p, "report")) return 1;
    if (strstr(p, "crash")) return 1;
    if (strstr(p, "tdm")) return 1;
    if (strstr(p, "complaint")) return 1;
    if (strstr(p, "origin")) return 1;
    if (strstr(p, "killer")) return 1;
    if (strstr(p, "Killer")) return 1;
    if (strstr(p, "hook")) return 1;
    if (strstr(p, "unsafe")) return 1;
    if (strstr(p, "ff_")) return 1;
    if (strstr(p, ".so")) return 1;
    if (strstr(p, ".dex")) return 1;
    if (strstr(p, ".apk")) return 1;
    if (strstr(p, ".odex")) return 1;
    if (strstr(p, ".vdex")) return 1;
    return 0;
}

FILE *(*old_fopen)(const char *, const char *);

static int dlsymInteresting(const char *s) {
    if (!s) return 0;
    if (interesting(s)) return 1;
    if (strstr(s, "Ano")) return 1;
    if (strstr(s, "TDM") || strstr(s, "tdm")) return 1;
    if (strstr(s, "Report") || strstr(s, "report")) return 1;
    if (strstr(s, "Complaint")) return 1;
    if (strstr(s, "Scan") || strstr(s, "scan")) return 1;
    if (strstr(s, "Cheat") || strstr(s, "cheat")) return 1;
    if (strstr(s, "Hack") || strstr(s, "hack")) return 1;
    if (strstr(s, "Integrity")) return 1;
    if (strstr(s, "il2cpp")) return 1;
    if (strstr(s, "unity") || strstr(s, "Unity")) return 1;
    return 0;
}
static __thread int in_log = 0;
static pthread_mutex_t attr_mx = PTHREAD_MUTEX_INITIALIZER;
static unsigned attr_ok = 0, attr_busy = 0;
static const char *baseName(const char *p) {
    const char *b = strrchr(p, '/');
    return b ? b + 1 : p;
}
struct mapEnt { unsigned long s, e; char name[192]; };
static struct mapEnt maps_[2048];
static int maps_n = 0;
static unsigned long anogs_s = 0, anogs_e = 0;
static char rb_[98304];
static int refreshMaps(void) {
    if (in_log) return maps_n;
    if (!old_open || !old_read || !old_close) return maps_n;
    if (pthread_mutex_trylock(&attr_mx)) return maps_n;
    in_log = 1;
    maps_n = 0;
    anogs_s = 0;
    anogs_e = 0;
    int fd = old_open("/proc/self/maps", 0, 0);
    if (fd >= 0) {
        int total = 0;
        for (;;) {
            int n = (int)old_read(fd, rb_ + total, (int)sizeof(rb_) - 1 - total);
            if (n <= 0) break;
            total += n;
            if (total >= (int)sizeof(rb_) - 1) break;
        }
        old_close(fd);
        if (total > 0) {
            rb_[total] = 0;
            char *ln = rb_;
            while (*ln && maps_n < 2048) {
                char *nl = strchr(ln, '\n');
                if (nl) *nl = 0;
                unsigned long s = 0, e = 0;
                char perms[8];
                char path[192];
                perms[0] = 0;
                path[0] = 0;
                int r = sscanf(ln, "%lx-%lx %7s %*s %*s %*s %191s", &s, &e, perms, path);
                if (r >= 4 && e > s && path[0] == '/') {
                    maps_[maps_n].s = s;
                    maps_[maps_n].e = e;
                    strncpy(maps_[maps_n].name, path, 191);
                    maps_[maps_n].name[191] = 0;
                    maps_n++;
                    if (strstr(path, "anogs")) {
                        if (!anogs_s || s < anogs_s) anogs_s = s;
                        if (e > anogs_e) anogs_e = e;
                    }
                }
                if (!nl) break;
                ln = nl + 1;
            }
        }
    }
    in_log = 0;
    pthread_mutex_unlock(&attr_mx);
    return maps_n;
}
static const char *anogs_syms[] = {
    "AnoSDKGetReportData1", "AnoSDKGetReportData2",
    "AnoSDKGetReportData3", "AnoSDKGetReportData4",
    "AnoSDKDelReportData", "AnoSDKInit", "AnoSDKStart",
    "tdm_report", "ReportComplaint", "AnoSDKIoctl", "AnoSDKIoctlOld", NULL
};
struct symEnt { unsigned long a; char name[64]; };
static struct symEnt asym_[2048];
static int asym_n = 0;
struct esymEnt { char name[96]; };
static struct esymEnt esym_[2048];
static int esym_n = 0;
static unsigned long anogs_bias = 0;
static unsigned long anogs_seen_base = 0;
static unsigned long anogs_x_base = 0;
static int anogs_remap_req = 0;
static char anogs_ver[64];
static int cmpSym(const void *x, const void *y) {
    unsigned long a = ((const struct symEnt *)x)->a;
    unsigned long b = ((const struct symEnt *)y)->a;
    return a < b ? -1 : a > b ? 1 : 0;
}
static int readFull(int fd, unsigned char *o, int n) {
    int got = 0;
    while (got < n) {
        int r = (int)old_read(fd, o + got, n - got);
        if (r <= 0) break;
        got += r;
    }
    return got;
}
static unsigned char sh_[4096];
static char shst_[8192];
static char dst_[262144];
static void loadAnogsSyms(const char *path) {
    asym_n = 0;
    if (!path || !old_open || !old_read || !old_close || !old_dlsym) return;
    int fd = old_open(path, 0, 0);
    if (fd < 0) return;
    unsigned char eh[64];
    if (readFull(fd, eh, 64) != 64 || eh[0] != 0x7f || eh[1] != 'E' || eh[2] != 'L' || eh[3] != 'F' || eh[4] != 2) { old_close(fd); return; }
    unsigned long shoff;
    unsigned short shentsz, shnum, shstr;
    memcpy(&shoff, eh + 40, 8);
    memcpy(&shentsz, eh + 58, 2);
    memcpy(&shnum, eh + 60, 2);
    memcpy(&shstr, eh + 62, 2);
    if (shentsz != 64 || shnum == 0 || shnum > 64 || shstr >= shnum) { old_close(fd); return; }
    lseek(fd, (off_t)shoff, SEEK_SET);
    if (readFull(fd, sh_, shnum * 64) != shnum * 64) { old_close(fd); return; }
    unsigned char *sn = sh_ + (unsigned long)shstr * 64;
    unsigned long sbo, sbs;
    memcpy(&sbo, sn + 24, 8);
    memcpy(&sbs, sn + 32, 8);
    if (sbs == 0 || sbs > 8192) { old_close(fd); return; }
    lseek(fd, (off_t)sbo, SEEK_SET);
    if (readFull(fd, (unsigned char *)shst_, (int)sbs) != (int)sbs) { old_close(fd); return; }
    unsigned long symoff = 0, symsz = 0, syment = 24, stroff = 0, strsz = 0;
    for (unsigned i = 0; i < shnum; i++) {
        unsigned char *s = sh_ + (unsigned long)i * 64;
        unsigned type;
        unsigned nm;
        unsigned long off, sz, esz;
        memcpy(&nm, s, 4);
        memcpy(&type, s + 4, 4);
        memcpy(&off, s + 24, 8);
        memcpy(&sz, s + 32, 8);
        memcpy(&esz, s + 56, 8);
        const char *sname = nm < sbs ? shst_ + nm : "";
        if (type == 11) { symoff = off; symsz = sz; if (esz) syment = esz; }
        else if (type == 3 && !strcmp(sname, ".dynstr")) { stroff = off; strsz = sz; }
    }
    if (!symoff || !stroff || !strsz || strsz > 262144) { old_close(fd); return; }
    lseek(fd, (off_t)stroff, SEEK_SET);
    if (readFull(fd, (unsigned char *)dst_, (int)strsz) != (int)strsz) { old_close(fd); return; }
    lseek(fd, (off_t)symoff, SEEK_SET);
    unsigned long count = symsz / syment;
    if (count > 8192) count = 8192;
    for (unsigned long k = 0; k < count && asym_n < 2048; k++) {
        unsigned char en[32];
        int want = syment > 32 ? 32 : (int)syment;
        if (readFull(fd, en, want) != want) break;
        unsigned nm;
        unsigned char info;
        unsigned short shndx;
        unsigned long val;
        memcpy(&nm, en, 4);
        info = en[4];
        memcpy(&shndx, en + 6, 2);
        memcpy(&val, en + 8, 8);
        if ((info & 15) != 2 || shndx == 0 || val == 0) continue;
        if (nm >= strsz) continue;
        const char *sname = dst_ + nm;
        int l = 0;
        while (l < 63 && sname[l]) { asym_[asym_n].name[l] = sname[l]; l++; }
        asym_[asym_n].name[l] = 0;
        asym_[asym_n].a = val;
        asym_n++;
    }
    old_close(fd);
    if (!asym_n) return;
    qsort(asym_, (size_t)asym_n, sizeof(asym_[0]), cmpSym);
    unsigned long bias = 0;
    for (int i = 0; anogs_syms[i]; i++) {
        void *r = old_dlsym(RTLD_DEFAULT, anogs_syms[i]);
        if (!r) continue;
        for (int k = 0; k < asym_n; k++) {
            if (!strcmp(asym_[k].name, anogs_syms[i])) { bias = (unsigned long)r - asym_[k].a; break; }
        }
        if (bias) break;
    }
    if (!bias && anogs_s) bias = anogs_s;
    if (bias) {
        anogs_bias = bias;
        for (int k = 0; k < asym_n; k++) asym_[k].a += bias;
    }
}
static void setupAnogs(void) {
    refreshMaps();
    for (int j = 0; j < maps_n; j++) {
        if (strstr(maps_[j].name, "anogs")) {
            anogs_seen_base = maps_[j].s;
            anogs_x_base = 0;
            anogs_remap_req = 0;
            loadAnogsSyms(maps_[j].name);
            break;
        }
    }
    dumpAnogsFns();
}
static void modTag(unsigned long a, char *out, size_t outn) {
    if (!out || outn < 8) return;
    out[0] = 0;
    if (a < 4096) return;
    const char *lib = NULL;
    for (int j = 0; j < maps_n; j++) {
        if (a >= maps_[j].s && a < maps_[j].e) { lib = baseName(maps_[j].name); break; }
    }
    if (!lib) return;
    if (anogs_s && a >= anogs_s && a < anogs_e) {
        int lo = 0, hi = asym_n - 1, best = -1;
        while (lo <= hi) {
            int m = (lo + hi) / 2;
            if (asym_[m].a <= a) { best = m; lo = m + 1; } else hi = m - 1;
        }
        if (best >= 0) snprintf(out, outn, "%s!%s+0x%lx", lib, asym_[best].name, a - asym_[best].a);
        else snprintf(out, outn, "%s!?+0x%lx", lib, a - anogs_s);
        return;
    }
    snprintf(out, outn, "%s", lib);
}
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wframe-address"
static int walkFp(void **fp0, void **pcs, int max) {
    void **fp = fp0;
    int n = 0;
    while (fp && n < max) {
        if (((unsigned long)fp & 7UL)) break;
        void **next = (void **)fp[0];
        void *ret = (void *)fp[1];
        if (!ret) break;
        pcs[n++] = ret;
        if (!next || next <= fp || (unsigned long)next - (unsigned long)fp > 0x4000000UL) break;
        fp = next;
    }
    return n;
}
static int collectPcs(void **pcs, int max) {
    return walkFp((void **)__builtin_frame_address(0), pcs, max);
}
static __attribute__((noinline)) void attrTag(char *out, size_t outn) {
    if (!out || outn < 8) return;
    out[0] = 0;
    if (in_log) return;
    if (pthread_mutex_trylock(&attr_mx)) { __sync_add_and_fetch(&attr_busy, 1); return; }
    __sync_add_and_fetch(&attr_ok, 1);
    in_log = 1;
    void *pcs[6];
    int npc = collectPcs(pcs, 6);
    for (int i = 0; i < npc; i++) {
        unsigned long a = (unsigned long)pcs[i];
        char mb[160];
        modTag(a, mb, sizeof(mb));
        if (!mb[0]) continue;
        if (strstr(mb, "SignatureKiller")) continue;
        if (!strncmp(mb, "libc.so", 7) || !strncmp(mb, "libm.so", 7) || !strncmp(mb, "libart", 6) || !strncmp(mb, "linker", 6)) continue;
        if (anogs_s && a >= anogs_s && a < anogs_e) snprintf(out, outn, " anogs=%s", mb);
        else snprintf(out, outn, " via=%s", mb);
        break;
    }
    in_log = 0;
    pthread_mutex_unlock(&attr_mx);
}
#pragma GCC diagnostic pop



static char sgs_[98304];
static void dumpAnogsSegs(void) {
    if (!old_open || !old_read || !old_close) return;
    int fd = old_open("/proc/self/maps", 0, 0);
    if (fd < 0) return;
    int total = 0;
    for (;;) {
        int n = (int)old_read(fd, sgs_ + total, (int)sizeof(sgs_) - 1 - total);
        if (n <= 0) break;
        total += n;
        if (total >= (int)sizeof(sgs_) - 1) break;
    }
    old_close(fd);
    if (total <= 0) return;
    sgs_[total] = 0;
    char *ln = sgs_;
    while (*ln) {
        char *nl = strchr(ln, '\n');
        if (nl) *nl = 0;
        if (strstr(ln, "anogs")) {
            char msg[640];
            snprintf(msg, sizeof(msg), "anogs_seg=%s", ln);
            LOGE("%s", msg);
            file_append(msg);
        }
        if (!nl) break;
        ln = nl + 1;
    }
}

FILE *(*old_fopen)(const char *, const char *);

static int nlog_fd = -1;
static void raw_append(const char *line) {
    if (!line || !line[0]) return;
    long fd = syscall(SYS_openat, AT_FDCWD, "/sdcard/Download/ffk_native.txt", O_WRONLY | O_CREAT | O_APPEND, 0666);
    if (fd < 0) return;
    size_t n = strlen(line);
    if (n > 2000) n = 2000;
    syscall(SYS_write, fd, line, n);
    syscall(SYS_write, fd, "\n", 1);
    syscall(SYS_close, fd);
}
static void file_append(const char *line) {
    if (line && line[0]) ffkImguiPush(line);
    if (!old_open || !old_write || !old_close) { raw_append(line); return; }
    int was = in_log;
    in_log = 1;
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    long long ms = (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
    struct timespec rts;
    clock_gettime(CLOCK_REALTIME, &rts);
    struct tm tmv;
    localtime_r(&rts.tv_sec, &tmv);
    char buf[560];
    int n = snprintf(buf, sizeof(buf), "t=%lld %02d:%02d:%02d %s\n", ms,
        tmv.tm_hour, tmv.tm_min, tmv.tm_sec, line ? line : "");
    if (n > 0) {
        if (n >= (int)sizeof(buf)) n = (int)sizeof(buf) - 1;
        if (nlog_fd < 0) nlog_fd = old_open("/sdcard/Download/ffk_native.txt", O_WRONLY | O_CREAT | O_APPEND, 0666);
        if (nlog_fd >= 0) {
            const char *p = buf;
            int left = n;
            while (left > 0) {
                ssize_t w = old_write(nlog_fd, p, (size_t)left);
                if (w <= 0) { old_close(nlog_fd); nlog_fd = -1; break; }
                p += w;
                left -= (int)w;
            }
        }
    }
    in_log = was;
}

static void nlog(const char *kind, const char *path) {
    if (in_log) return;
    char buf[512];
    snprintf(buf, sizeof(buf), "%s %s", kind, path ? path : "NULL");
    LOGE("%s", buf);
    file_append(buf);
}
static int repInterest(const char *p) {
    if (!p) return 0;
    if (strstr(p, "ffk_native") || strstr(p, "ffk_trace")) return 0;
    if (strstr(p, "tdm") || strstr(p, "report") || strstr(p, "complaint") ||
            strstr(p, "cache") || strstr(p, "anogs") || strstr(p, "scan") ||
            strstr(p, ".json") || strstr(p, ".dat") || strstr(p, ".log") ||
            strstr(p, ".txt") || strstr(p, ".xml")) return 1;
    return 0;
}
static char fdp_[1024][192];
static unsigned repwc_[1024];
static unsigned self_n = 0;
static int selfWatch(const char *p) {
    if (!p) return 0;
    if (strstr(p, "ffk_trace") || strstr(p, "ffk_native")) return 1;
    return 0;
}
static void repTrack(int fd, const char *path) {
    if (fd < 0 || fd >= 1024 || !path || in_log) return;
    if (selfWatch(path)) {
        snprintf(fdp_[fd], sizeof(fdp_[fd]), "SELF:%s", baseName(path));
        repwc_[fd] = 0;
        char sb[256];
        snprintf(sb, sizeof(sb), "selfopen fd=%d %s", fd, path);
        LOGE("%s", sb);
        file_append(sb);
        return;
    }
    if (!repInterest(path)) return;
    strncpy(fdp_[fd], path, 191);
    fdp_[fd][191] = 0;
    repwc_[fd] = 0;
    char tb[256];
    snprintf(tb, sizeof(tb), "reptrack fd=%d %s", fd, path);
    LOGE("%s", tb);
    file_append(tb);
}
static int is_word_char(unsigned char c) {
    return (c >= 'a' && c <= 'z') ||
           (c >= 'A' && c <= 'Z') ||
           (c >= '0' && c <= '9') ||
           c == '_' || c == '-';
}

static int match_word(const unsigned char *d, long i, long m, const char *kw) {
    if (i > 0 && is_word_char(d[i - 1])) return 0;

    size_t klen = strlen(kw);
    for (size_t j = 0; j < klen; j++) {
        if (i + (long)j >= m) return 0;
        unsigned char c = d[i + j];
        if (c >= 'A' && c <= 'Z') c += 32;
        if (c != (unsigned char)kw[j]) return 0;
    }

    if (i + (long)klen < m && is_word_char(d[i + klen])) return 0;
    return 1;
}

static int looks_like_path_noise(const unsigned char *d, long st, long en) {
    for (long q = st; q + 6 < en; q++) {
        if (d[q] != '/') continue;

        if (memcmp(d + q, "/lib/", 5) == 0) return 1;
        if (memcmp(d + q, "/system/", 8) == 0) return 1;
        if (memcmp(d + q, "/apex/", 6) == 0) return 1;
        if (memcmp(d + q, "/vendor/", 8) == 0) return 1;
        if (memcmp(d + q, "/data/app/", 10) == 0) return 1;
        if (memcmp(d + q, "libanogs", 8) == 0) return 1;
        if (memcmp(d + q, "libanort", 8) == 0) return 1;
        if (memcmp(d + q, "libandroid", 10) == 0) return 1;
        if (memcmp(d + q, "libSignature", 12) == 0) return 1;
        if (memcmp(d + q, ".so", 3) == 0) return 1;
    }
    return 0;
}
static int sieve_fd = -1;
static char sieve_peer[64];
static unsigned char anogs_fd[1024];
static unsigned anogscap[1024];
static unsigned evseq = 0;
static int dump_hot = 0, nohex_g = 0;
static long long now_ms(void);
static void rep_tick(void);
static long long last_bancand_ms = 0;
static long long first_bancand_ms = 0;
static long long proc_start_ms = 0;
#define BOOT_QUIET_MS 60000
static int ref_budget = 8;
static volatile int report_active = 0;
static void report_fired(void) {
    if (proc_start_ms && now_ms() - proc_start_ms > BOOT_QUIET_MS) report_active = 1;
}
static int anogs_state = 0;
static const char *anogs_state_name(int s) {
    return s == 1 ? "ReportPending" : s == 2 ? "ReportSent" : s == 3 ? "PossibleBan" : "Normal";
}
static void anogs_set_state(int ns, const char *why) {
    if (ns == anogs_state || ns < 0 || ns > 3) return;
    char sb[192];
    snprintf(sb, sizeof(sb), "ANOGS-STATE %s->%s %s", anogs_state_name(anogs_state), anogs_state_name(ns), why ? why : "?");
    file_append(sb);
    evlog(sb);
    anogs_state = ns;
}
static char ctxring[24][192];
static volatile unsigned ctx_i = 0;
static void ctx_save(const char *s) {
    if (!s || !s[0]) return;
    unsigned i = __sync_fetch_and_add(&ctx_i, 1) % 24;
    snprintf(ctxring[i], sizeof(ctxring[i]), "%lld %s", now_ms(), s);
}
static void ctx_dump(const char *why) {
    char bh[128];
    snprintf(bh, sizeof(bh), "CTX-RING-BEGIN %s", why ? why : "?");
    file_append(bh);
    unsigned ci = ctx_i;
    for (int k = 0; k < 24; k++) {
        int idx = (int)((ci + (unsigned)k) % 24);
        if (!ctxring[idx][0]) continue;
        char cb[224];
        snprintf(cb, sizeof(cb), "ctx %s", ctxring[idx]);
        file_append(cb);
    }
    file_append("CTX-RING-END");
}
static void bancand_emit(const char *line, const char *kind) {
    long long now = now_ms();
    file_append(line);
    evlog(line);
    ctx_save(line);
    if (proc_start_ms && now - proc_start_ms < BOOT_QUIET_MS) {
        char bb[192];
        snprintf(bb, sizeof(bb), "BAN-BOOT-INIT no-correlate boot_age_ms=%lld %s", now - proc_start_ms, kind ? kind : "?");
        file_append(bb);
        evlog(bb);
        rep_tick();
        return;
    }
    if (!first_bancand_ms) {
        first_bancand_ms = now;
        char fb[160];
        snprintf(fb, sizeof(fb), "FIRST-BAN-CANDIDATE t=%lld %s", now, kind ? kind : "?");
        file_append(fb);
        evlog(fb);
    }
    last_bancand_ms = now;
    rep_tick();
    report_active = 1;
    anogs_set_state(3, kind);
    ctx_dump(kind);
}
static void time_to_ban(const char *event) {
    if (!first_bancand_ms) return;
    char tb[192];
    snprintf(tb, sizeof(tb), "TIME-TO-BAN event=%s delta_ms=%lld", event ? event : "?", now_ms() - first_bancand_ms);
    file_append(tb);
}
static void report_pattern(unsigned seq, const unsigned char *b, long blen) {
    if (!b || blen < 16) return;
    long n = blen > 1024 ? 1024 : blen;
    char tags[96];
    tags[0] = 0;
    int allzero = 1;
    for (long i = 0; i < n; i++) if (b[i]) { allzero = 0; break; }
    if (allzero) strcat(tags, "zero|");
    int nptr = 0;
    long pn = n > 128 ? 128 : n;
    for (long off = 0; off + 8 <= pn; off += 8) {
        unsigned long v;
        memcpy(&v, b + off, 8);
        if ((v & 7) == 0 && v >= 0x10000UL && v < 0x800000000000UL) nptr++;
    }
    if (nptr >= 4) strcat(tags, "ptrtable|");
    if (n >= 32 && !memcmp(b, b + 16, 16)) strcat(tags, "repeat16|");
    long pr = 0, an = n > 256 ? 256 : n;
    for (long i = 0; i < an; i++) if (b[i] >= 32 && b[i] < 127) pr++;
    if (pr * 100 / an > 70) strcat(tags, "ascii|");
    if (!tags[0]) return;
    tags[strlen(tags) - 1] = 0;
    char pb[192];
    snprintf(pb, sizeof(pb), "REPORT-PAT seq=%u TYPE=%s len=%ld", seq, tags, blen);
    file_append(pb);
}
static void report_follow(unsigned seq, const unsigned char *b, long blen) {
    if (!b || blen < 16) return;
    long scan = blen > 256 ? 256 : blen;
    int found = 0;
    for (long off = 0; off + 8 <= scan && found < 4; off += 8) {
        unsigned long v;
        memcpy(&v, b + off, 8);
        if ((v & 7) != 0 || v < 0x10000UL || v >= 0x800000000000UL) continue;
        if (!mem_readable((const void *)v, 64)) continue;
        char ph[128];
        snprintf(ph, sizeof(ph), "REPORT-PTR seq=%u off=0x%lx target=0x%lx", seq, (unsigned long)off, v);
        file_append(ph);
        dump_buf("REPORT-PTR", (const void *)v, 64);
        found++;
    }
}
static void sieve(const char *tag, const unsigned char *d, long n) {
    if (in_log || !tag || !d || n < 6) return;

    long m = n > 4096 ? 4096 : n;

    const char *hit = NULL;
    long pos = 0;

    static const char *kws[] = {
        "account suspended",
        "cheatdetected",
        "integrityfailed",
        "securityreport",
        "security violation",
        "banned",
        "suspend",
        "complaint",
        "integrity",
        "report",
        "detect",
        "cheat",
        "hack",
        "violat",
        "ban",
        NULL
    };

    for (long i = 0; i < m && !hit; i++) {
        unsigned char c = d[i];
        if (c >= 'A' && c <= 'Z') c += 32;

        if (c != 'a' && c != 'b' && c != 'c' && c != 'd' &&
            c != 'h' && c != 'i' && c != 'r' && c != 's' && c != 'v')
            continue;

        for (int k = 0; kws[k]; k++) {
            if (match_word(d, i, m, kws[k])) {
                hit = kws[k];
                pos = i;
                break;
            }
        }
    }

    if (!hit) return;

    char ctx[160];
    long st = pos > 48 ? pos - 48 : 0;
    long en = st + 120;
    if (en > m) en = m;

    if (looks_like_path_noise(d, st, en)) return;

    for (long q = st; q < en; q++) {
        unsigned char c = d[q];
        ctx[q - st] = (c >= 32 && c < 127) ? (char)c : '.';
    }
    ctx[en - st] = 0;

    char msg[360];
    if (sieve_fd >= 0)
        snprintf(msg, sizeof(msg), "sieve %s fd=%d %s kw=%s ctx=%s",
                 tag, sieve_fd, sieve_peer, hit, ctx);
    else
        snprintf(msg, sizeof(msg), "sieve %s kw=%s ctx=%s", tag, hit, ctx);

    if (sieve_fd >= 0 && sieve_fd < 1024) {
        if (!anogs_fd[sieve_fd]) {
            char fb[160];
            snprintf(fb, sizeof(fb), "ANOGS-FD fd=%d peer=%s",
                sieve_fd, sieve_peer[0] ? sieve_peer : "?");
            file_append(fb);
            evlog(fb);
        }
        anogs_fd[sieve_fd] = 1;
    }
    file_append(msg);
}

static unsigned pkt_n = 0;
static unsigned achain_n = 0;
static void pktlog(const char *dir, int fd, const char *peer, long n,
        const unsigned char *data, int withHex) {
    char hx[33];
    char msg[640];
    char at[128];
    char tx[65];
    int ti = 0;
    at[0] = 0;
    sieve_fd = fd;
    if (peer) { strncpy(sieve_peer, peer, 63); sieve_peer[63] = 0; } else sieve_peer[0] = 0;
    if (data && n > 0) sieve("pkt", data, n > 4096 ? 4096 : n);
    if (fd >= 0 && fd < 1024 && anogs_fd[fd] && data && n > 0) {
        unsigned c = __sync_fetch_and_add(&anogscap[fd], 1);
        if (c < 20 || c % 50 == 0) {
            char psha[17];
            psha[0] = 0;
            if (data && n > 0) {
                size_t pn = (size_t)n > 256 ? 256 : (size_t)n;
                size_t hl = hashable_len(data, pn);
                if (hl >= 16) {
                    char full[65];
                    sha256hexffk(data, hl, full);
                    memcpy(psha, full, 16);
                    psha[16] = 0;
                }
            }
            char bcs[24];
            bcs[0] = 0;
            if (last_bancand_ms && now_ms() - last_bancand_ms < 15000 && rep_sha_i)
                snprintf(bcs, sizeof(bcs), " bcsha=%.8s", rep_sha_ring[(rep_sha_i - 1) % 8]);
            char ph[256];
            snprintf(ph, sizeof(ph), "PKT-ANOGS seq=%u fd=%d %s n=%ld pktsha=%s%s",
                __sync_add_and_fetch(&evseq, 1), fd, (peer && peer[0]) ? peer : "?", n, psha[0] ? psha : "-", bcs);
            file_append(ph);
            ctx_save(ph);
            if (!dump_hot && !nohex_g)
                dump_buf("PKT-ANOGS", data, n > 1024 ? 1024 : (size_t)n);
            if (last_bancand_ms && data && n > 0) {
                long long age = now_ms() - last_bancand_ms;
                if (age >= 0 && age < 15000) {
                    char pr[192];
                    snprintf(pr, sizeof(pr), "=== POSSIBLE-BAN-REPLY seq=%u fd=%d %s n=%ld age_ms=%lld ===",
                        __sync_add_and_fetch(&evseq, 1), fd, (peer && peer[0]) ? peer : "?", n, age);
                    file_append(pr);
                    evlog(pr);
                    ctx_save(pr);
                    if (!dump_hot && !nohex_g)
                        dump_buf("BAN-REPLY", data, n > 1024 ? 1024 : (size_t)n);
                }
            }
        }
    }
    if (anogs_state == 1 && dir && dir[4] == 'i' && n > 2048)
        anogs_set_state(2, "big-reply");
    if ((__sync_add_and_fetch(&pkt_n, 1) % 2000) == 0) refreshMaps();
    if (withHex && data && n > 0) hex16(data, n, hx);
    else hx[0] = 0;
    if (withHex && data && n > 2 && data[0] >= 32 && data[0] < 127 &&
            data[1] >= 32 && data[1] < 127) {
        for (long i = 0; i < n && ti < 64; i++) {
            unsigned char c = data[i];
            if (c < 32 || c >= 127) break;
            tx[ti++] = (char)c;
        }
    }
    tx[ti] = 0;
    attrTag(at, sizeof(at));
    snprintf(msg, sizeof(msg), "%s tid=%d fd=%d %s n=%ld hx=%s%s%s%s%s",
        dir, mytid(), fd, (peer && peer[0]) ? peer : "?", n, hx,
        ti ? " t='" : "", ti ? tx : "", ti ? "'" : "", at);
    LOGE("%s", msg);
    file_append(msg);
    if (at[0] && strstr(at, "anogs=") && !in_log) {
        unsigned k = __sync_fetch_and_add(&achain_n, 1);
        if (k < 12 || k % 50 == 0) {
            char ch[640];
            ch[0] = 0;
            deathBt(ch, sizeof(ch));
            if (ch[0]) {
                char cm[768];
                snprintf(cm, sizeof(cm), "achain fd=%d %s %s", fd,
                    (peer && peer[0]) ? peer : "?", ch);
                LOGE("%s", cm);
                file_append(cm);
            }
        }
    }
}

static int sockfmt(const struct sockaddr *sa, socklen_t sl, char *out, size_t outn) {
    if (!sa || !out || outn < 8) return 0;
    if (sa->sa_family == AF_INET && sl >= (socklen_t)sizeof(struct sockaddr_in)) {
        const struct sockaddr_in *a = (const struct sockaddr_in *)sa;
        const unsigned char *b = (const unsigned char *)&a->sin_addr.s_addr;
        snprintf(out, outn, "%d.%d.%d.%d:%d",
            b[0], b[1], b[2], b[3], (int)ntohs(a->sin_port));
        return 1;
    }
    if (sa->sa_family == AF_UNIX && sl > (socklen_t)sizeof(sa_family_t)) {
        const struct sockaddr_un *u = (const struct sockaddr_un *)sa;
        unsigned long plen = (unsigned long)sl - sizeof(sa_family_t);
        if (plen > sizeof(u->sun_path)) plen = sizeof(u->sun_path);
        int absx = (plen > 0 && u->sun_path[0] == 0);
        unsigned long start = absx ? 1 : 0;
        char nm[56];
        unsigned long k = 0;
        while (start + k < plen && k + 1 < sizeof(nm) && u->sun_path[start + k]) {
            nm[k] = u->sun_path[start + k];
            k++;
        }
        nm[k] = 0;
        if (!k) return 0;
        snprintf(out, outn, "unix:%s%s", absx ? "@" : "", nm);
        return 1;
    }
    if (sa->sa_family == AF_INET6 && sl >= (socklen_t)sizeof(struct sockaddr_in6)) {
        const struct sockaddr_in6 *a = (const struct sockaddr_in6 *)sa;
        const unsigned char *b = a->sin6_addr.s6_addr;
        snprintf(out, outn, "[%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x]:%d",
            b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7],
            b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15],
            (int)ntohs(a->sin6_port));
        return 1;
    }
    return 0;
}

static int selfnoise(const unsigned char *d, long n) {
    if (!d || n <= 0) return 0;
    long m = n > 128 ? 128 : n;
    static const char *marks[] = {"FFKX", "FFKN", "pkt ", "close fd=",
        "socket fd=", "connect ", "sendto ", "sendmsg ", "dns ", "dlopen"};
    for (int k = 0; k < 10; k++) {
        const char *mk = marks[k];
        size_t ml = strlen(mk);
        for (long i = 0; i + (long)ml <= m; i++) {
            if (memcmp(d + i, mk, ml) == 0) return 1;
        }
    }
    return 0;
}
static pthread_mutex_t ring_mx = PTHREAD_MUTEX_INITIALIZER;
struct ringEnt { int fd; char dir[8]; char peer[64]; long len; char hx[65]; long long t; };
static struct ringEnt ring_[12];
static int ring_i = 0, ring_full = 0;
static int full_n = 0;
static int full_fd[1024];
static int bin_fd = -1;
static void fullcap(int fd, const unsigned char *d, long n, int isOut) {
    if (!d || n <= 0 || fd < 0 || fd >= 1024) return;
    if (!sockpeer[fd][0] || !strncmp(sockpeer[fd], "unix:", 5)) return;
    if (full_n >= 1048576 || full_fd[fd] >= 32768) return;
    if (in_log || !old_open || !old_write || !old_close) return;
    long m = n > 16384 ? 16384 : n;
    if (full_n + 21 + m > 1048576) m = 1048576 - full_n - 21;
    if (full_fd[fd] + 21 + m > 32768) m = 32768 - full_fd[fd] - 21;
    if (m <= 0) return;
    if (isOut && !in_log && n >= 43 && d[0] == 0x16 && d[1] == 0x03 && d[5] == 0x01) {
        unsigned hslen = ((unsigned)d[6] << 16) | ((unsigned)d[7] << 8) | (unsigned)d[8];
        if (hslen >= 34) {
            char rh[65];
            for (int q = 0; q < 32; q++) {
                unsigned char c = d[11 + q];
                rh[q * 2] = "0123456789abcdef"[c >> 4];
                rh[q * 2 + 1] = "0123456789abcdef"[c & 15];
            }
            rh[64] = 0;
            char cb[128];
            snprintf(cb, sizeof(cb), "ch_random fd=%d hx=%s", fd, rh);
            LOGE("%s", cb);
            file_append(cb);
        }
    }
    { static long long flast[1024]; static unsigned char fact[1024]; struct timespec t0; clock_gettime(CLOCK_MONOTONIC, &t0); long long now0 = (long long)t0.tv_sec * 1000LL + t0.tv_nsec / 1000000LL; if (fact[fd] && now0 - flast[fd] > 8000 && !in_log) { char rb[160]; snprintf(rb, sizeof(rb), "rhythm fd=%d gap=%lldms %s", fd, now0 - flast[fd], isOut ? "out" : "in"); LOGE("%s", rb); file_append(rb); } flast[fd] = now0; fact[fd] = 1; }
    in_log = 1;
    if (bin_fd < 0) bin_fd = old_open("/sdcard/Download/ffk_full.bin", O_WRONLY | O_CREAT | O_APPEND, 0666);
    int f = bin_fd;
    if (f >= 0) {
        unsigned char h[21];
        int fdi = fd, mm = (int)m, tid = mytid();
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        long long ms = (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
        h[0] = isOut ? 'O' : 'I';
        memcpy(h + 1, &fdi, 4);
        memcpy(h + 5, &mm, 4);
        memcpy(h + 9, &ms, 8);
        memcpy(h + 17, &tid, 4);
        if (old_write(f, h, 21) != 21) { old_close(f); bin_fd = -1; }
        else if (old_write(f, d, (size_t)m) <= 0) { old_close(f); bin_fd = -1; }
        __atomic_fetch_add(&full_n, 21 + (int)m, __ATOMIC_RELAXED);
        __atomic_fetch_add(&full_fd[fd], 21 + (int)m, __ATOMIC_RELAXED);
    }
    in_log = 0;
}
static unsigned ring_dup_n = 0;
static int ring_dup_fd = -1;
static long ring_dup_len = 0;
static char ring_dup_hx[17];
static void mirror(const char *tag, int fd, const unsigned char *d, long seg, long total) {
    if (!tag || !d || seg <= 0 || total <= 0) return;
    if (fd < 0 || fd >= 1024 || !sockpeer[fd][0]) return;
    if (seg > 2048) seg = 2048;
    if (selfnoise(d, seg)) return;
    sieve_fd = fd;
    strncpy(sieve_peer, sockpeer[fd], 63);
    sieve_peer[63] = 0;
    sieve(tag, d, seg);
    {
        char dh[17];
        {
            size_t qn = (size_t)seg > 64 ? 64 : (size_t)seg;
            size_t qh = hashable_len(d, qn);
            if (qh >= 8) {
                char qf[65];
                sha256hexffk(d, qh, qf);
                memcpy(dh, qf, 16);
                dh[16] = 0;
            } else {
                long dm = seg > 8 ? 8 : seg;
                static const char *hh = "0123456789abcdef";
                for (long i = 0; i < dm; i++) { dh[i*2] = hh[d[i] >> 4]; dh[i*2+1] = hh[d[i] & 15]; }
                dh[dm*2] = 0;
            }
        }
        if (fd == ring_dup_fd && total == ring_dup_len && !strcmp(dh, ring_dup_hx)) {
            __atomic_fetch_add(&ring_dup_n, 1, __ATOMIC_RELAXED);
            if (ring_dup_n % 100 == 0) {
                char lp[128];
                snprintf(lp, sizeof(lp), "lastpkt-dup fd=%d n=%ld x%u (consecutive)", fd, total, ring_dup_n);
                file_append(lp);
            }
            return;
        }
        if (ring_dup_n) {
            char lp[128];
            snprintf(lp, sizeof(lp), "lastpkt-dup fd=%d n=%ld total x%u", ring_dup_fd, ring_dup_len, ring_dup_n + 1);
            file_append(lp);
            ring_dup_n = 0;
        }
        ring_dup_fd = fd;
        ring_dup_len = total;
        strcpy(ring_dup_hx, dh);
    }
    if (pthread_mutex_trylock(&ring_mx)) return;
    struct ringEnt *e = &ring_[ring_i];
    e->fd = fd;
    strncpy(e->dir, tag, 7);
    e->dir[7] = 0;
    strncpy(e->peer, sockpeer[fd], 63);
    e->peer[63] = 0;
    e->len = total;
    long m = seg > 32 ? 32 : seg;
    static const char *h = "0123456789abcdef";
    for (long i = 0; i < m; i++) {
        e->hx[i * 2] = h[d[i] >> 4];
        e->hx[i * 2 + 1] = h[d[i] & 15];
    }
    e->hx[m * 2] = 0;
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    e->t = (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
    ring_i = (ring_i + 1) % 12;
    if (ring_i == 0) ring_full = 1;
    pthread_mutex_unlock(&ring_mx);
}
static void repBody(const char *tag, int fd, const unsigned char *d, long n) {
    if (!tag || !d || n < 4 || fd < 0 || fd >= 1024) return;
    if (!fdp_[fd][0] || repwc_[fd] >= 3 || in_log) return;
    if (selfnoise(d, n)) return;
    int isSelf = fdp_[fd][0] == 'S' && fdp_[fd][1] == 'E' && fdp_[fd][2] == 'L' && fdp_[fd][3] == 'F';
    if (isSelf) {
        if (self_n >= 8) return;
        __sync_fetch_and_add(&self_n, 1);
    }
    __sync_fetch_and_add(&repwc_[fd], 1);
    char hx[33];
    hex16(d, n, hx);
    char tx[65];
    int ti = 0;
    if (d[0] >= 32 && d[0] < 127 && n > 1 && d[1] >= 32 && d[1] < 127) {
        for (long i = 0; i < n && ti < 64; i++) {
            unsigned char c = d[i];
            if (c < 32 || c >= 127) break;
            tx[ti++] = (char)c;
        }
    }
    tx[ti] = 0;
    sieve("rep", d, n > 4096 ? 4096 : n);
    char at[128];
    at[0] = 0;
    attrTag(at, sizeof(at));
    char msg[640];
    snprintf(msg, sizeof(msg), "%s %s n=%ld hx=%s%s%s%s%s", tag, fdp_[fd], n, hx,
        ti ? " t='" : "", ti ? tx : "", ti ? "'" : "", at);
    LOGE("%s", msg);
    file_append(msg);
}
static void repDel(const char *path) {
    if (!path || in_log || !old_open || !old_read || !old_close) return;
    if (!repInterest(path)) return;
    in_log = 1;
    int fd = old_open(path, 0, 0);
    if (fd >= 0) {
        unsigned char b[512];
        int n = (int)old_read(fd, b, sizeof(b));
        old_close(fd);
        if (n > 0) {
            char hx[33];
            hex16(b, n, hx);
            char tx[65];
            int ti = 0;
            if (b[0] >= 32 && b[0] < 127 && n > 1 && b[1] >= 32 && b[1] < 127) {
                for (int i = 0; i < n && ti < 64; i++) {
                    if (b[i] < 32 || b[i] >= 127) break;
                    tx[ti++] = (char)b[i];
                }
            }
            tx[ti] = 0;
            in_log = 0;
            char at[128];
            at[0] = 0;
            attrTag(at, sizeof(at));
            char msg[640];
            snprintf(msg, sizeof(msg), "repdel %s n=%d hx=%s%s%s%s%s", path, n, hx,
                ti ? " t='" : "", ti ? tx : "", ti ? "'" : "", at);
            sieve("repdel", b, n > 4096 ? 4096 : n);
            LOGE("%s", msg);
            file_append(msg);
            return;
        }
    }
    in_log = 0;
}
static void dumpRing(void) {
    if (pthread_mutex_trylock(&ring_mx)) return;
    int total = ring_full ? 12 : ring_i;
    for (int k = 0; k < total; k++) {
        int idx = ring_full ? (ring_i + k) % 12 : k;
        struct ringEnt *e = &ring_[idx];
        char msg[320];
        snprintf(msg, sizeof(msg), "lastpkt %s fd=%d %s n=%ld hx=%s t=%lld",
            e->dir, e->fd, e->peer[0] ? e->peer : "?",
            e->len, e->hx, e->t);
        LOGE("%s", msg);
        file_append(msg);
    }
    {
        char ab[96];
        snprintf(ab, sizeof(ab), "attr ok=%u busy=%u", attr_ok, attr_busy);
        LOGE("%s", ab);
        file_append(ab);
    }
    pthread_mutex_unlock(&ring_mx);
}
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wframe-address"
static __attribute__((noinline)) void deathBt(char *out, size_t outn) {
    if (!out || outn < 16) return;
    out[0] = 0;
    int locked = pthread_mutex_trylock(&attr_mx) == 0;
    if (locked) __sync_add_and_fetch(&attr_ok, 1);
    void *pcs[8];
    int npc = collectPcs(pcs, 8);
    size_t used = 0;
    for (int i = 0; i < npc; i++) {
        unsigned long a = (unsigned long)pcs[i];
        if (a < 4096) continue;
        char mb[160];
        mb[0] = 0;
        if (locked) modTag(a, mb, sizeof(mb));
        else snprintf(mb, sizeof(mb), "0x%lx", a);
        if (!mb[0]) continue;
        if (strstr(mb, "SignatureKiller")) continue;
        int w = snprintf(out + used, outn - used, "[%s]", mb);
        if (w <= 0 || (size_t)w >= outn - used) break;
        used += (size_t)w;
    }
    if (locked) pthread_mutex_unlock(&attr_mx);
}
#pragma GCC diagnostic pop
struct rxEnt { unsigned long s, e; char nm[128]; };
static struct rxEnt rxseen_[512];
static int rxseen_n = 0;
static int watcher_logged_ok = 0;
struct sslEnt { char dir; int len; long long t; int tid; char sha[65]; unsigned char b[1024]; };
static char ptx_pre[16][65];
static long long ptx_ms[16];
static char ptx_dir[16];
static int ptx_tid[16];
static unsigned ptx_i = 0;
static struct sslEnt sslring_[64];
static unsigned sslring_w = 0;
static void sslTap(char dir, const unsigned char *d, int n) {
    if (!d || n <= 0) return;
    unsigned k = __atomic_fetch_add(&sslring_w, 1, __ATOMIC_RELAXED) % 64;
    sslring_[k].len = 0;
    int m = n > 1024 ? 1024 : n;
    memcpy(sslring_[k].b, d, (size_t)m);
    sslring_[k].dir = dir;
    int tid = mytid();
    sslring_[k].tid = tid;
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    sslring_[k].t = (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
    sslring_[k].sha[0] = 0;
    if (m >= 16) {
        int nz = 0;
        for (int z = 0; z < 16; z++) if (d[z]) { nz = 1; break; }
        if (nz) {
            size_t qn = (size_t)m > 64 ? 64 : (size_t)m;
            char t[65];
            sha256hexffk(d, qn, t);
            memcpy(sslring_[k].sha, t, 65);
            unsigned q = __sync_fetch_and_add(&ptx_i, 1) % 16;
            memcpy(ptx_pre[q], t, 65);
            ptx_ms[q] = sslring_[k].t;
            ptx_dir[q] = dir;
            ptx_tid[q] = tid;
        }
    }
    sslring_[k].len = m;
}
static char wbuf_[98304];
static void *watcherFn(void *a) {
    (void)a;
    pthread_setname_np(pthread_self(), "FFKWatch");
    for (;;) {
        struct timespec rq;
        rq.tv_sec = 0;
        rq.tv_nsec = 500000000L;
        nanosleep(&rq, NULL);
        bh_poll_armed();
        if (!old_open || !old_read || !old_close) continue;
        int fd = old_open("/proc/self/maps", 0, 0);
        int total = 0;
        if (fd >= 0) {
            for (;;) {
                int n = (int)old_read(fd, wbuf_ + total, (int)sizeof(wbuf_) - 1 - total);
                if (n <= 0) break;
                total += n;
                if (total >= (int)sizeof(wbuf_) - 1) break;
            }
            old_close(fd);
        }
        if (total > 0) {
            wbuf_[total] = 0;
            if (!watcher_logged_ok) {
                watcher_logged_ok = 1;
                char wb[96];
                snprintf(wb, sizeof(wb), "watcher ok");
                LOGE("%s", wb);
                file_append(wb);
            }
            int logged = 0;
            unsigned long xbase = 0;
            char *ln = wbuf_;
            while (*ln) {
                char *nl = strchr(ln, '\n');
                if (nl) *nl = 0;
                unsigned long s = 0, e = 0;
                char perms[8];
                char path[192];
                perms[0] = 0;
                path[0] = 0;
                int r = sscanf(ln, "%lx-%lx %7s %*s %*s %*s %191s", &s, &e, perms, path);
                if (r >= 3 && e > s && perms[0] == 'r' && perms[2] == 'x') {
                    if (path[0] && strstr(path, "anogs") && (!xbase || s < xbase)) xbase = s;
                    int seen = 0;
                    for (int j = 0; j < rxseen_n; j++) {
                        if (rxseen_[j].s == s && rxseen_[j].e == e) { seen = 1; break; }
                    }
                    if (!seen && rxseen_n < 512) {
                        rxseen_[rxseen_n].s = s;
                        rxseen_[rxseen_n].e = e;
                        const char *nm = path[0] ? path : "[anon]";
                        strncpy(rxseen_[rxseen_n].nm, nm, 127);
                        rxseen_[rxseen_n].nm[127] = 0;
                        rxseen_n++;
                        if (logged < 12) {
                            char msg[448];
                            if (!path[0])
                                snprintf(msg, sizeof(msg), "hidemod anon r-xp %lx-%lx", s, e);
                            else
                                snprintf(msg, sizeof(msg), "newrx %lx-%lx %s", s, e, nm);
                            LOGE("%s", msg);
                            file_append(msg);
                            logged++;
                        }
                    }
                }
                if (!nl) break;
                ln = nl + 1;
            }
            if (xbase && !in_log) {
                if (!anogs_x_base) anogs_x_base = xbase;
                else if (xbase != anogs_x_base) {
                    anogs_x_base = xbase;
                    anogs_remap_req = 1;
                    char rb2[160];
                    snprintf(rb2, sizeof(rb2), "anogs remap base=0x%lx", xbase);
                    LOGE("%s", rb2);
                    file_append(rb2);
                }
            }
        }
        { static unsigned sslring_r = 0;
        unsigned w = __atomic_load_n(&sslring_w, __ATOMIC_RELAXED);
        int shown = 0;
        while (sslring_r != w && shown < 12) {
            struct sslEnt *e = &sslring_[sslring_r % 64];
            sslring_r++;
            if (e->len <= 0 || e->len > 1024) continue;
            int off = 0;
            int part = 0;
            int cnt = (e->len + 223) / 224;
            while (off < e->len && shown < 12) {
                int m = e->len - off > 224 ? 224 : e->len - off;
                char hx[449], tx[225];
                for (int q = 0; q < m; q++) {
                    unsigned char c = e->b[off + q];
                    hx[q * 2] = "0123456789abcdef"[c >> 4];
                    hx[q * 2 + 1] = "0123456789abcdef"[c & 15];
                    tx[q] = (c >= 32 && c < 127) ? (char)c : '.';
                }
                hx[m * 2] = 0;
                tx[m] = 0;
                char sb[896];
                long long sage = last_bancand_ms ? e->t - last_bancand_ms : -1LL;
                char pbc[24]; pbc[0] = 0;
                if (sage >= 0 && sage < 15000 && rep_sha_i)
                    snprintf(pbc, sizeof(pbc), " bcsha=%.8s", rep_sha_ring[(rep_sha_i - 1) % 8]);
                snprintf(sb, sizeof(sb), "sslp %c t=%lld n=%d p=%d/%d%s psha=%.16s%s hx=%s t='%s'", e->dir, e->t, e->len, part + 1, cnt,
                    (sage >= 0 && sage < 15000) ? " BAN-REPLY" : "", e->sha[0] ? e->sha : "-", pbc, hx, tx);
                LOGE("%s", sb);
                file_append(sb);
                off += m;
                part++;
                shown++;
            } } }
    }
    return NULL;
}
static int watcher_on = 0;
static void watcherStart(void) {
    if (watcher_on) return;
    watcher_on = 1;
    pthread_t t;
    pthread_create(&t, NULL, watcherFn, NULL);
    pthread_detach(t);
}

int (*old_open)(const char *, int, mode_t);
static int openImpl(const char *pathname, int flags, mode_t mode) {
    hkEnter(4);
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_open(repPath__, flags, mode);
    if (interesting(pathname)) nlog("open", pathname);
    int r = old_open(pathname, flags, mode);
    repTrack(r, pathname);
    return r;
}

int (*old_open64)(const char *, int, mode_t);
static int open64Impl(const char *pathname, int flags, mode_t mode) {
    hkEnter(3);
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_open64(repPath__, flags, mode);
    if (interesting(pathname)) nlog("open64", pathname);
    int r = old_open64(pathname, flags, mode);
    repTrack(r, pathname);
    return r;
}

int (*old_openat)(int, const char *, int, mode_t);
static int openatImpl(int fd, const char *pathname, int flags, mode_t mode) {
    hkEnter(2);
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_openat(fd, repPath__, flags, mode);
    if (interesting(pathname)) nlog("openat", pathname);
    int r = old_openat(fd, pathname, flags, mode);
    repTrack(r, pathname);
    return r;
}

int (*old_openat64)(int, const char *, int, mode_t);
static int openat64Impl(int fd, const char *pathname, int flags, mode_t mode) {
    hkEnter(1);
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_openat64(fd, repPath__, flags, mode);
    if (interesting(pathname)) nlog("openat64", pathname);
    int r = old_openat64(fd, pathname, flags, mode);
    repTrack(r, pathname);
    return r;
}

int (*old_access)(const char *, int);
static int accessImpl(const char *pathname, int mode_) {
    hkEnter(5);
    if (interesting(pathname)) nlog("access", pathname);
    return old_access(pathname, mode_);
}

static FILE *fopenImpl(const char *pathname, const char *mode_) {
    hkEnter(6);
    if (interesting(pathname)) nlog("fopen", pathname);
    FILE *f = old_fopen(pathname, mode_);
    if (f && pathname && repInterest(pathname) && !in_log) {
        int fd = fileno(f);
        repTrack(fd, pathname);
    }
    return f;
}

int (*old_stat)(const char *, struct stat *);
static int statImpl(const char *pathname, struct stat *buf) {
    hkEnter(7);
    if (interesting(pathname)) nlog("stat", pathname);
    return old_stat(pathname, buf);
}

int (*old_stat64)(const char *, void *);
static int stat64Impl(const char *pathname, void *buf) {
    hkEnter(8);
    if (interesting(pathname)) nlog("stat64", pathname);
    return old_stat64(pathname, buf);
}

int (*old_lstat)(const char *, struct stat *);
static int lstatImpl(const char *pathname, struct stat *buf) {
    hkEnter(9);
    if (interesting(pathname)) nlog("lstat", pathname);
    return old_lstat(pathname, buf);
}

int (*old_lstat64)(const char *, void *);
static int lstat64Impl(const char *pathname, void *buf) {
    hkEnter(10);
    if (interesting(pathname)) nlog("lstat64", pathname);
    return old_lstat64(pathname, buf);
}

int (*old_fstatat)(int, const char *, struct stat *, int);
static int fstatatImpl(int fd, const char *pathname, struct stat *buf, int flag) {
    hkEnter(11);
    if (interesting(pathname)) nlog("fstatat", pathname);
    return old_fstatat(fd, pathname, buf, flag);
}

int (*old_fstatat64)(int, const char *, void *, int);
static int fstatat64Impl(int fd, const char *pathname, void *buf, int flag) {
    hkEnter(12);
    if (interesting(pathname)) nlog("fstatat64", pathname);
    return old_fstatat64(fd, pathname, buf, flag);
}

int (*old_unlink)(const char *);
static int unlinkImpl(const char *pathname) {
    hkEnter(13);
    repDel(pathname);
    if (interesting(pathname)) nlog("unlink", pathname);
    return old_unlink(pathname);
}

int (*old_unlinkat)(int, const char *, int);
static int unlinkatImpl(int fd, const char *pathname, int flag) {
    hkEnter(14);
    repDel(pathname);
    if (interesting(pathname)) nlog("unlinkat", pathname);
    return old_unlinkat(fd, pathname, flag);
}

int (*old_rename)(const char *, const char *);
static int renameImpl(const char *oldp, const char *newp) {
    hkEnter(15);
    if (interesting(oldp) || interesting(newp)) {
        char buf[512];
        snprintf(buf, sizeof(buf), "rename %s -> %s", oldp ? oldp : "NULL", newp ? newp : "NULL");
        LOGE("%s", buf);
        file_append(buf);
    }
    return old_rename(oldp, newp);
}

int (*old_mkdir)(const char *, mode_t);
static int mkdirImpl(const char *pathname, mode_t mode) {
    hkEnter(16);
    if (interesting(pathname)) nlog("mkdir", pathname);
    return old_mkdir(pathname, mode);
}

static void dumpAnogsApi(void) {
    if (!old_dlsym || in_log) return;
    in_log = 1;
    for (int i = 0; anogs_syms[i]; i++) {
        void *a = old_dlsym(RTLD_DEFAULT, anogs_syms[i]);
        if (a) {
            char buf[256];
            snprintf(buf, sizeof(buf), "anogs_api %s=%p", anogs_syms[i], a);
            LOGE("%s", buf);
            file_append(buf);
        }
    }
    in_log = 0;
}
static void dumpAnogsFns(void) {
    if (in_log || !asym_n) return;
    in_log = 1;
    {
        int cap = asym_n > 400 ? 400 : asym_n;
        for (int k = 0; k < cap; k++) {
            char buf[160];
            snprintf(buf, sizeof(buf), "anogs_fn %s 0x%lx", asym_[k].name, asym_[k].a);
            in_log = 0;
            LOGE("%s", buf);
            file_append(buf);
            in_log = 1;
        }
    }
    {
        int cap = asym_n > 400 ? 400 : asym_n;
        int shown = 0;
        for (int k = 0; k < cap && shown < 24; k++) {
            unsigned long sz = (k + 1 < cap) ? asym_[k + 1].a - asym_[k].a : 0;
            if (sz < 0x200 || sz > 0x3000) continue;
            char sb[288];
            snprintf(sb, sizeof(sb), "anogs_site %s sz=0x%lx @0x%lx", asym_[k].name, sz, asym_[k].a);
            in_log = 0;
            LOGE("%s", sb);
            file_append(sb);
            in_log = 1;
            shown++;
        }
    }
    for (int j = 0; j < maps_n; j++) {
        if (!strstr(maps_[j].name, "anogs")) continue;
        const char *path = maps_[j].name;
        int fd = old_open(path, 0, 0);
        if (fd < 0) continue;
        unsigned char eh[64];
        if (readFull(fd, eh, 64) != 64 || eh[0] != 0x7f) { old_close(fd); continue; }
        unsigned long phoff = 0, shoff = 0;
        unsigned short phentsz = 0, phnum = 0, shentsz = 0, shnum = 0, shstr = 0;
        memcpy(&phoff, eh + 32, 8);
        memcpy(&phentsz, eh + 54, 2);
        memcpy(&phnum, eh + 56, 2);
        memcpy(&shoff, eh + 40, 8);
        memcpy(&shentsz, eh + 58, 2);
        memcpy(&shnum, eh + 60, 2);
        memcpy(&shstr, eh + 62, 2);
        unsigned long txV = 0, txO = 0;
        if (phentsz == 56 && phnum > 0 && phnum <= 16) {
            lseek(fd, (off_t)phoff, SEEK_SET);
            for (unsigned q = 0; q < phnum; q++) {
                unsigned char ph[56];
                if (readFull(fd, ph, 56) != 56) break;
                unsigned pt = 0, pf = 0;
                unsigned long po = 0, pv = 0, pfsz = 0, pmsz = 0;
                memcpy(&pt, ph, 4);
                memcpy(&pf, ph + 4, 4);
                memcpy(&po, ph + 8, 8);
                memcpy(&pv, ph + 16, 8);
                memcpy(&pfsz, ph + 32, 8);
                memcpy(&pmsz, ph + 40, 8);
                if (pt == 1 && (pf & 5) == 5 && !txV) { txV = pv; txO = po; }
                char pb[192];
                snprintf(pb, sizeof(pb), "anogs_ph t=%u f=%u off=0x%lx v=0x%lx fsz=0x%lx msz=0x%lx",
                    pt, pf, po, pv, pfsz, pmsz);
                in_log = 0;
                LOGE("%s", pb);
                file_append(pb);
                in_log = 1;
            }
        }
        if (shentsz == 64 && shnum > 0 && shnum <= 64 && shstr < shnum) {
            lseek(fd, (off_t)shoff, SEEK_SET);
            if (readFull(fd, sh_, shnum * 64) == shnum * 64) {
                unsigned char *sn = sh_ + (unsigned long)shstr * 64;
                unsigned long bo = 0, bs = 0;
                memcpy(&bo, sn + 24, 8);
                memcpy(&bs, sn + 32, 8);
                if (bs > 0 && bs <= 8192) {
                    lseek(fd, (off_t)bo, SEEK_SET);
                    if (readFull(fd, (unsigned char *)shst_, (int)bs) == (int)bs) {
                        for (unsigned q = 0; q < shnum; q++) {
                            unsigned char *sc = sh_ + (unsigned long)q * 64;
                            unsigned nm = 0, ty = 0;
                            unsigned long of = 0, sz = 0;
                            memcpy(&nm, sc, 4);
                            memcpy(&ty, sc + 4, 4);
                            memcpy(&of, sc + 24, 8);
                            memcpy(&sz, sc + 32, 8);
                            const char *sname = nm < bs ? shst_ + nm : "";
                            char lb[160];
                            snprintf(lb, sizeof(lb), "anogs_sh %.48s t=%u off=0x%lx sz=0x%lx", sname, ty, of, sz);
                            in_log = 0;
                            LOGE("%s", lb);
                            file_append(lb);
                            in_log = 1;
                        }
                    }
                }
            }
        }
        {
            int cap = asym_n > 400 ? 400 : asym_n;
            int shown = 0;
            for (int k = 0; k < cap && shown < 24 && anogs_bias && txV; k++) {
                unsigned long sz = (k + 1 < cap) ? asym_[k + 1].a - asym_[k].a : 0;
                if (sz < 0x200 || sz > 0x3000) continue;
                unsigned long fo = asym_[k].a - anogs_bias - txV + txO;
                lseek(fd, (off_t)fo, SEEK_SET);
                unsigned char tb[16];
                int n = readFull(fd, tb, 16);
                if (n == 16) {
                    char hx[33];
                    for (int q = 0; q < 16; q++) {
                        hx[q * 2] = "0123456789abcdef"[tb[q] >> 4];
                        hx[q * 2 + 1] = "0123456789abcdef"[tb[q] & 15];
                    }
                    hx[32] = 0;
                    char tl[192];
                    snprintf(tl, sizeof(tl), "anogs_tx %s sz=0x%lx %s", asym_[k].name, sz, hx);
                    in_log = 0;
                    LOGE("%s", tl);
                    file_append(tl);
                    in_log = 1;
                    shown++;
                }
            }
        }
        old_close(fd);
        break;
    }
    in_log = 0;
}
static int symPrefix(const char *s, const char *p) {
    if (!s || !p) return 0;
    while (*p) { if (*s++ != *p++) return 0; }
    return 1;
}
static void dumpEngineSyms(const char *path, const char *tag, const char *prefix) {
    if (!path || !tag || !prefix || !old_open || !old_read || !old_close || in_log) return;
    in_log = 1;
    int fd = old_open(path, 0, 0);
    if (fd < 0) { in_log = 0; return; }
    unsigned char eh[64];
    if (readFull(fd, eh, 64) != 64 || eh[0] != 0x7f || eh[1] != 'E' || eh[2] != 'L' || eh[3] != 'F' || eh[4] != 2) { old_close(fd); in_log = 0; return; }
    unsigned long shoff;
    unsigned short shentsz, shnum, shstr;
    memcpy(&shoff, eh + 40, 8);
    memcpy(&shentsz, eh + 58, 2);
    memcpy(&shnum, eh + 60, 2);
    memcpy(&shstr, eh + 62, 2);
    if (shentsz != 64 || shnum == 0 || shnum > 64 || shstr >= shnum) { old_close(fd); in_log = 0; return; }
    lseek(fd, (off_t)shoff, SEEK_SET);
    if (readFull(fd, sh_, shnum * 64) != shnum * 64) { old_close(fd); in_log = 0; return; }
    unsigned char *sn = sh_ + (unsigned long)shstr * 64;
    unsigned long sbo, sbs;
    memcpy(&sbo, sn + 24, 8);
    memcpy(&sbs, sn + 32, 8);
    if (sbs == 0 || sbs > 8192) { old_close(fd); in_log = 0; return; }
    lseek(fd, (off_t)sbo, SEEK_SET);
    if (readFull(fd, (unsigned char *)shst_, (int)sbs) != (int)sbs) { old_close(fd); in_log = 0; return; }
    unsigned long symoff = 0, symsz = 0, syment = 24, stroff = 0, strsz = 0;
    for (unsigned i = 0; i < shnum; i++) {
        unsigned char *s = sh_ + (unsigned long)i * 64;
        unsigned type, nm;
        unsigned long off, sz, esz;
        memcpy(&nm, s, 4);
        memcpy(&type, s + 4, 4);
        memcpy(&off, s + 24, 8);
        memcpy(&sz, s + 32, 8);
        memcpy(&esz, s + 56, 8);
        const char *sname = nm < sbs ? shst_ + nm : "";
        if (type == 11) { symoff = off; symsz = sz; if (esz) syment = esz; }
        else if (type == 3 && !strcmp(sname, ".dynstr")) { stroff = off; strsz = sz; }
    }
    int shown = 0;
    if (symoff && stroff && strsz && strsz <= 262144) {
        lseek(fd, (off_t)stroff, SEEK_SET);
        if (readFull(fd, (unsigned char *)dst_, (int)strsz) == (int)strsz) {
            lseek(fd, (off_t)symoff, SEEK_SET);
            unsigned long count = symsz / syment;
            if (count > 8192) count = 8192;
            for (unsigned long k = 0; k < count && shown < 400; k++) {
                unsigned char en[32];
                int want = syment > 32 ? 32 : (int)syment;
                if (readFull(fd, en, want) != want) break;
                unsigned nm;
                unsigned char info;
                unsigned short shndx;
                unsigned long val;
                memcpy(&nm, en, 4);
                info = en[4];
                memcpy(&shndx, en + 6, 2);
                memcpy(&val, en + 8, 8);
                if ((info & 15) != 2 || shndx == 0 || val == 0 || nm >= strsz) continue;
                const char *sname = dst_ + nm;
                if (!symPrefix(sname, prefix) && strcmp(sname, "UnitySendMessage")) continue;
                if (esym_n < 2048) {
                    int l = 0;
                    while (l < 95 && sname[l]) { esym_[esym_n].name[l] = sname[l]; l++; }
                    esym_[esym_n].name[l] = 0;
                    esym_n++;
                }
                char lb[192];
                snprintf(lb, sizeof(lb), "%s %.96s 0x%lx", tag, sname, val);
                in_log = 0;
                LOGE("%s", lb);
                file_append(lb);
                in_log = 1;
                shown++;
            }
        }
    }
    old_close(fd);
    {
        char cb[128];
        snprintf(cb, sizeof(cb), "%s_shown=%d", tag, shown);
        in_log = 0;
        LOGE("%s", cb);
        file_append(cb);
    }
    in_log = 0;
}
static void setupAnogsIfPresent(void) {
    for (int j = 0; j < maps_n; j++) {
        if (strstr(maps_[j].name, "anogs")) {
            dumpAnogsSegs();
            dumpAnogsApi();
            setupAnogs();
            break;
        }
    }
}
static long long now_ms(void);
static pthread_mutex_t ref_mx = PTHREAD_MUTEX_INITIALIZER;
static long long rep_last = 0;
static long long last_refresh_ms = 0;
#define MIN_REFRESH_INTERVAL_MS 2500
#define REPORT_BREATHER_MS 800
static int is_blacklisted(const char *name) {
    if (!name) return 1;
    if (strstr(name, "libSignatureKiller")) return 1;
    if (strstr(name, "libc.so")) return 1;
    if (strstr(name, "libdl.so")) return 1;
    if (strstr(name, "libandroid.so")) return 1;
    if (strstr(name, "libEGL.so")) return 1;
    if (strstr(name, "libGLESv")) return 1;
    if (strstr(name, "libil2cpp.so")) return 1;
    if (strstr(name, "libunity.so")) return 1;
    if (strstr(name, "libmain.so")) return 1;
    if (strstr(name, "libcrashlytics")) return 1;
    if (strstr(name, "libFirebaseCpp")) return 1;
    return 0;
}
static int is_engine_lib(const char *f) {
    if (!f) return 0;
    if (strstr(f, "libil2cpp")) return 1;
    if (strstr(f, "libunity")) return 1;
    if (strstr(f, "libanogs")) return 1;
    if (strstr(f, "libanort")) return 1;
    return 0;
}
static char evring[32][96];
static volatile unsigned ev_i = 0;
static void evlog(const char *s) {
    if (!s || !s[0]) return;
    unsigned i = __sync_fetch_and_add(&ev_i, 1) % 32;
    snprintf(evring[i], sizeof(evring[i]), "%lld %s", now_ms(), s);
}
static void safe_refresh(const char *why) {
    long long now = now_ms();
    if (report_active) {
        char sb[160];
        snprintf(sb, sizeof(sb), "xrefresh blocked-after-report %s", why ? why : "?");
        file_append(sb);
        return;
    }
    if (ref_budget <= 0) {
        char sb[160];
        snprintf(sb, sizeof(sb), "xrefresh budget-skip %s", why ? why : "?");
        file_append(sb);
        return;
    }
    if (last_refresh_ms && now - last_refresh_ms < MIN_REFRESH_INTERVAL_MS) {
        char sb[160];
        snprintf(sb, sizeof(sb), "xrefresh ratelimit-skip %s", why ? why : "?");
        file_append(sb);
        return;
    }
    if (rep_last && now - rep_last < REPORT_BREATHER_MS) {
        char sb[160];
        snprintf(sb, sizeof(sb), "xrefresh breather-skip %s", why ? why : "?");
        file_append(sb);
        return;
    }
    if (pthread_mutex_trylock(&ref_mx) != 0) {
        char sb[160];
        snprintf(sb, sizeof(sb), "xrefresh busy-skip %s", why ? why : "?");
        file_append(sb);
        return;
    }
    if (why && is_blacklisted(why)) {
        char sb[160];
        snprintf(sb, sizeof(sb), "xrefresh blacklist-skip %s", why);
        file_append(sb);
        pthread_mutex_unlock(&ref_mx);
        return;
    }
    {
        char rb[160];
        snprintf(rb, sizeof(rb), "xrefresh begin %s tid=%d", why ? why : "?", mytid());
        file_append(rb);
        evlog(rb);
    }
    file_append("xrefresh auto-bhook (no manual refresh)");
    last_refresh_ms = now;
    ref_budget--;
    pthread_mutex_unlock(&ref_mx);
    file_append("xrefresh end");
    evlog("xrefresh end");
}
static int is_syslib(const char *f) {
    if (!f) return 1;
    if (!strncmp(f, "/system/", 8) || !strncmp(f, "/vendor/", 8) ||
        !strncmp(f, "/apex/", 6) || !strncmp(f, "/product/", 9)) return 1;
    const char *b = strrchr(f, '/');
    b = b ? b + 1 : f;
    static const char *sys[] = {"libc.so", "libdl.so", "libm.so", "liblog.so",
        "libz.so", "libc++.so", "libstdc++.so", "libandroid.so", "libEGL.so",
        "libGLESv2.so", "libGLESv1_CM.so", "libvulkan.so", "libOpenSLES.so",
        "libaaudio.so", "libmediandk.so", "libjnigraphics.so", "libnativewindow.so",
        "libsync.so", "libcutils.so", "libutils.so", "libhardware.so",
        "libGLES_trace.so", NULL};
    for (int i = 0; sys[i]; i++) if (!strcmp(b, sys[i])) return 1;
    return 0;
}
static char refseen[16][128];
static unsigned refseen_i = 0;
static int ref_seen(const char *f) {
    char b[128];
    strncpy(b, f ? f : "null", sizeof(b) - 1);
    b[sizeof(b) - 1] = 0;
    for (int i = 0; i < 16; i++) if (!strcmp(refseen[i], b)) return 1;
    strncpy(refseen[refseen_i % 16], b, sizeof(refseen[0]));
    refseen_i++;
    return 0;
}
static void maybe_refresh(const char *filename) {
    if (is_syslib(filename) || ref_seen(filename)) {
        char sb[160];
        snprintf(sb, sizeof(sb), "xrefresh skip %s", filename ? filename : "null");
        file_append(sb);
        return;
    }
    if (!is_engine_lib(filename)) {
        char sb[160];
        snprintf(sb, sizeof(sb), "xrefresh engskip %s", filename ? filename : "null");
        file_append(sb);
        return;
    }
    safe_refresh(filename);
}
void *(*old_dlopen)(const char *, int);
static void *dlopenImpl(const char *filename, int flags) {
    hkEnter(17);
    nlog("dlopen", filename ? filename : "NULL");
    if (filename && strstr(filename, "libFirebaseCpp")) {
        const char *b = strrchr(filename, '/');
        bytehook_add_ignore(b ? b + 1 : filename);
    }
    if (filename && strstr(filename, "anogs")) {
        dumpAnogsSegs();
        dumpAnogsApi();
        setupAnogs();
    }
    if (filename && (strstr(filename, "libil2cpp") || strstr(filename, "libunity")))
        dumpEngineSyms(filename, strstr(filename, "libil2cpp") ? "il2cpp_fn" : "unity_fn",
            strstr(filename, "libil2cpp") ? "il2cpp_" : "Unity");
    maybe_refresh(filename);
    void *h = old_dlopen(filename, flags);
    if (h && filename && filename[0]) bh_elf_manager_refresh(false, bh_late_newelf, NULL);
    if (anogs_remap_req) {
        anogs_remap_req = 0;
        dumpAnogsSegs();
        dumpAnogsApi();
        setupAnogs();
    }
    return h;
}

void *(*old_android_dlopen_ext)(const char *, int, const void *);
static void *android_dlopen_extImpl(const char *filename, int flags, const void *extinfo) {
    hkEnter(18);
    (void)extinfo;
    nlog("dlopen_ext", filename ? filename : "NULL");
    if (filename && strstr(filename, "libFirebaseCpp")) {
        const char *b = strrchr(filename, '/');
        bytehook_add_ignore(b ? b + 1 : filename);
    }
    if (filename && strstr(filename, "anogs")) {
        dumpAnogsSegs();
        dumpAnogsApi();
        setupAnogs();
    }
    if (filename && (strstr(filename, "libil2cpp") || strstr(filename, "libunity")))
        dumpEngineSyms(filename, strstr(filename, "libil2cpp") ? "il2cpp_fn" : "unity_fn",
            strstr(filename, "libil2cpp") ? "il2cpp_" : "Unity");
    maybe_refresh(filename);
    void *h = old_android_dlopen_ext(filename, flags, extinfo);
    if (h && filename && filename[0]) bh_elf_manager_refresh(false, bh_late_newelf, NULL);
    if (anogs_remap_req) {
        anogs_remap_req = 0;
        dumpAnogsSegs();
        dumpAnogsApi();
        setupAnogs();
    }
    return h;
}

int (*old_socket)(int, int, int);
static int socketImpl(int domain, int type, int proto) {
    hkEnter(19);
    int fd = old_socket(domain, type, proto);
    if (fd >= 0) {
        trackAdd(fd);
        char buf[80];
        snprintf(buf, sizeof(buf), "socket fd=%d dom=%d type=%d", fd, domain, type);
        LOGE("%s", buf);
        file_append(buf);
    }
    return fd;
}

struct ldir64 { long d_ino; long d_off; unsigned short d_reclen; unsigned char d_type; char d_name[1]; };
static void taskDump(void) {
    if (in_log || !old_open || !old_read || !old_close) return;
    in_log = 1;
    int mt = mytid();
    char pc[64], pw[64], cb[64], wb[64];
    snprintf(pc, sizeof(pc), "/proc/self/task/%d/comm", mt);
    snprintf(pw, sizeof(pw), "/proc/self/task/%d/wchan", mt);
    int cf = old_open(pc, O_RDONLY, 0);
    cb[0] = 0;
    if (cf >= 0) { long cr = old_read(cf, cb, sizeof(cb) - 1); if (cr > 0) { cb[cr] = 0; if (cb[cr-1] == '\n') cb[cr-1] = 0; } old_close(cf); }
    int wf = old_open(pw, O_RDONLY, 0);
    wb[0] = 0;
    if (wf >= 0) { long wr = old_read(wf, wb, sizeof(wb) - 1); if (wr > 0) wb[wr] = 0; old_close(wf); }
    char lb[256];
    snprintf(lb, sizeof(lb), "taskself tid=%d comm=%s wchan=%s", mt, cb[0] ? cb : "?", wb[0] ? wb : "?");
    in_log = 0;
    LOGE("%s", lb);
    file_append(lb);
    in_log = 1;
    in_log = 0;
}
void *(*old_eglGetProcAddress)(const char *);
static void *eglGetProcAddressImpl(const char *name) {
    hkEnter(54);
    void *r = old_eglGetProcAddress ? old_eglGetProcAddress(name) : NULL;
    if (r && name && !in_log && (strstr(name, "egl") || strstr(name, "Swap") || strstr(name, "swap"))) {
        static unsigned procq_n = 0;
        unsigned q = ++procq_n;
        if (q <= 30 || q % 200 == 0) {
            char qb[160];
            snprintf(qb, sizeof(qb), "procq n=%u %s -> %p", q, name, r);
            LOGE("%s", qb);
            file_append(qb);
        }
    }
    if (r && name && !strcmp(name, "eglSwapBuffers") && !in_log) {
        extern void **ffkOldSwapAddr(void);
        void **slot = ffkOldSwapAddr();
        if (slot) *slot = r;
        char mb[96];
        snprintf(mb, sizeof(mb), "swap_armed %p", r);
        LOGE("%s", mb);
        file_append(mb);
        extern unsigned int ffkSwapBuffers(void *, void *);
        return (void *)ffkSwapBuffers;
    }
    return r;
}
void *old_swapDamage = 0;
static unsigned ffkSwapDamageImpl(void *dpy, void *surf, void *rects, int n) {
    hkEnter(53);
    extern unsigned ffkSwapBuffers(void *, void *);
    unsigned rr = ffkSwapBuffers(dpy, surf);
    (void)rr;
    if (old_swapDamage) return ((unsigned (*)(void *, void *, void *, int))old_swapDamage)(dpy, surf, rects, n);
    return 0;
}
int (*old_close)(int);
int (*old_sysprop)(const char *, char *);
extern void ffkShotArm(void);
static int ffk_shot_n = 0;
void ffkSaveShot(const unsigned char *rgba, int w, int h) {
    if (!rgba || w <= 0 || h <= 0 || w > 4096 || h > 4096) return;
    if (ffk_shot_n >= 4) return;
    if (!old_open || !old_write || !old_close || in_log) return;
    in_log = 1;
    int sw = w / 3 > 0 ? w / 3 : 1, sh = h / 3 > 0 ? h / 3 : 1;
    int rowb = sw * 4;
    int img = rowb * sh;
    int hd = 54;
    unsigned char bh[54];
    memset(bh, 0, sizeof(bh));
    bh[0] = 'B'; bh[1] = 'M';
    unsigned fsz = (unsigned)(hd + img);
    memcpy(bh + 2, &fsz, 4);
    unsigned dbo = (unsigned)hd;
    memcpy(bh + 10, &dbo, 4);
    unsigned bis = 40;
    memcpy(bh + 14, &bis, 4);
    memcpy(bh + 18, &sw, 4);
    memcpy(bh + 22, &sh, 4);
    unsigned short pl = 1, bc = 32;
    memcpy(bh + 26, &pl, 2);
    memcpy(bh + 28, &bc, 4);
    char path[64];
    snprintf(path, sizeof(path), "/sdcard/Download/ffk_shot_%d.bmp", ffk_shot_n);
    int fd = old_open(path, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (fd >= 0) {
        old_write(fd, bh, 54);
        for (int y = sh - 1; y >= 0; y--) {
            for (int x = 0; x < sw; x++) {
                int sx = x * 3, sy = y * 3;
                const unsigned char *p = rgba + ((sy * w) + sx) * 4;
                unsigned char px[4];
                px[0] = p[2]; px[1] = p[1]; px[2] = p[0]; px[3] = 0xFF;
                old_write(fd, px, 4);
            }
        }
        old_close(fd);
        char mb[96];
        snprintf(mb, sizeof(mb), "shot saved %s %dx%d", path, sw, sh);
        in_log = 0;
        LOGE("%s", mb);
        file_append(mb);
        in_log = 1;
        ffk_shot_n++;
    }
    in_log = 0;
}
static int closeImpl(int fd) {
    hkEnter(20);
    int r = old_close(fd);
    int isext = (fd >= 0 && fd < 1024 && sockpeer[fd][0] && strncmp(sockpeer[fd], "unix:", 5));
    unsigned pk = (fd >= 0 && fd < 1024) ? sockcnt[fd] : 0;
    if (fd >= 0 && fd < 1024) { fdp_[fd][0] = 0; repwc_[fd] = 0; sockpeer[fd][0] = 0; full_fd[fd] = 0; }
    if (trackHas(fd)) {
        char buf[160];
        snprintf(buf, sizeof(buf), "close fd=%d pkts=%u fullcap=%d peer=%s",
            fd, sockcnt[fd], full_n, sockpeer[fd][0] ? sockpeer[fd] : "?");
        LOGE("%s", buf);
        file_append(buf);
        trackDel(fd);
    }
    if (isext) taskDump();
    if (isext && pk >= 6 && ffk_shot_n < 4 && !in_log) {
        ffkShotArm();
        char sb2[96];
        snprintf(sb2, sizeof(sb2), "shot armed fd=%d pkts=%u", fd, pk);
        LOGE("%s", sb2);
        file_append(sb2);
    }
    return r;
}

int (*old_connect)(int, const struct sockaddr *, socklen_t);
static int connectImpl(int fd, const struct sockaddr *addr, socklen_t len) {
    hkEnter(24);
    char peer[96];
    if (sockfmt(addr, len, peer, sizeof(peer))) {
        char buf[224];
        snprintf(buf, sizeof(buf), "connect tid=%d fd=%d %s", mytid(), fd, peer);
        LOGE("%s", buf);
        file_append(buf);
        trackPeer(fd, peer);
    }
    return old_connect(fd, addr, len);
}

ssize_t (*old_sendto)(int, const void *, size_t, int, const struct sockaddr *, socklen_t);
static ssize_t sendtoImpl(int fd, const void *buf_, size_t len, int flags,
        const struct sockaddr *addr, socklen_t alen) {
    hkEnter(25);
    char peer[96];
    if (sockfmt(addr, alen, peer, sizeof(peer))) {
        trackPeer(fd, peer);
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)len))
            pktlog("pkt out", fd, peer, (long)len, (const unsigned char *)buf_, c <= 30);
    } else if (trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)len))
            pktlog("pkt out", fd, sockpeer[fd], (long)len, (const unsigned char *)buf_, c <= 30);
    }
    mirror("pktout", fd, (const unsigned char *)buf_, (long)len, (long)len);
    if (!addr) fullcap(fd, (const unsigned char *)buf_, (long)len, 1);
    return old_sendto(fd, buf_, len, flags, addr, alen);
}

ssize_t (*old_sendmsg)(int, const struct msghdr *, int);
static ssize_t sendmsgImpl(int fd, const struct msghdr *msg, int flags) {
    hkEnter(26);
    if (trackHas(fd) || (msg && msg->msg_name)) {
        size_t total = 0;
        if (msg) {
            size_t n = msg->msg_iovlen > 8 ? 8 : msg->msg_iovlen;
            if (msg->msg_iov) for (size_t i = 0; i < n; i++) total += msg->msg_iov[i].iov_len;
        }
        const char *peer = sockpeer[fd];
        char tmp[96];
        if (msg && msg->msg_name &&
                sockfmt((const struct sockaddr *)msg->msg_name, msg->msg_namelen, tmp, sizeof(tmp))) {
            trackPeer(fd, tmp);
            peer = tmp;
        }
        unsigned c = trackBump(fd);
        if (c <= 30 || c % 50 == 0)
            pktlog("pkt out", fd, peer, (long)total, NULL, 0);
        if (msg && msg->msg_iov && msg->msg_iovlen > 0 && msg->msg_iov[0].iov_base)
            mirror("pktout", fd, (const unsigned char *)msg->msg_iov[0].iov_base,
                (long)msg->msg_iov[0].iov_len, (long)total);
        if (msg && !msg->msg_name && msg->msg_iov && msg->msg_iovlen > 0 && msg->msg_iov[0].iov_base) {
            long s0 = (long)msg->msg_iov[0].iov_len;
            if (s0 > 16384) s0 = 16384;
            fullcap(fd, (const unsigned char *)msg->msg_iov[0].iov_base, s0, 1);
        }
    }
    return old_sendmsg(fd, msg, flags);
}

ssize_t (*old_send)(int, const void *, size_t, int);
static ssize_t sendImpl(int fd, const void *buf_, size_t len, int flags) {
    hkEnter(27);
    if (trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)len))
            pktlog("pkt out", fd, sockpeer[fd], (long)len, (const unsigned char *)buf_, c <= 30);
    }
    mirror("pktout", fd, (const unsigned char *)buf_, (long)len, (long)len);
    fullcap(fd, (const unsigned char *)buf_, (long)len, 1);
    return old_send(fd, buf_, len, flags);
}

ssize_t (*old_recv)(int, void *, size_t, int);
static ssize_t recvImpl(int fd, void *buf_, size_t len, int flags) {
    hkEnter(28);
    ssize_t r = old_recv(fd, buf_, len, flags);
    if (r > 0 && trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)r))
            pktlog("pkt in", fd, sockpeer[fd], (long)r, (const unsigned char *)buf_, c <= 30);
    }
    if (r > 0) mirror("pktin", fd, (const unsigned char *)buf_, r, r);
    if (r > 0) fullcap(fd, (const unsigned char *)buf_, r, 0);
    return r;
}

ssize_t (*old_recvfrom)(int, void *, size_t, int, struct sockaddr *, socklen_t *);
static ssize_t recvfromImpl(int fd, void *buf_, size_t len, int flags,
        struct sockaddr *addr, socklen_t *alen) {
    hkEnter(29);
    ssize_t r = old_recvfrom(fd, buf_, len, flags, addr, alen);
    if (r > 0 && trackHas(fd)) {
        char tmp[96];
        const char *peer = sockpeer[fd];
        if (addr && alen && sockfmt(addr, *alen, tmp, sizeof(tmp)))
            peer = tmp;
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)r))
            pktlog("pkt in", fd, peer, (long)r, (const unsigned char *)buf_, c <= 30);
    }
    if (r > 0) mirror("pktin", fd, (const unsigned char *)buf_, r, r);
    if (r > 0) fullcap(fd, (const unsigned char *)buf_, r, 0);
    return r;
}

ssize_t (*old_recvmsg)(int, struct msghdr *, int);
static ssize_t recvmsgImpl(int fd, struct msghdr *msg, int flags) {
    hkEnter(30);
    ssize_t r = old_recvmsg(fd, msg, flags);
    if (r > 0 && trackHas(fd)) {
        const char *peer = sockpeer[fd];
        char tmp[96];
        if (msg && msg->msg_name &&
                sockfmt((const struct sockaddr *)msg->msg_name, msg->msg_namelen, tmp, sizeof(tmp)))
            peer = tmp;
        const unsigned char *sample = NULL;
        if (msg && msg->msg_iovlen > 0 && msg->msg_iov) sample = (const unsigned char *)msg->msg_iov[0].iov_base;
        unsigned c = trackBump(fd);
        if (c <= 30 || c % 50 == 0)
            pktlog("pkt in", fd, peer, (long)r, sample, c <= 30);
        if (r > 0 && sample && msg && msg->msg_iov && msg->msg_iovlen > 0) {
            long seg0 = (long)msg->msg_iov[0].iov_len;
            if (seg0 > r) seg0 = r;
            mirror("pktin", fd, sample, seg0, r);
            if (!msg->msg_name) fullcap(fd, sample, seg0, 0);
        }
    }
    return r;
}

ssize_t (*old_read)(int, void *, size_t);
static ssize_t readImpl(int fd, void *buf_, size_t n) {
    hkEnter(31);
    ssize_t r = old_read(fd, buf_, n);
    if (r > 0 && trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)r))
            pktlog("pkt in", fd, sockpeer[fd], (long)r, (const unsigned char *)buf_, c <= 30);
    }
    if (r > 0) mirror("pktin", fd, (const unsigned char *)buf_, r, r);
    if (r > 0) repBody("repr", fd, (const unsigned char *)buf_, r);
    return r;
}

static ssize_t writeImpl(int fd, const void *buf_, size_t n) {
    hkEnter(32);
    if (trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)n))
            pktlog("pkt out", fd, sockpeer[fd], (long)n, (const unsigned char *)buf_, c <= 30);
    }
    mirror("pktout", fd, (const unsigned char *)buf_, (long)n, (long)n);
    fullcap(fd, (const unsigned char *)buf_, (long)n, 1);
    ssize_t r = old_write(fd, buf_, n);
    if (r > 0) repBody("repw", fd, (const unsigned char *)buf_, (long)n);
    return r;
}

int (*old_getaddrinfo)(const char *, const char *, const struct addrinfo *, struct addrinfo **);
static int getaddrinfoImpl(const char *node, const char *service,
        const struct addrinfo *hints, struct addrinfo **res) {
    hkEnter(33);
    if (node) {
        char buf[448];
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        snprintf(buf, sizeof(buf), "dns %s%s", node, at);
        LOGE("%s", buf);
        file_append(buf);
    }
    return old_getaddrinfo(node, service, hints, res);
}

static void UnitySendMessageImpl(const char *obj, const char *method, const char *msg);
static void (*usm_real)(const char *, const char *, const char *);
static int usm_armed = 0;
static unsigned repcap_[20];
static const char *rep_names[20] = {"AnoSDKGetReportData", "AnoSDKGetReportData2",
    "AnoSDKGetReportData3", "AnoSDKGetReportData4", "AnoSDKDelReportData",
    "AnoSDKDelReportData3", "AnoSDKDelReportData4", "AnoSDKOnRecvData",
    "AnoSDKInit", "AnoSDKInitEx", "AnoSDKSetUserInfo", "AnoSDKSetUserInfoWithLicense",
    "AnoSDKIoctl", "AnoSDKIoctlOld", "AnoSDKOnPause", "AnoSDKOnResume",
    "AnoSDKFree", "AnoSDKOnRecvSignature", "AnoSDKRegistInfoListener", "AnoSDKForExport"};
static void *real_rep[20];
static int repIdx(const char *s) {
    if (!s) return -1;
    for (int i = 0; i < 20; i++) if (!strcmp(s, rep_names[i])) return i;
    return -1;
}
static void repdump_arg(int idx, const char *phase, int ai, long av) {
    if (av < 4096 && av > -4096) {
        char lb[160];
        snprintf(lb, sizeof(lb), "repget tid=%d %s %s a%d=%ld", mytid(), rep_names[idx], phase, ai, av);
        LOGE("%s", lb);
        file_append(lb);
        return;
    }
    unsigned long a = (unsigned long)av;
    unsigned long pg0 = a & ~0xFFFUL, pg1 = (a + 127) & ~0xFFFUL;
    int ok = msync((void *)pg0, 4096, MS_ASYNC) == 0 &&
        (pg1 == pg0 || msync((void *)pg1, 4096, MS_ASYNC) == 0);
    if (!ok) {
        char lb[192];
        snprintf(lb, sizeof(lb), "repget tid=%d %s %s a%d=0x%lx (unreadable)", mytid(), rep_names[idx], phase, ai, a);
        LOGE("%s", lb);
        file_append(lb);
        return;
    }
    unsigned char b[128];
    memcpy(b, (const void *)a, 128);
    for (int o = 0; o < 128; o += 64) {
        char hx[129], tx[65];
        for (int q = 0; q < 64; q++) {
            unsigned char c = b[o + q];
            hx[q * 2] = "0123456789abcdef"[c >> 4];
            hx[q * 2 + 1] = "0123456789abcdef"[c & 15];
            tx[q] = (c >= 32 && c < 127) ? (char)c : '.';
        }
        hx[128] = 0;
        tx[64] = 0;
        char lb[384];
        snprintf(lb, sizeof(lb), "repget tid=%d %s %s a%d=0x%lx+%d %s %s",
            mytid(), rep_names[idx], phase, ai, a, o, hx, tx);
        LOGE("%s", lb);
        file_append(lb);
    }
    sieve("repget", b, 128);
}
static const char *ioctl_name(int cmd) {
    switch (cmd) {
        case 0x0a: return "cmd0a";
        case 0x12: return "cmd12";
        case 0x0e: return "version";
        case 0x14: return "init";
        case 0x46: return "report";
        case 0x47: return "report2";
        case 0x48: return "report3";
        case 0x50: return "recv";
        case 0x51: return "send";
        case 0x60: return "status";
        case 0x70: return "config";
        default:   return "unknown";
    }
}
static unsigned rep_hist[7];
static unsigned rephist_n = 0;
static void rep_hist_line(void) {
    char hh[224];
    snprintf(hh, sizeof(hh), "REP-HIST n=%u s64=%u s128=%u s256=%u s512=%u s1k=%u s2k=%u big=%u",
        rephist_n, rep_hist[0], rep_hist[1], rep_hist[2], rep_hist[3],
        rep_hist[4], rep_hist[5], rep_hist[6]);
    file_append(hh);
}
static const char *ret_meaning(long r) {
    if (r == 0) return "ok";
    if (r < 0) return "error";
    if (r <= 4096) return "small";
    return "ptr";
}
static long long rep_times[64];
static int rep_idx = 0, rep_tot = 0;
static long long now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}
static void rep_tick(void) {
    long long now = now_ms();
    rep_times[rep_idx % 64] = now;
    rep_last = now;
    rep_idx++;
    if (rep_tot < 64) rep_tot++;
}
static void rep_freq(char *out, size_t outn) {
    long long now = now_ms();
    int c10 = 0, c30 = 0;
    for (int i = 0; i < rep_tot; i++) {
        long long dt = now - rep_times[i];
        if (dt <= 10000) c10++;
        if (dt <= 30000) c30++;
    }
    snprintf(out, outn, "freq10=%d freq30=%d", c10, c30);
}
static __thread int in_repdump = 0;
static unsigned repadm = 0;
static int rep_hot(void) {
    long long now = now_ms();
    int c = 0;
    for (int i = 0; i < rep_tot; i++) if (now - rep_times[i] <= 10000) c++;
    return c > 40;
}
static int rep_bare_check(void) {
    if ((__sync_add_and_fetch(&repadm, 1) % 20) == 0) {
        long r = syscall(__NR_faccessat, AT_FDCWD, "/sdcard/Download/ffk_nohex", F_OK);
        nohex_g = (r == 0);
    }
    int hot = rep_hot();
    if (hot != dump_hot) {
        dump_hot = hot;
        file_append(hot ? "REPDUMP-HOT on (headers only)" : "REPDUMP-HOT off (full dumps)");
        evlog(hot ? "REPDUMP-HOT on" : "REPDUMP-HOT off");
    }
    return dump_hot || nohex_g;
}
static void modOff(unsigned long a, char *out, size_t outn) {
    if (!out || outn < 8) return;
    out[0] = 0;
    if (a < 4096) return;
    for (int j = 0; j < maps_n; j++) {
        if (a >= maps_[j].s && a < maps_[j].e) {
            snprintf(out, outn, "%s+0x%lx", baseName(maps_[j].name), a - maps_[j].s);
            return;
        }
    }
}
static unsigned char prev_rb[20][256];
static int prev_rn[20];
static int lastrep_idx = -1;
static char lastrep_phase[8];
static int lastrep_tid = 0;
static long long lastrep_ms = 0;
static char lastrep_cs[96];
static char lastrep_sha[65];
static void rep_diffk(int idx, unsigned seq, const char *nm, const unsigned char *b, long blen, const char *rawsha) {
    if (idx < 0 || idx >= 20 || !nm) return;
    int haveMaps = (pthread_mutex_trylock(&attr_mx) == 0);
    if (rawsha && rawsha[0]) memcpy(lastrep_sha, rawsha, 65);
    if (b && blen > 0 && rawsha && rawsha[0]) {
        long n = blen > 256 ? 256 : blen;
        if (mem_readable(b, (size_t)n) && prev_rn[idx] > 0) {
            long m = n < prev_rn[idx] ? n : prev_rn[idx];
            long lanes = m / 8 > 16 ? 16 : m / 8;
            if (lanes > 0) {
                char cls[17];
                unsigned long paddrs[16];
                int planes[16];
                int np = 0;
                long long now = now_ms();
                unsigned long long un = (unsigned long long)now;
                for (long L = 0; L < lanes; L++) {
                    unsigned long long o, v;
                    memcpy(&o, prev_rb[idx] + L * 8, 8);
                    memcpy(&v, b + L * 8, 8);
                    char c;
                    if (o == v) c = 'C';
                    else if ((v & 7) == 0 && v >= 0x10000ULL && v < 0x800000000000ULL) {
                        c = 'P';
                        if (np < 16) { paddrs[np] = (unsigned long)v; planes[np] = (int)L; np++; }
                    }
                    else if ((v >= un - 3600000ULL && v <= un + 60000ULL) ||
                             (v >= un * 1000ULL - 3600000000ULL && v <= un * 1000ULL + 60000000ULL)) c = 'T';
                    else {
                        long long d = (long long)(v - o);
                        c = (d >= -(1LL << 32) && d <= (1LL << 32)) ? 'N' : 'R';
                    }
                    cls[L] = c;
                }
                cls[lanes] = 0;
                char cb[160];
                snprintf(cb, sizeof(cb), "REPORT-CLS seq=%u %s %s", seq, nm, cls);
                file_append(cb);
                for (int q = 0; q < np; q++) {
                    char mo[160];
                    mo[0] = 0;
                    if (haveMaps) modOff(paddrs[q], mo, sizeof(mo));
                    char pl[300];
                    snprintf(pl, sizeof(pl), "REPORT-CLS-PTR seq=%u %s lane=%d addr=0x%lx norm=%s", seq, nm, planes[q], paddrs[q], mo[0] ? mo : "-");
                    file_append(pl);
                }
            }
            if (n != prev_rn[idx]) {
                if (last_sha[idx][0] && strcmp(last_sha[idx], rawsha)) {
                    char db[192];
                    snprintf(db, sizeof(db), "REPORT-DIFF seq=%u %s kind=len %d->%ld", seq, nm, prev_rn[idx], n);
                    file_append(db);
                }
            } else {
                unsigned char c1[256], c2[256];
                memcpy(c1, prev_rb[idx], (size_t)n);
                memcpy(c2, b, (size_t)n);
                for (long L = 0; L + 8 <= n; L += 8) {
                    unsigned long long v;
                    memcpy(&v, c2 + L, 8);
                    if ((v & 7) == 0 && v >= 0x10000ULL && v < 0x800000000000ULL) {
                        memset(c1 + L, 0, 8);
                        memset(c2 + L, 0, 8);
                    }
                }
                char s1[65], s2[65];
                sha256hexffk(c1, (size_t)n, s1);
                sha256hexffk(c2, (size_t)n, s2);
                if (last_sha[idx][0] && strcmp(last_sha[idx], rawsha)) {
                    char db[192];
                    snprintf(db, sizeof(db), "REPORT-DIFF seq=%u %s kind=%s", seq, nm,
                        strcmp(s1, s2) ? "content" : "ptr-only");
                    file_append(db);
                }
            }
        }
        if (mem_readable(b, (size_t)n)) { memcpy(prev_rb[idx], b, (size_t)n); prev_rn[idx] = (int)n; }
        {
            size_t hl = hashable_len(b, (size_t)n);
            if (hl >= 16) {
                int nz = 0;
                for (int z = 0; z < 16; z++) if (b[z]) { nz = 1; break; }
                if (nz) {
                    size_t qn = hl > 64 ? 64 : hl;
                    char cp[65];
                    sha256hexffk(b, qn, cp);
                    for (unsigned q = 0; q < 16; q++) {
                        if (ptx_pre[q][0] && !strcmp(ptx_pre[q], cp)) {
                            char mb[224];
                            snprintf(mb, sizeof(mb), "=== REPORT-NET-MATCH seq=%u %s dir=%c tid=%d age_ms=%lld ===",
                                seq, nm, ptx_dir[q], ptx_tid[q], now_ms() - ptx_ms[q]);
                            file_append(mb);
                            evlog(mb);
                            ctx_save(mb);
                            break;
                        }
                    }
                }
            }
        }
    }
    if (haveMaps) pthread_mutex_unlock(&attr_mx);
    if (rawsha && rawsha[0] && (last_sha[idx][0] == 0 || strcmp(last_sha[idx], rawsha)))
        memcpy(last_sha[idx], rawsha, 65);
}
static int pb_varint(const unsigned char *b, long n, long *off, unsigned long long *v) {
    unsigned long long r = 0;
    int sh = 0;
    while (*off < n && sh < 64) {
        unsigned char c = b[(*off)++];
        r |= (unsigned long long)(c & 0x7F) << sh;
        if (!(c & 0x80)) { *v = r; return 1; }
        sh += 7;
    }
    return 0;
}
static void pb_fields(const char *tag, const unsigned char *b, long n, int depth, int *count) {
    long off = 0;
    char lb[224];
    while (off < n && *count < 24) {
        unsigned long long tv;
        if (!pb_varint(b, n, &off, &tv) || tv == 0) break;
        unsigned f = (unsigned)(tv >> 3);
        unsigned wt = (unsigned)(tv & 7);
        if (f == 0 || f > 4194303) break;
        if (wt == 0) {
            unsigned long long v;
            if (!pb_varint(b, n, &off, &v)) break;
            snprintf(lb, sizeof(lb), "%sPB f=%u varint=%llu", tag, f, v);
            file_append(lb);
            (*count)++;
        } else if (wt == 1) {
            if (off + 8 > n) break;
            unsigned long long v;
            memcpy(&v, b + off, 8);
            off += 8;
            snprintf(lb, sizeof(lb), "%sPB f=%u fixed64=%llu", tag, f, v);
            file_append(lb);
            (*count)++;
        } else if (wt == 5) {
            if (off + 4 > n) break;
            unsigned v;
            memcpy(&v, b + off, 4);
            off += 4;
            snprintf(lb, sizeof(lb), "%sPB f=%u fixed32=%u", tag, f, v);
            file_append(lb);
            (*count)++;
        } else if (wt == 2) {
            unsigned long long L;
            if (!pb_varint(b, n, &off, &L)) break;
            if (L > (unsigned long long)(n - off)) break;
            long m = L > 40 ? 40 : (long)L;
            int pr = 0;
            for (long q = 0; q < m; q++) { unsigned char c = b[off+q]; if (c >= 32 && c < 127) pr++; }
            if (m > 0 && pr * 100 / m >= 60) {
                char tx[44];
                memcpy(tx, b + off, (size_t)m);
                tx[m] = 0;
                snprintf(lb, sizeof(lb), "%sPB f=%u str[%llu]='%s'%s", tag, f, L, tx, L > 40 ? "..." : "");
            } else snprintf(lb, sizeof(lb), "%sPB f=%u bytes[%llu]", tag, f, L);
            file_append(lb);
            (*count)++;
            if (depth < 1 && L >= 2 && L <= 64) {
                long so = 0;
                unsigned long long st;
                if (pb_varint(b + off, (long)L, &so, &st) && (st >> 3) >= 1 && (st >> 3) <= 64 && (st & 7) <= 5)
                    pb_fields(tag, b + off, (long)L, depth + 1, count);
            }
            off += (long)L;
        } else break;
    }
}
static void pb_walk(const char *tag, const unsigned char *b, long blen) {
    if (!tag || !b || blen < 8) return;
    long n = blen > 256 ? 256 : blen;
    if (!mem_readable(b, (size_t)n)) return;
    { unsigned long long st; long so = 0;
      if (!pb_varint(b, n, &so, &st) || (st >> 3) < 1 || (st >> 3) > 2047 || (st & 7) > 5) return; }
    int c = 0;
    pb_fields(tag, b, n, 0, &c);
    if (c > 0) { char sb[96]; snprintf(sb, sizeof(sb), "%sPB fields=%d", tag, c); file_append(sb); }
}
static void repdump_call(int idx, const char *phase, long r, long *av) {
    unsigned k = __sync_fetch_and_add(&repcap_[idx], 1);
    if (k >= 40 && (k % 20)) return;
    if (in_repdump) return;
    in_repdump = 1;
    lastrep_idx = idx;
    lastrep_tid = mytid();
    lastrep_ms = now_ms();
    { size_t pl = 0; while (pl < 7 && phase[pl]) { lastrep_phase[pl] = phase[pl]; pl++; } lastrep_phase[pl] = 0; }
    if (pthread_mutex_trylock(&attr_mx) == 0) {
        modTag((unsigned long)__builtin_return_address(0), lastrep_cs, sizeof(lastrep_cs));
        pthread_mutex_unlock(&attr_mx);
    } else lastrep_cs[0] = 0;
    int bare = rep_bare_check();
    char hb[256];
    snprintf(hb, sizeof(hb), "repget tid=%d %s %s ret=%ld a0=0x%lx a1=0x%lx a2=0x%lx a3=0x%lx",
        mytid(), rep_names[idx], phase, r, av[0], av[1], av[2], av[3]);
    LOGE("%s", hb);
    file_append(hb);
    for (int i = 0; i < 4; i++) repdump_arg(idx, phase, i, av[i]);
    if (idx == 13 && phase[1] == 'o' && av[0] == 14) {
        unsigned long a = (unsigned long)av[1];
        unsigned long pg0 = a & ~0xFFFUL, pg1 = (a + 63) & ~0xFFFUL;
        if (a && msync((void *)pg0, 4096, MS_ASYNC) == 0 && (pg1 == pg0 || msync((void *)pg1, 4096, MS_ASYNC) == 0)) {
            char vb[65];
            memcpy(vb, (const void *)a, 64);
            vb[64] = 0;
            int printable = 0;
            for (int q = 0; q < 64 && vb[q]; q++) if (vb[q] >= 32 && vb[q] < 127) printable++;
            if (printable > 3) {
                char vl[128];
                snprintf(vl, sizeof(vl), "anogs ver=%s", vb);
                LOGE("%s", vl);
                file_append(vl);
                if (!anogs_ver[0]) {
                    strncpy(anogs_ver, vb, 63);
                    anogs_ver[63] = 0;
                } else if (strcmp(anogs_ver, vb)) {
                    char vc[160];
                    snprintf(vc, sizeof(vc), "anogs verchg %s -> %s", anogs_ver, vb);
                    LOGE("%s", vc);
                    file_append(vc);
                    strncpy(anogs_ver, vb, 63);
                    anogs_ver[63] = 0;
                }
            }
        }
    }
    if (idx == 13 && phase[1] == 'o' && av[0] == 70) {
        unsigned long a = (unsigned long)av[1];
        unsigned long pg0 = a & ~0xFFFUL, pg1 = (a + 127) & ~0xFFFUL;
        if (a && msync((void *)pg0, 4096, MS_ASYNC) == 0 && (pg1 == pg0 || msync((void *)pg1, 4096, MS_ASYNC) == 0)) {
            static unsigned w70[32];
            static int w70init = 0;
            unsigned cur[32];
            memcpy(cur, (const void *)a, 128);
            if (!w70init) { memcpy(w70, cur, 128); w70init = 1; }
            for (int w = 0; w < 32; w++) if (cur[w] != w70[w]) {
                char cb[160];
                snprintf(cb, sizeof(cb), "ioctl70chg w%d %u->%u", w, w70[w], cur[w]);
                LOGE("%s", cb);
                file_append(cb);
                w70[w] = cur[w];
            }
            {
                char fh[300];
                for (int l = 0; l < 2; l++) {
                    int p = snprintf(fh, sizeof(fh), "ioctl70full %d%c", l, l ? ':' : ' ');
                    for (int q = 0; q < 16 && p < (int)sizeof(fh) - 9; q++) {
                        unsigned v = cur[l * 16 + q];
                        p += snprintf(fh + p, sizeof(fh) - (size_t)p, " %08x", v);
                    }
                    LOGE("%s", fh);
                    file_append(fh);
                }
            }
        }
    }
    if ((idx >= 0 && idx <= 3) || idx == 7) {
        int ispost = phase[1] == 'o';
        char tag[64];
        snprintf(tag, sizeof(tag), "REPORT %s %s", rep_names[idx], phase);
        for (int i = 0; i < 4; i++) {
            unsigned long a = (unsigned long)av[i];
            if (a < 4096 && a > (unsigned long)-4096) continue;
            if (!mem_readable((const void *)a, 16)) continue;
            long blen = 0;
            int blenarg = -1;
            for (int j = 0; j < 4; j++)
                if (j != i && av[j] > 0 && av[j] <= 2048) { blen = av[j]; blenarg = j; break; }
            if (!blen) blen = 256;
            unsigned char fbb[16];
            memcpy(fbb, (const void *)a, 16);
            {
                char fp[33];
                for (int f = 0; f < 16; f++) {
                    fp[f * 2] = "0123456789abcdef"[fbb[f] >> 4];
                    fp[f * 2 + 1] = "0123456789abcdef"[fbb[f] & 15];
                }
                fp[32] = 0;
                unsigned hle = 0;
                memcpy(&hle, fbb, 4);
                unsigned hbe = ((unsigned)fbb[0] << 24) | ((unsigned)fbb[1] << 16) |
                    ((unsigned)fbb[2] << 8) | (unsigned)fbb[3];
                char hs[64];
                hs[0] = 0;
                {
                    int p = 0;
                    if (hle > 0 && hle <= (unsigned)blen)
                        p += snprintf(hs + p, sizeof(hs) - (size_t)p, " HEADER_LEN=0x%x", hle);
                    if (hbe > 0 && hbe <= (unsigned)blen && hbe != hle)
                        p += snprintf(hs + p, sizeof(hs) - (size_t)p, " HEADER_BE=0x%x", hbe);
                }
                char fq[32];
                rep_tick();
                if (ispost && idx <= 3) { anogs_set_state(1, "getreport"); report_fired(); }
                rep_freq(fq, sizeof(fq));
                char shx[65];
                shx[0] = 0;
                rep_sha_note((const unsigned char *)a, (size_t)blen > 2048 ? 2048 : (size_t)blen, shx);
                char csb[96];
                csb[0] = 0;
                if (pthread_mutex_trylock(&attr_mx) == 0) {
                    modTag((unsigned long)__builtin_return_address(0), csb, sizeof(csb));
                    pthread_mutex_unlock(&attr_mx);
                }
                if (ispost && shx[0] && idx >= 0 && idx < 20)
                    rep_diffk(idx, evseq + 1, rep_names[idx], (const unsigned char *)a, blen, shx);
                char hb[560];
                snprintf(hb, sizeof(hb), "REPORT seq=%u %s %s a%d=0x%lx claimed_len=%ld%s real_dump=%ld %s fp=%s sha=%s ret=%ld(%s) %s%s%s%s",
                    __sync_add_and_fetch(&evseq, 1), rep_names[idx], phase, i, a, blen,
                    blenarg >= 0 ? "" : "(default)", blen,
                    blen > 512 ? "LARGE" : blen > 128 ? "MEDIUM" : "SMALL", fp, shx[0] ? shx : "-",
                    r, ret_meaning(r), fq, hs, csb[0] ? " cs=" : "", csb[0] ? csb : "");
                file_append(hb);
                ctx_save(hb);
                rep_hist[blen <= 64 ? 0 : blen <= 128 ? 1 : blen <= 256 ? 2 :
                    blen <= 512 ? 3 : blen <= 1024 ? 4 : blen <= 2048 ? 5 : 6]++;
                {
                    unsigned hn = __sync_add_and_fetch(&rephist_n, 1);
                    if (ispost && blen > 512) {
                        char bc[224];
                        snprintf(bc, sizeof(bc), "=== BAN-CANDIDATE seq=%u LARGE-REPORT %s fp=%s ===",
                            __sync_add_and_fetch(&evseq, 1), rep_names[idx], fp);
                        bancand_emit(bc, "LARGE-REPORT");
                        rep_hist_line();
                    } else if (hn % 50 == 0) {
                        rep_hist_line();
                    }
                }
            }
            if (!bare) dump_buf(tag, (const void *)a, (size_t)blen);
            if (!bare && !dump_hot && ispost && mem_readable((const void *)a, 16)) {
                report_pattern(evseq, (const unsigned char *)a, blen);
                report_follow(evseq, (const unsigned char *)a, blen);
                annotate_buf("REPORT-ANN", (const void *)a, (size_t)blen);
                pb_walk("REPORT", (const unsigned char *)a, blen);
            }
            if (blen > 512) {
                if (!bare) dump_buf("REPORT-X", (const void *)(a + (unsigned long)blen), 1024);
            }
            else if (!is_zero_fp(fbb, 16)) {
                char sm[128];
                snprintf(sm, sizeof(sm), "REPORT INTERESTING seq=%u fp=%02x%02x%02x%02x... len=%ld",
                    evseq, fbb[0], fbb[1], fbb[2], fbb[3], blen);
                file_append(sm);
                if (blen < 1024) {
                    char mark[96];
                    snprintf(mark, sizeof(mark), "REPORT-X seq=%u NONZERO-FP extra dump (%lu bytes)",
                        evseq, (unsigned long)(1024 - blen));
                    if (!bare) {
                        file_append(mark);
                        dump_buf("REPORT-X", (const void *)(a + (unsigned long)blen), (size_t)(1024 - blen));
                    }
                }
            }
            if (ispost) sieve("report", (const unsigned char *)a, blen > 4096 ? 4096 : blen);
        }
    }
    if (idx == 12 || idx == 13) {
        char fq[32];
        if ((int)av[0] == 0x46) rep_tick();
        if ((int)av[0] == 0x46 && phase[1] == 'o') { anogs_set_state(1, "cmd46"); report_fired(); }
        rep_freq(fq, sizeof(fq));
        char ishx[65];
        ishx[0] = 0;
        unsigned long ixa = (unsigned long)av[1];
        if (ixa && (int)av[0] == 0x46)
            rep_sha_note((const unsigned char *)ixa, 1024, ishx);
        char icsb[96];
        icsb[0] = 0;
        if (pthread_mutex_trylock(&attr_mx) == 0) {
            modTag((unsigned long)__builtin_return_address(0), icsb, sizeof(icsb));
            pthread_mutex_unlock(&attr_mx);
        }
        if (phase[1] == 'o' && (int)av[0] == 0x46 && ishx[0] && idx >= 0 && idx < 20)
            rep_diffk(idx, evseq + 1, rep_names[idx], (const unsigned char *)ixa, 256, ishx);
        char hb[480];
        snprintf(hb, sizeof(hb), "IOCTL seq=%u %s cmd=0x%lx (%s) arg=0x%lx sha=%s ret=%ld(%s) %s%s%s",
            __sync_add_and_fetch(&evseq, 1), rep_names[idx], (unsigned long)av[0], ioctl_name((int)av[0]),
            (unsigned long)av[1], ishx[0] ? ishx : "-", r, ret_meaning(r), fq,
            icsb[0] ? " cs=" : "", icsb[0] ? icsb : "");
            file_append(hb);
            ctx_save(hb);
        if (phase[1] == 'o' && ((int)av[0] == 0x46 || (int)av[0] == 0x47 || (int)av[0] == 0x48)) {
            char bc[160];
            snprintf(bc, sizeof(bc), "=== BAN-CANDIDATE seq=%u IOCTL-%s ===",
                __sync_add_and_fetch(&evseq, 1), ioctl_name((int)av[0]));
            bancand_emit(bc, "IOCTL-report");
            rep_hist_line();
        }
        unsigned long a = (unsigned long)av[1];
        if (a && mem_readable((const void *)a, 16)) {
            char tag[80];
            snprintf(tag, sizeof(tag), "IOCTL-%s cmd=0x%lx (%s)",
                phase[1] == 'r' ? "IN" : "OUT",
                (unsigned long)av[0], ioctl_name((int)av[0]));
            if (!bare) dump_ioctl_report(tag, (int)av[0], (const void *)a, 1024);
            if (!bare && phase[1] == 'o' && (int)av[0] == 0x46) {
                annotate_buf("IOCTL-ANN", (const void *)a, 128);
                pb_walk("IOCTL", (const void *)a, 256);
            }
        }
    }
    in_repdump = 0;
}
#define REPDUMP_WRAP(i) \
static long wrap_rep##i(long a0, long a1, long a2, long a3, long a4, long a5, long a6, long a7) { \
    hkEnter(100 + (i)); \
    long av[8] = {a0, a1, a2, a3, a4, a5, a6, a7}; \
    repdump_call(i, "pre", 0, av); \
    long (*rf)(long, long, long, long, long, long, long, long) = (void *)real_rep[i]; \
    if (!rf) return 0; \
    long r = rf(a0, a1, a2, a3, a4, a5, a6, a7); \
    repdump_call(i, "post", r, av); \
    return r; \
}
REPDUMP_WRAP(0)
REPDUMP_WRAP(1)
REPDUMP_WRAP(2)
REPDUMP_WRAP(3)
REPDUMP_WRAP(4)
REPDUMP_WRAP(5)
REPDUMP_WRAP(6)
REPDUMP_WRAP(7)
REPDUMP_WRAP(8)
REPDUMP_WRAP(9)
REPDUMP_WRAP(10)
REPDUMP_WRAP(11)
REPDUMP_WRAP(12)
REPDUMP_WRAP(13)
REPDUMP_WRAP(14)
REPDUMP_WRAP(15)
REPDUMP_WRAP(16)
REPDUMP_WRAP(17)
REPDUMP_WRAP(18)
REPDUMP_WRAP(19)
static void *rep_wraps[20] = {(void *)wrap_rep0, (void *)wrap_rep1,
    (void *)wrap_rep2, (void *)wrap_rep3, (void *)wrap_rep4, (void *)wrap_rep5,
    (void *)wrap_rep6, (void *)wrap_rep7, (void *)wrap_rep8, (void *)wrap_rep9,
    (void *)wrap_rep10, (void *)wrap_rep11, (void *)wrap_rep12, (void *)wrap_rep13,
    (void *)wrap_rep14, (void *)wrap_rep15, (void *)wrap_rep16, (void *)wrap_rep17,
    (void *)wrap_rep18, (void *)wrap_rep19};
static void *repWrapFor(const char *sym, void *r) {
    int i = repIdx(sym);
    if (i < 0 || !r) return NULL;
    real_rep[i] = r;
    return rep_wraps[i];
}
static int dlsymWatch(const char *s) {
    if (!s || !s[0]) return 0;
    static const char *kws[] = {"report", "complaint", "scan", "cheat", "hack", "ban",
        "suspend", "integrity", "tdm", "anosdk", "detect", "violat", "signature", "regist", NULL};
    for (int w = 0; kws[w]; w++) {
        const char *kw = kws[w];
        size_t kl = strlen(kw);
        for (const char *p = s; *p; p++) {
            size_t i = 0;
            while (i < kl && p[i]) {
                char a = p[i], b = kw[i];
                if (a >= 'A' && a <= 'Z') a += 32;
                if (a != b) break;
                i++;
            }
            if (i == kl && (p == s || p[-1] == '_' || p[-1] == '/' || p[-1] == '.')) return 1;
        }
    }
    return 0;
}
static void *real_invoke = NULL;
static const char *(*real_mname)(void *) = NULL;
static unsigned invoke_n = 0;
static void *invokeImpl(void *a0, void *a1, void *a2, void *a3) {
    unsigned k = __sync_fetch_and_add(&invoke_n, 1);
    char mn[128];
    mn[0] = 0;
    if (a0 && real_mname) {
        unsigned long ma = (unsigned long)a0;
        if (msync((void *)(ma & ~0xFFFUL), 4096, MS_ASYNC) == 0) {
            const char *n = real_mname(a0);
            if (n && msync((void *)(((unsigned long)n) & ~0xFFFUL), 4096, MS_ASYNC) == 0) {
                strncpy(mn, n, 120);
                mn[120] = 0;
            }
        }
    }
    int hot = 0;
    if (mn[0]) {
        char lw[128];
        int i;
        for (i = 0; mn[i] && i < 120; i++) {
            char c = mn[i];
            lw[i] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
        }
        lw[i] = 0;
        if (strstr(lw, "ban") || strstr(lw, "suspend") || strstr(lw, "violat") || strstr(lw, "punish") || strstr(lw, "cheat") || strstr(lw, "kick") || strstr(lw, "dialog") || strstr(lw, "popup") || strstr(lw, "account") || strstr(lw, "verdict") || strstr(lw, "penalt")) hot = 1;
    }
    if (((k < 40 || k % 20 == 0) || hot) && !in_log) {
        char ib[320];
        snprintf(ib, sizeof(ib), "invoke tid=%d m=%s obj=%p%s", mytid(), mn[0] ? mn : "?", a1, hot ? " HOT" : "");
        LOGE("%s", ib);
        file_append(ib);
    }
    if (real_invoke) {
        void *(*rf)(void *, void *, void *, void *) = real_invoke;
        return rf(a0, a1, a2, a3);
    }
    return NULL;
}
static int syspropImpl(const char *name, char *value) {
    hkEnter(55);
    int r = old_sysprop ? old_sysprop(name, value) : 0;
    if (!in_log && name) {
        char pb[256];
        snprintf(pb, sizeof(pb), "sysprop %s=%.128s", name, value ? value : "(null)");
        LOGE("%s", pb);
        file_append(pb);
    }
    return r;
}
static void *dlsymImpl(void *handle, const char *sym) {
    hkEnter(34);
    if (dlsymInteresting(sym) && !in_log) nlog("dlsym", sym);
    void *r = old_dlsym(handle, sym);
    if (r && sym) {
        void *w = repWrapFor(sym, r);
        if (w) {
            if (!in_log) {
                char wb[256];
                snprintf(wb, sizeof(wb), "repwatch %s -> wrapper (real %p)", sym, r);
                LOGE("%s", wb);
                file_append(wb);
            }
            { int ri = repIdx(sym);
              if (ri == 17 || ri == 18) {
                  char sw[256];
                  snprintf(sw, sizeof(sw), "=== SIGWATCH %s resolved -> wrapper (real %p) ===", sym, r);
                  LOGE("%s", sw);
                  if (!in_log) { file_append(sw); evlog(sw); }
              } }
            return w;
        }
    }
    if (r && sym && !in_log) {
        const char *htag = NULL;
        for (int k = 0; k < asym_n; k++) {
            if (!strcmp(asym_[k].name, sym)) { htag = "anogs"; break; }
        }
        if (!htag) {
            for (int k = 0; k < esym_n; k++) {
                if (!strcmp(esym_[k].name, sym)) { htag = "engine"; break; }
            }
        }
        if (htag) {
            char mb[160];
            if (pthread_mutex_trylock(&attr_mx) == 0) {
                modTag((unsigned long)r, mb, sizeof(mb));
                pthread_mutex_unlock(&attr_mx);
            } else mb[0] = 0;
            char xb[448];
            snprintf(xb, sizeof(xb), "xres HIT %s %s -> %p %s", htag, sym, r, mb[0] ? mb : "?");
            LOGE("%s", xb);
            file_append(xb);
        }
    }
    if (r && sym && !strcmp(sym, "il2cpp_runtime_invoke") && !real_invoke) {        real_invoke = r;
        if (!in_log) {
            char ab[96];
            snprintf(ab, sizeof(ab), "invoke_armed %p", r);
            LOGE("%s", ab);
            file_append(ab);
        }
        return r;
    }
    if (r && sym && !strcmp(sym, "il2cpp_method_get_name") && !real_mname) {
        real_mname = (void *)r;
        return r;
    }
    if (r && sym && !strcmp(sym, "UnitySendMessage")) {
        usm_real = (void (*)(const char *, const char *, const char *))r;
        if (!usm_armed) {
            usm_armed = 1;
            if (!in_log) {
                char ab[96];
                snprintf(ab, sizeof(ab), "usm_armed %p", r);
                LOGE("%s", ab);
                file_append(ab);
            }
        }
        return r;
    }
    if (r && sym && dlsymWatch(sym) && !in_log) {
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        char wb[512];
        snprintf(wb, sizeof(wb), "watch HIT %s -> %p%s", sym, r, at);
        LOGE("%s", wb);
        file_append(wb);
    }
    if (r && dlsymInteresting(sym) && !in_log) {
        char mb[160];
        if (pthread_mutex_trylock(&attr_mx) == 0) {
            modTag((unsigned long)r, mb, sizeof(mb));
            pthread_mutex_unlock(&attr_mx);
        } else mb[0] = 0;
        char buf[448];
        snprintf(buf, sizeof(buf), "dlsym_ret %s -> %p %s", sym, r, mb[0] ? mb : "?");
        LOGE("%s", buf);
        file_append(buf);
    }
    if (r && sym && !strcmp(sym, "eglSwapBuffers") && !in_log) {
        extern void **ffkOldSwapAddr(void);
        void **swslot = ffkOldSwapAddr();
        if (swslot && !*swslot) *swslot = r;
        char sb[96];
        snprintf(sb, sizeof(sb), "swap_dlsym %p", r);
        LOGE("%s", sb);
        file_append(sb);
        extern unsigned int ffkSwapBuffers(void *, void *);
        return (void *)ffkSwapBuffers;
    }
    if (r && sym && !in_log && (!strcmp(sym, "eglSwapBuffersWithDamageKHR") || !strcmp(sym, "eglSwapBuffersWithDamageEXT"))) {
        if (!old_swapDamage) old_swapDamage = r;
        char sb[96];
        snprintf(sb, sizeof(sb), "swap_dlsym_damage %p %s", r, sym);
        LOGE("%s", sb);
        file_append(sb);
        return (void *)ffkSwapDamageImpl;
    }
    return r;
}

int (*old_ioctl)(int, unsigned long, void *);
static unsigned ioctl_seen[1024];
static int ioctlImpl(int fd, unsigned long req, void *arg) {
    hkEnter(49);
    unsigned c = (fd >= 0 && fd < 1024) ? ++ioctl_seen[fd] : 999;
    if (c <= 12) {
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        char buf[320];
        snprintf(buf, sizeof(buf), "ioctl fd=%d req=0x%lx%s", fd, req, at);
        LOGE("%s", buf);
        file_append(buf);
    }
    return old_ioctl(fd, req, arg);
}

void (*old_UnitySendMessage)(const char *, const char *, const char *);
static char usm_last[256];
static unsigned usm_rep = 0;
static void UnitySendMessageImpl(const char *obj, const char *method, const char *msg) {
    hkEnter(50);
    char key[256];
    snprintf(key, sizeof(key), "%.100s|%.100s", obj ? obj : "?", method ? method : "?");
    if (!strcmp(key, usm_last)) {
        usm_rep++;
    } else {
        if (usm_rep) {
            char rb[320];
            snprintf(rb, sizeof(rb), "usmsame %s x%u", usm_last, usm_rep + 1);
            LOGE("%s", rb);
            file_append(rb);
        }
        strncpy(usm_last, key, sizeof(usm_last) - 1);
        usm_last[sizeof(usm_last) - 1] = 0;
        usm_rep = 0;
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        char buf[1536];
        size_t ml = msg ? strnlen(msg, 1024) : 0;
        char mcpy[1025];
        if (ml) { strncpy(mcpy, msg, ml); mcpy[ml] = 0; } else mcpy[0] = 0;
        snprintf(buf, sizeof(buf), "usm %s m=%s%s", key, mcpy, at);
        LOGE("%s", buf);
        file_append(buf);
        if (msg && ml) sieve("usm", (const unsigned char *)msg, (long)ml);
    }
    if (usm_real) usm_real(obj, method, msg);
    else if (old_UnitySendMessage) old_UnitySendMessage(obj, method, msg);
}

int (*old_pthread_create)(void *, const void *, void *(*)(void *), void *);
static int pthread_createImpl(void *t, const void *a, void *(*fn)(void *), void *arg) {
    hkEnter(35);
    char buf[320];
    char mb[192];
    mb[0] = 0;
    if (fn && pthread_mutex_trylock(&attr_mx) == 0) {
        char tmp[160];
        modTag((unsigned long)fn, tmp, sizeof(tmp));
        pthread_mutex_unlock(&attr_mx);
        if (tmp[0]) snprintf(mb, sizeof(mb), " mod=%s", tmp);
    }
    snprintf(buf, sizeof(buf), "thread start=%p%s", (void *)fn, mb);
    LOGE("%s", buf);
    file_append(buf);
    return old_pthread_create(t, a, fn, arg);
}

static unsigned sslw_n = 0, sslr_n = 0, mbw_n = 0, mbr_n = 0;

static void tlslog(const char *dir, long n, const unsigned char *data, int withHex) {
    char hx[97];
    char msg[384];
    if (withHex && data && n > 0) {
        long m = n > 48 ? 48 : n;
        static const char *h = "0123456789abcdef";
        for (long i = 0; i < m; i++) {
            hx[i * 2] = h[data[i] >> 4];
            hx[i * 2 + 1] = h[data[i] & 15];
        }
        hx[m * 2] = 0;
    } else hx[0] = 0;
    snprintf(msg, sizeof(msg), "%s n=%ld hx=%s", dir, n, hx);
    LOGE("%s", msg);
    file_append(msg);
}

int (*old_SSL_write)(void *, const void *, int);
static int SSL_writeImpl(void *s, const void *b, int n) {
    hkEnter(36);
    if (n > 0 && b) sslTap('O', (const unsigned char *)b, n);
    return old_SSL_write(s, b, n);
}

int (*old_SSL_read)(void *, void *, int);
static int SSL_readImpl(void *s, void *b, int n) {
    hkEnter(37);
    int r = old_SSL_read(s, b, n);
    if (r > 0 && b) sslTap('I', (const unsigned char *)b, r);
    return r;
}

int (*old_mbedtls_ssl_write)(void *, const unsigned char *, unsigned long);
static int mbedtls_ssl_writeImpl(void *c_, const unsigned char *b, unsigned long n) {
    hkEnter(38);
    unsigned c = __sync_add_and_fetch(&mbw_n, 1);
    if (n > 0 && 0 && (c <= 20 || c % 200 == 0))
        tlslog("tls_plain out", (long)n, b, c <= 20);
    return old_mbedtls_ssl_write(c_, b, n);
}

int (*old_mbedtls_ssl_read)(void *, unsigned char *, unsigned long);
static int mbedtls_ssl_readImpl(void *c_, unsigned char *b, unsigned long n) {
    hkEnter(39);
    int r = old_mbedtls_ssl_read(c_, b, n);
    if (r > 0) {
        unsigned c = __sync_add_and_fetch(&mbr_n, 1);
        if (0 && (c <= 20 || c % 200 == 0))
            tlslog("tls_plain in", (long)r, b, c <= 20);
    }
    return r;
}

void (*old_exit)(int);
static void exitImpl(int code) {
    hkEnter(40);
    if (1) {
        char bt[640];
        deathBt(bt, sizeof(bt));
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        char buf[1024];
        snprintf(buf, sizeof(buf), "proc_exit exit code=%d%s bt=%s", code, at, bt);
        LOGE("%s", buf);
        file_append(buf);
        dumpRing();
        time_to_ban("exit");
        ctx_dump("process-death");
    }
    old_exit(code);
}
void (*old__exit)(int);
static void _exitImpl(int code) {
    hkEnter(41);
    if (1) {
        char bt[640];
        deathBt(bt, sizeof(bt));
        char buf[768];
        snprintf(buf, sizeof(buf), "proc_exit _exit code=%d bt=%s", code, bt);
        LOGE("%s", buf);
        file_append(buf);
        dumpRing();
        time_to_ban("_exit");
        ctx_dump("process-death");
    }
    old__exit(code);
}
void (*old_abort)(void);
static void abortImpl(void) {
    hkEnter(42);
    if (1) {
        char bt[640];
        deathBt(bt, sizeof(bt));
        char buf[768];
        snprintf(buf, sizeof(buf), "proc_exit abort bt=%s", bt);
        LOGE("%s", buf);
        file_append(buf);
        dumpRing();
        time_to_ban("abort");
        ctx_dump("process-death");
    }
    old_abort();
}
int (*old_kill)(pid_t, int);
static int killImpl(pid_t pid, int sig) {
    hkEnter(43);
    if (1) {
        char bt[640];
        deathBt(bt, sizeof(bt));
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        char buf[1024];
        snprintf(buf, sizeof(buf), "kill pid=%d sig=%d%s bt=%s", (int)pid, sig, at, bt);
        LOGE("%s", buf);
        file_append(buf);
        dumpRing();
        time_to_ban("kill");
    }
    return old_kill(pid, sig);
}
void (*old_pthread_exit)(void *);
static void pthread_exitImpl(void *v) {
    hkEnter(44);
    if (1) {
        char bt[640];
        deathBt(bt, sizeof(bt));
        char buf[768];
        snprintf(buf, sizeof(buf), "proc_exit pthread_exit bt=%s", bt);
        LOGE("%s", buf);
        file_append(buf);
        dumpRing();
    }
    old_pthread_exit(v);
}
int (*old___android_log_print)(int, const char *, const char *, ...);
static int (*vprint_)(int, const char *, const char *, va_list) = NULL;
static int alogImpl(int prio, const char *tag, const char *fmt, ...) {
    hkEnter(46);
    char msg[2048];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt ? fmt : "", ap);
    if (!in_log && tag && tag[0] && strcmp(tag, "FFKN") != 0 &&
            !(tag[0] == 'F' && tag[1] == 'F' && tag[2] == 'K')) {
        if (1) {
            char line[2300];
            snprintf(line, sizeof(line), "alog %d %s %s", prio, tag, msg);
            LOGE("%s", line);
            file_append(line);
        }
        sieve("alog", (const unsigned char *)msg, (long)strlen(msg));
    }
    int r;
    if (!vprint_ && old_dlsym)
        vprint_ = (int (*)(int, const char *, const char *, va_list))old_dlsym(RTLD_DEFAULT, "__android_log_vprint");
    if (vprint_) {
        va_list aq;
        va_copy(aq, ap);
        r = vprint_(prio, tag, fmt ? fmt : "", aq);
        va_end(aq);
    } else {
        r = old___android_log_print(prio, tag, "%s", msg);
    }
    va_end(ap);
    return r;
}
size_t (*old_fwrite)(const void *, size_t, size_t, FILE *);
static size_t fwriteImpl(const void *p, size_t sz, size_t n, FILE *f) {
    hkEnter(47);
    if (!in_log && p && sz && n) {
        unsigned long total = (unsigned long)sz * n;
        if (total >= 4)
            sieve("fwrite", (const unsigned char *)p, total > 4096 ? 4096 : (long)total);
    }
    return old_fwrite(p, sz, n, f);
}
int (*old_fputs)(const char *, FILE *);
static int fputsImpl(const char *s, FILE *f) {
    hkEnter(48);
    if (!in_log && s) {
        size_t l = strnlen(s, 513);
        if (l >= 6) sieve("fputs", (const unsigned char *)s, l > 4096 ? 4096 : (long)l);
    }
    return old_fputs(s, f);
}
int (*old_dlclose)(void *);
static int dlcloseImpl(void *h) {
    hkEnter(45);
    if (!in_log && h) {
        char buf[128];
        snprintf(buf, sizeof(buf), "dlclose %p", h);
        LOGE("%s", buf);
        file_append(buf);
    }
    return old_dlclose(h);
}
int (*old_close_range)(unsigned, unsigned, int);
static int close_rangeImpl(unsigned fd, unsigned max, int flags) {
    hkEnter(21);
    int r = old_close_range(fd, max, flags);
    unsigned lo = fd < 1024 ? fd : 1024, hi = max < 1024 ? max : 1024;
    for (unsigned i = lo; i <= hi && i < 1024; i++) { fdp_[i][0] = 0; repwc_[i] = 0; }
    return r;
}
int (*old_dup2)(int, int);
static int dup2Impl(int o, int n) {
    hkEnter(22);
    int r = old_dup2(o, n);
    if (n >= 0 && n < 1024 && !in_log) {
        fdp_[n][0] = 0; repwc_[n] = 0;
        if (o >= 0 && o < 1024 && fdp_[o][0]) {
            strncpy(fdp_[n], fdp_[o], 191);
            fdp_[n][191] = 0;
            repwc_[n] = repwc_[o];
        }
    }
    return r;
}
int (*old_dup3)(int, int, int);
static int dup3Impl(int o, int n, int flags) {
    hkEnter(23);
    int r = old_dup3(o, n, flags);
    if (n >= 0 && n < 1024 && !in_log) {
        fdp_[n][0] = 0; repwc_[n] = 0;
        if (o >= 0 && o < 1024 && fdp_[o][0]) {
            strncpy(fdp_[n], fdp_[o], 191);
            fdp_[n][191] = 0;
            repwc_[n] = repwc_[o];
        }
    }
    return r;
}
static struct sigaction oldSigSegv, oldSigAbrt;
static int sigInstalled = 0;
struct snapSeg { unsigned long s, e; char base[48]; };
static struct snapSeg snap_[768];
static int snap_n = 0;
static int snap_over = 0;
static int snap_trunc = 0;
static void snapParse(char *ln) {
    if (!ln || !*ln) return;
    unsigned long s = 0, e = 0;
    char *p = ln;
    while (*p == ' ') p++;
    char *q = p;
    while ((*q >= '0' && *q <= '9') || (*q >= 'a' && *q <= 'f') || (*q >= 'A' && *q <= 'F')) {
        unsigned d = (unsigned)(*q <= '9' ? *q - '0' : ((*q) | 32) - 'a' + 10);
        s = s * 16 + d; q++;
    }
    if (*q != '-') return;
    q++;
    char *r = q;
    while ((*r >= '0' && *r <= '9') || (*r >= 'a' && *r <= 'f') || (*r >= 'A' && *r <= 'F')) {
        unsigned d = (unsigned)(*r <= '9' ? *r - '0' : ((*r) | 32) - 'a' + 10);
        e = e * 16 + d; r++;
    }
    if (e <= s) return;
    char *t = r;
    for (int f2 = 0; f2 < 4; f2++) {
        while (*t == ' ' || *t == '\t') t++;
        if (!*t) return;
        while (*t && *t != ' ' && *t != '\t') t++;
    }
    while (*t == ' ' || *t == '\t') t++;
    const char *bn = t;
    if (*t) { const char *sl = strrchr(t, '/'); bn = sl ? sl + 1 : t; }
    if (snap_n < 768) {
        snap_[snap_n].s = s; snap_[snap_n].e = e;
        if (*bn) { int bi = 0; while (bi < 47 && bn[bi]) { snap_[snap_n].base[bi] = bn[bi]; bi++; } snap_[snap_n].base[bi] = 0; }
        else snap_[snap_n].base[0] = 0;
        snap_n++;
    } else snap_over = 1;
}
static void snapPass(int f, int dump) {
    long sfd = syscall(SYS_openat, AT_FDCWD, "/proc/self/maps", O_RDONLY, 0);
    if (sfd < 0) return;
    static char slb[1024];
    int slen = 0;
    for (;;) {
        long n = syscall(SYS_read, sfd, slb + slen, (long)sizeof(slb) - slen);
        if (n <= 0) {
            if (slen > 0) {
                slb[slen] = 0;
                if (dump) { old_write(f, "snapmaps ", 9); old_write(f, slb, (size_t)slen); old_write(f, "\n", 1); }
                else snapParse(slb);
            }
            break;
        }
        long tot = slen + n;
        long ls = 0;
        for (long k = 0; k < tot; k++) {
            if (slb[k] != '\n') continue;
            slb[k] = 0;
            if (dump) { old_write(f, "snapmaps ", 9); old_write(f, slb + ls, (size_t)(k - ls)); old_write(f, "\n", 1); }
            else snapParse(slb + ls);
            ls = k + 1;
        }
        slen = (int)(tot - ls);
        if (slen > 0) memmove(slb, slb + ls, (size_t)slen);
        if (slen >= (int)sizeof(slb)) { slen = 0; snap_trunc = 1; }
    }
    syscall(SYS_close, sfd);
}
static void snapAttr(unsigned long a, char *out, size_t outn) {
    if (!out || outn < 8) return;
    out[0] = 0;
    if (a < 4096) return;
    int best = -1;
    for (int j = 0; j < snap_n; j++) {
        if (snap_[j].s <= a && (best < 0 || snap_[j].s > snap_[best].s)) best = j;
    }
    if (best < 0) { snprintf(out, outn, "0x%lx", a); return; }
    snprintf(out, outn, "%s+0x%lx", snap_[best].base[0] ? snap_[best].base : "[anon]", a - snap_[best].s);
}
static int snapContains(unsigned long a) {
    if (a < 4096) return 0;
    for (int j = 0; j < snap_n; j++)
        if (a >= snap_[j].s && a < snap_[j].e) return 1;
    return 0;
}
static int snapWalk(void **fp0, unsigned long sp, void **pcs, int max) {
    void **fp = fp0;
    int n = 0;
    while (fp && n < max) {
        unsigned long f = (unsigned long)fp;
        if (f < 4096 || (f & 15UL) || f < sp || !snapContains(f) || !snapContains(f + 8)) break;
        void **next = (void **)fp[0];
        void *ret = (void *)fp[1];
        if (!ret) break;
        pcs[n++] = ret;
        if (!next) break;
        unsigned long nf = (unsigned long)next;
        if (nf <= f || nf - f > 0x4000000UL) break;
        fp = next;
    }
    return n;
}
static struct { unsigned long pc; unsigned n; } sgc_[16];
static unsigned sgc_over = 0;
static void ffkSigHandler(int sig, siginfo_t *si, void *uc) {
    (void)uc;
    if (old_open && old_write && old_close) {
        int f = old_open("/sdcard/Download/ffk_crash.txt", O_WRONLY | O_CREAT | O_APPEND, 0666);
        if (f >= 0) {
            char hb[160];
            int hn = snprintf(hb, sizeof(hb), "sig CRASH sig=%d addr=%p tid=%d\n", sig,
                si ? si->si_addr : 0, mytid());
            if (hn > 0) old_write(f, hb, (size_t)hn);
            {
                char pc2[64], cb2[96];
                snprintf(pc2, sizeof(pc2), "/proc/self/task/%d/comm", mytid());
                int cf2 = old_open(pc2, O_RDONLY, 0);
                cb2[0] = 0;
                if (cf2 >= 0) {
                    long cr2 = old_read(cf2, cb2, sizeof(cb2) - 1);
                    if (cr2 > 0) { cb2[cr2] = 0; if (cb2[cr2 - 1] == '\n') cb2[cr2 - 1] = 0; }
                    old_close(cf2);
                }
                char cl2[160];
                int cln = snprintf(cl2, sizeof(cl2), "sigcomm %s\n", cb2[0] ? cb2 : "?");
                if (cln > 0) old_write(f, cl2, (size_t)cln);
            }
            {
                int hid = ffk_cur_hkid;
                const char *hnm = (hid > 0 && hid < 160 && hkNames[hid]) ? hkNames[hid] : "?";
                char hb2[192];
                int hn2 = snprintf(hb2, sizeof(hb2), "sighook id=%d %s\n", hid, hnm);
                if (hn2 > 0) old_write(f, hb2, (size_t)hn2);
            }
            void *pcs[8];
            int npc = 0;
            unsigned long ucp = 0;
            int uok = 0;
#if defined(__aarch64__)
            if (uc) {
                ucontext_t *uu = (ucontext_t *)uc;
                unsigned long ufa = (unsigned long)uu->uc_mcontext.fault_address;
                unsigned long usi = (unsigned long)(si ? si->si_addr : 0);
                if ((sig == SIGSEGV || sig == SIGBUS) && usi && ufa != usi) {
                    char um[96];
                    int un = snprintf(um, sizeof(um), "sigpc=unavailable reason=ucontext-mismatch\n");
                    if (un > 0) old_write(f, um, (size_t)un);
                } else {
                    unsigned long tpc = (unsigned long)uu->uc_mcontext.pc;
                    unsigned long usp = (unsigned long)uu->uc_mcontext.sp;
                    void **ufp = (void **)(unsigned long)uu->uc_mcontext.regs[29];
                    if (tpc >= 4096 && snapContains(tpc)) {
                        ucp = tpc;
                        uok = 1;
                        if (ufp) npc = snapWalk(ufp, usp, pcs, 8);
                    } else {
                        char um[96];
                        int un = snprintf(um, sizeof(um), "sigpc=unavailable reason=pc-unmapped\n");
                        if (un > 0) old_write(f, um, (size_t)un);
                    }
                }
            } else npc = collectPcs(pcs, 8);
#else
            npc = collectPcs(pcs, 8);
#endif
            (void)uok;
            snap_n = 0; snap_over = 0; snap_trunc = 0;
            snapPass(f, 0);
            if (ucp >= 4096) {
                char pa[128];
                snapAttr(ucp, pa, sizeof(pa));
                char pl[192];
                int pn = snprintf(pl, sizeof(pl), "sigpc %s\n", pa[0] ? pa : "?");
                if (pn > 0) old_write(f, pl, (size_t)pn);
            } else if (!uc) {
                const char nu[] = "sigpc=unavailable reason=no-ucontext\n";
                old_write(f, nu, sizeof(nu) - 1);
            }
            if (!npc) {
                const char sbn[] = "sigbt none\n";
                old_write(f, sbn, sizeof(sbn) - 1);
            }
            for (int i = 0; i < npc; i++) {
                unsigned long a = (unsigned long)pcs[i];
                if (a < 4096) continue;
                char mb[128];
                snapAttr(a, mb, sizeof(mb));
                char lb[192];
                int ln = snprintf(lb, sizeof(lb), "sigbt %s\n", mb[0] ? mb : "?");
                if (ln > 0) old_write(f, lb, (size_t)ln);
            }
            {
                unsigned long fa = (unsigned long)(si ? si->si_addr : 0);
                char fa_[128];
                snapAttr(fa, fa_, sizeof(fa_));
                char fb[224];
                int fn2 = snprintf(fb, sizeof(fb), "faultmap %s addr=0x%lx\n", fa_[0] ? fa_ : "?", fa);
                if (fn2 > 0) old_write(f, fb, (size_t)fn2);
            }
            snapPass(f, 1);
            if (snap_over || snap_trunc) {
                char sb[80];
                int sn = snprintf(sb, sizeof(sb), "snapmaps-limited over=%d trunc=%d n=%d\n", snap_over, snap_trunc, snap_n);
                if (sn > 0) old_write(f, sb, (size_t)sn);
            }
            {
                unsigned long scp = ucp ? ucp : (unsigned long)(si ? si->si_addr : 0);
                int found = 0;
                for (int q = 0; q < 16; q++) {
                    if (scp && sgc_[q].pc == scp) { sgc_[q].n++; found = 1; break; }
                    if (!sgc_[q].pc && !found) { sgc_[q].pc = scp; sgc_[q].n = 1; found = 1; break; }
                }
                if (!found) sgc_over++;
                for (int q = 0; q < 16; q++) {
                    if (!sgc_[q].pc) continue;
                    char sc[96];
                    int sn2 = snprintf(sc, sizeof(sc), "sigcnt pc=0x%lx n=%u\n", sgc_[q].pc, sgc_[q].n);
                    if (sn2 > 0) old_write(f, sc, (size_t)sn2);
                }
                if (sgc_over) {
                    char so[48];
                    int so2 = snprintf(so, sizeof(so), "sigcnt-over %u\n", sgc_over);
                    if (so2 > 0) old_write(f, so, (size_t)so2);
                }
            }
                for (int k = 0; k < 64; k++) {
                    if (hk_[k].id) {
                        int hid = hk_[k].id;
                        const char *hn = (hid >= 100 && hid < 120) ? rep_names[hid - 100] : "";
                        char lb[128];
                        int ln2 = snprintf(lb, sizeof(lb), "lk tid=%d id=%d %s\n", hk_[k].tid, hid, hn);
                        if (ln2 > 0) old_write(f, lb, (size_t)ln2);
                    }
                }
            if (lastrep_idx >= 0) {
                char rb[448];
                struct timespec rts;
                clock_gettime(CLOCK_MONOTONIC, &rts);
                long long rnow = (long long)rts.tv_sec * 1000LL + rts.tv_nsec / 1000000LL;
                const char *rn = (lastrep_idx >= 0 && lastrep_idx < 20) ? rep_names[lastrep_idx] : "?";
                int rn2 = snprintf(rb, sizeof(rb), "sigrep idx=%d %s phase=%s tid=%d age_ms=%lld cs=%s sha=%s\n",
                    lastrep_idx, rn, lastrep_phase, lastrep_tid, rnow - lastrep_ms,
                    lastrep_cs[0] ? lastrep_cs : "-",
                    lastrep_sha[0] ? lastrep_sha : "-");
                if (rn2 > 0) old_write(f, rb, (size_t)rn2);
            }
            else { const char srn[] = "sigrep none\n"; old_write(f, srn, sizeof(srn) - 1); }
            if (pthread_mutex_trylock(&ring_mx) == 0) {
                int total = ring_full ? 12 : ring_i;
                for (int k = 0; k < total; k++) {
                    int idx = ring_full ? (ring_i + k) % 12 : k;
                    struct ringEnt *e = &ring_[idx];
                    char rb[256];
                    int rn = snprintf(rb, sizeof(rb), "sigring %s fd=%d %s n=%ld hx=%s t=%lld\n",
                        e->dir, e->fd, e->peer[0] ? e->peer : "?", e->len, e->hx, e->t);
                    if (rn > 0) old_write(f, rb, (size_t)rn);
                }
                pthread_mutex_unlock(&ring_mx);
            }
            {
                unsigned ei = ev_i;
                for (int k = 0; k < 32; k++) {
                    int idx = (int)((ei + (unsigned)k) % 32);
                    if (!evring[idx][0]) continue;
                    char eb[128];
                    int en = snprintf(eb, sizeof(eb), "sigev %s\n", evring[idx]);
                    if (en > 0) old_write(f, eb, (size_t)en);
                }
            }
            if (first_bancand_ms) {
                char tb[128];
                struct timespec tts;
                clock_gettime(CLOCK_MONOTONIC, &tts);
                long long nowc = (long long)tts.tv_sec * 1000LL + tts.tv_nsec / 1000000LL;
                int tn = snprintf(tb, sizeof(tb), "sigtime TIME-TO-BAN delta_ms=%lld\n", nowc - first_bancand_ms);
                if (tn > 0) old_write(f, tb, (size_t)tn);
            }
            { char nb_[96]; int nn_ = snprintf(nb_, sizeof(nb_), "signote sigctx=last-N-anogs-tail not-in-flight-at-crash\n"); if (nn_ > 0) old_write(f, nb_, (size_t)nn_); }
            {
                unsigned ci = ctx_i;
                for (int k = 0; k < 24; k++) {
                    int idx = (int)((ci + (unsigned)k) % 24);
                    if (!ctxring[idx][0]) continue;
                    char cb[224];
                    int cn = snprintf(cb, sizeof(cb), "sigctx %s\n", ctxring[idx]);
                    if (cn > 0) old_write(f, cb, (size_t)cn);
                }
            }
            old_close(f);
        }
    }
    struct sigaction *old = (sig == SIGSEGV) ? &oldSigSegv : &oldSigAbrt;
    if (old->sa_flags & SA_SIGINFO)
        old->sa_sigaction(sig, si, uc);
    else if (old->sa_handler != SIG_DFL && old->sa_handler != SIG_IGN)
        old->sa_handler(sig);
    else {
        signal(sig, SIG_DFL);
        raise(sig);
    }
}
static void installSigChain(void) {
    if (sigInstalled) return;
    sigInstalled = 1;
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = ffkSigHandler;
    sa.sa_flags = SA_SIGINFO | SA_RESTART;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, &oldSigSegv);
    sigaction(SIGABRT, &sa, &oldSigAbrt);
    if (!in_log) { LOGE("sigchain on"); file_append("sigchain on"); }
}
extern unsigned int ffkSwapBuffers(void *, void *);
extern void **ffkOldSwapAddr(void);
struct bhEnt { const char *sym; void *newfn; void **slot; };
static const struct bhEnt bh_libc[] = {
    {"openat64", (void *)openat64Impl, (void **)&old_openat64},
    {"openat", (void *)openatImpl, (void **)&old_openat},
    {"open64", (void *)open64Impl, (void **)&old_open64},
    {"open", (void *)openImpl, (void **)&old_open},
    {"access", (void *)accessImpl, (void **)&old_access},
    {"fopen", (void *)fopenImpl, (void **)&old_fopen},
    {"stat", (void *)statImpl, (void **)&old_stat},
    {"stat64", (void *)stat64Impl, (void **)&old_stat64},
    {"lstat", (void *)lstatImpl, (void **)&old_lstat},
    {"lstat64", (void *)lstat64Impl, (void **)&old_lstat64},
    {"fstatat", (void *)fstatatImpl, (void **)&old_fstatat},
    {"fstatat64", (void *)fstatat64Impl, (void **)&old_fstatat64},
    {"unlink", (void *)unlinkImpl, (void **)&old_unlink},
    {"unlinkat", (void *)unlinkatImpl, (void **)&old_unlinkat},
    {"rename", (void *)renameImpl, (void **)&old_rename},
    {"mkdir", (void *)mkdirImpl, (void **)&old_mkdir},
    {"dlopen", (void *)dlopenImpl, (void **)&old_dlopen},
    {"android_dlopen_ext", (void *)android_dlopen_extImpl, (void **)&old_android_dlopen_ext},
    {"socket", (void *)socketImpl, (void **)&old_socket},
    {"close", (void *)closeImpl, (void **)&old_close},
    {"close_range", (void *)close_rangeImpl, (void **)&old_close_range},
    {"dup2", (void *)dup2Impl, (void **)&old_dup2},
    {"dup3", (void *)dup3Impl, (void **)&old_dup3},
    {"connect", (void *)connectImpl, (void **)&old_connect},
    {"sendto", (void *)sendtoImpl, (void **)&old_sendto},
    {"sendmsg", (void *)sendmsgImpl, (void **)&old_sendmsg},
    {"send", (void *)sendImpl, (void **)&old_send},
    {"recv", (void *)recvImpl, (void **)&old_recv},
    {"recvfrom", (void *)recvfromImpl, (void **)&old_recvfrom},
    {"recvmsg", (void *)recvmsgImpl, (void **)&old_recvmsg},
    {"read", (void *)readImpl, (void **)&old_read},
    {"write", (void *)writeImpl, (void **)&old_write},
    {"getaddrinfo", (void *)getaddrinfoImpl, (void **)&old_getaddrinfo},
    {"dlsym", (void *)dlsymImpl, (void **)&old_dlsym},
    {"pthread_create", (void *)pthread_createImpl, (void **)&old_pthread_create},
    {"SSL_write", (void *)SSL_writeImpl, (void **)&old_SSL_write},
    {"SSL_read", (void *)SSL_readImpl, (void **)&old_SSL_read},
    {"mbedtls_ssl_write", (void *)mbedtls_ssl_writeImpl, (void **)&old_mbedtls_ssl_write},
    {"mbedtls_ssl_read", (void *)mbedtls_ssl_readImpl, (void **)&old_mbedtls_ssl_read},
    {"exit", (void *)exitImpl, (void **)&old_exit},
    {"_exit", (void *)_exitImpl, (void **)&old__exit},
    {"abort", (void *)abortImpl, (void **)&old_abort},
    {"kill", (void *)killImpl, (void **)&old_kill},
    {"pthread_exit", (void *)pthread_exitImpl, (void **)&old_pthread_exit},
    {"dlclose", (void *)dlcloseImpl, (void **)&old_dlclose},
    {"__android_log_print", (void *)alogImpl, (void **)&old___android_log_print},
    {"fwrite", (void *)fwriteImpl, (void **)&old_fwrite},
    {"fputs", (void *)fputsImpl, (void **)&old_fputs},
    {"ioctl", (void *)ioctlImpl, (void **)&old_ioctl},
    {"UnitySendMessage", (void *)UnitySendMessageImpl, (void **)&old_UnitySendMessage},
    {"eglSwapBuffers", (void *)ffkSwapBuffers, (void **)0},
    {"eglSwapBuffersWithDamageKHR", (void *)ffkSwapDamageImpl, (void **)&old_swapDamage},
    {"eglSwapBuffersWithDamageEXT", (void *)ffkSwapDamageImpl, (void **)&old_swapDamage},
    {"eglGetProcAddress", (void *)eglGetProcAddressImpl, (void **)&old_eglGetProcAddress},
    {"__system_property_get", (void *)syspropImpl, (void **)&old_sysprop},
};
static const struct bhEnt bh_anogs[] = {
    {"AnoSDKGetReportData", (void *)wrap_rep0, (void **)&real_rep[0]},
    {"AnoSDKGetReportData2", (void *)wrap_rep1, (void **)&real_rep[1]},
    {"AnoSDKGetReportData3", (void *)wrap_rep2, (void **)&real_rep[2]},
    {"AnoSDKGetReportData4", (void *)wrap_rep3, (void **)&real_rep[3]},
    {"AnoSDKDelReportData", (void *)wrap_rep4, (void **)&real_rep[4]},
    {"AnoSDKDelReportData3", (void *)wrap_rep5, (void **)&real_rep[5]},
    {"AnoSDKDelReportData4", (void *)wrap_rep6, (void **)&real_rep[6]},
    {"AnoSDKOnRecvData", (void *)wrap_rep7, (void **)&real_rep[7]},
    {"AnoSDKInit", (void *)wrap_rep8, (void **)&real_rep[8]},
    {"AnoSDKInitEx", (void *)wrap_rep9, (void **)&real_rep[9]},
    {"AnoSDKSetUserInfo", (void *)wrap_rep10, (void **)&real_rep[10]},
    {"AnoSDKSetUserInfoWithLicense", (void *)wrap_rep11, (void **)&real_rep[11]},
    {"AnoSDKIoctl", (void *)wrap_rep12, (void **)&real_rep[12]},
    {"AnoSDKIoctlOld", (void *)wrap_rep13, (void **)&real_rep[13]},
    {"AnoSDKOnPause", (void *)wrap_rep14, (void **)&real_rep[14]},
    {"AnoSDKOnResume", (void *)wrap_rep15, (void **)&real_rep[15]},
    {"AnoSDKFree", (void *)wrap_rep16, (void **)&real_rep[16]},
    {"AnoSDKOnRecvSignature", (void *)wrap_rep17, (void **)&real_rep[17]},
    {"AnoSDKRegistInfoListener", (void *)wrap_rep18, (void **)&real_rep[18]},
    {"AnoSDKForExport", (void *)wrap_rep19, (void **)&real_rep[19]},
};
static int stL[55];
static int stA[20];
static void *bh_stubL[55];
static void *bh_stubA[20];
static volatile unsigned bh_armed = 0;
static int bh_init_done = 0;
static const char *bh_status_name(int st) {
    switch (st) {
        case 0: return "OK"; case 1: return "UNINIT"; case 2: return "INITERR_INVALID_ARG";
        case 3: return "INITERR_SYM"; case 4: return "INITERR_TASK"; case 5: return "INITERR_HOOK";
        case 6: return "INITERR_ELF"; case 7: return "INITERR_ELF_REFR"; case 8: return "INITERR_TRAMPO";
        case 9: return "INITERR_SIG"; case 10: return "INITERR_DLMTR"; case 11: return "INVALID_ARG";
        case 12: return "UNMATCH_ORIG_FUNC"; case 13: return "NOSYM"; case 14: return "GET_PROT";
        case 15: return "SET_PROT"; case 16: return "SET_GOT"; case 17: return "NEW_TRAMPO";
        case 18: return "APPEND_TRAMPO"; case 19: return "GOT_VERIFY"; case 20: return "REPEATED_FUNC";
        case 21: return "READ_ELF"; case 22: return "CFI_HOOK_FAILED"; case 23: return "ORIG_ADDR";
        case 24: return "INITERR_CFI"; case 25: return "IGNORE"; case 26: return "INITERR_SAFE";
        case 27: return "INITERR_HUB"; case 28: return "OOM"; case 29: return "DUP";
        case 30: return "ERRNO_NOT_FOUND"; case 1000: return "OK-prev-NULL"; default: return "?";
    }
}
static struct { char base[48]; unsigned n; } qmods[16];
static unsigned qmods_over = 0;
static void quiet_mod(const char *caller) {
    const char *b = caller ? strrchr(caller, '/') : NULL;
    b = b ? b + 1 : (caller && caller[0] ? caller : "-");
    for (int i = 0; i < 16; i++) {
        if (qmods[i].base[0] && !strcmp(qmods[i].base, b)) { __atomic_fetch_add(&qmods[i].n, 1, __ATOMIC_RELAXED); return; }
    }
    for (int i = 0; i < 16; i++) {
        if (!qmods[i].base[0]) {
            snprintf(qmods[i].base, sizeof(qmods[i].base), "%.47s", b);
            __atomic_fetch_add(&qmods[i].n, 1, __ATOMIC_RELAXED);
            return;
        }
    }
    __atomic_fetch_add(&qmods_over, 1, __ATOMIC_RELAXED);
}
static unsigned char asym_nosym[20];
extern int bh_task_report_nosym;
extern uintptr_t bh_last_got_slot;
extern const char *bh_last_got_sym;
extern const char *bh_last_got_elf;
static unsigned scan_quiet = 0;
static void hooked_cb(bytehook_stub_t stub, int status, const char *caller, const char *sym, void *newf, void *prev, void *arg) {
    (void)stub;
    (void)newf;
    (void)arg;
    if (!sym) return;
    unsigned nl = (unsigned)(sizeof(bh_libc) / sizeof(bh_libc[0]));
    unsigned na = (unsigned)(sizeof(bh_anogs) / sizeof(bh_anogs[0]));
    int ai = -1;
    for (unsigned j = 0; j < na; j++)
        if (bh_anogs[j].sym && !strcmp(bh_anogs[j].sym, sym)) { ai = (int)j; break; }
    int quiet = (ai < 0 && (status == 13 || status == 21));
    if (quiet) { __sync_fetch_and_add(&scan_quiet, 1); quiet_mod(caller); }
    int stashOk = (bh_last_got_sym && sym && !strcmp(bh_last_got_sym, sym) && bh_last_got_slot &&
        caller && caller[0] && bh_last_got_elf && !strcmp(caller, bh_last_got_elf));
    unsigned long soff = 0;
    int sok = 0;
    char slotowner[160];
    slotowner[0] = 0;
    unsigned long imp_base = 0, imp_end = 0;
    int imp_known = 0;
    int in_range = 0;
    if (stashOk) {
        if (pthread_mutex_trylock(&attr_mx) == 0) {
            const char *cb2 = strrchr(caller, '/');
            cb2 = cb2 ? cb2 + 1 : caller;
            for (int m = 0; m < maps_n; m++) {
                if (!strcmp(baseName(maps_[m].name), cb2)) {
                    if (!imp_known) { imp_base = maps_[m].s; imp_end = maps_[m].e; imp_known = 1; }
                    else {
                        if (maps_[m].s < imp_base) imp_base = maps_[m].s;
                        if (maps_[m].e > imp_end) imp_end = maps_[m].e;
                    }
                    if (!sok && bh_last_got_slot >= maps_[m].s && bh_last_got_slot < maps_[m].e) {
                        soff = (unsigned long)bh_last_got_slot - maps_[m].s;
                        sok = 1;
                    }
                }
            }
            if (!sok && imp_known && (unsigned long)bh_last_got_slot >= imp_base &&
                (unsigned long)bh_last_got_slot < imp_end)
                in_range = 1;
            if (!sok && !in_range)
                modOff((unsigned long)bh_last_got_slot, slotowner, sizeof(slotowner));
            pthread_mutex_unlock(&attr_mx);
        }
    }
    char rv[256];
    if (status == 0 && prev && caller && caller[0]) {
        if (sok) snprintf(rv, sizeof(rv), "plt:%.100s+0x%lx", caller, soff);
        else if (stashOk && in_range) snprintf(rv, sizeof(rv), "plt:%.100s+0x%lx", caller, (unsigned long)bh_last_got_slot - imp_base);
        else if (stashOk && slotowner[0]) snprintf(rv, sizeof(rv), "plt:%.80s slot=%s", caller, slotowner);
        else if (stashOk) snprintf(rv, sizeof(rv), "plt:%.80s slot=0x%lx", caller, (unsigned long)bh_last_got_slot);
        else snprintf(rv, sizeof(rv), "plt:%.100s", caller);
    } else if (stashOk) {
        if (sok) snprintf(rv, sizeof(rv), "fail:%.100s+0x%lx", caller, soff);
        else if (in_range) snprintf(rv, sizeof(rv), "fail:%.100s+0x%lx", caller, (unsigned long)bh_last_got_slot - imp_base);
        else if (slotowner[0]) snprintf(rv, sizeof(rv), "fail:%.60s slot=%s", caller, slotowner);
        else snprintf(rv, sizeof(rv), "fail:%.80s slot=0x%lx", caller, (unsigned long)bh_last_got_slot);
    } else snprintf(rv, sizeof(rv), "none");
    if (stashOk && !sok) {
        if (in_range) {
            char rm[384];
            snprintf(rm, sizeof(rm), "slot-range-miss sym=%s importer=%s slot=0x%lx imp=[0x%lx,0x%lx)",
                sym, caller, (unsigned long)bh_last_got_slot, imp_base, imp_end);
            LOGE("%s", rm);
            file_append(rm);
        } else if (slotowner[0]) {
            char fb[384];
            snprintf(fb, sizeof(fb), "slot-fallback sym=%s importer=%s slot=%s", sym, caller, slotowner);
            LOGE("%s", fb);
            file_append(fb);
        } else {
            char fb[384];
            snprintf(fb, sizeof(fb), "slot-fallback sym=%s importer=%s slot=0x%lx", sym, caller, (unsigned long)bh_last_got_slot);
            LOGE("%s", fb);
            file_append(fb);
        }
    }
    if (!quiet) {
        char cb[560];
        snprintf(cb, sizeof(cb), "bhook cb sym=%s status=%d(%s) resolve_via=%s prev=%p caller=%.64s",
            sym, status, bh_status_name(status == 0 && !prev ? 1000 : status), rv, prev, caller ? caller : "-");
        LOGE("%s", cb);
    }
    int firstOk = (ai >= 0 && status == 0 && prev && stA[ai] != 1);
    if (ai >= 0) {
        if (status == 13) asym_nosym[ai] = 1;
        if (status != 0 || !prev) {
            char bs[320];
            snprintf(bs, sizeof(bs), "bh_scan sym=%s importer=%s result=%s", sym,
                (caller && caller[0]) ? caller : "-", bh_status_name(status));
            LOGE("%s", bs);
            file_append(bs);
        }
    }
    int rec = status + 1;
    if (status == 0 && !prev) rec = 1000;
    for (unsigned i = 0; i < nl; i++) {
        if (bh_libc[i].sym && !strcmp(bh_libc[i].sym, sym)) {
            if (status == 0 && prev) {
                stL[i] = 1;
                if (bh_libc[i].slot) *bh_libc[i].slot = prev;
                else if (!strcmp(sym, "eglSwapBuffers")) { void **s = ffkOldSwapAddr(); if (s) *s = prev; }
                __sync_fetch_and_add(&bh_armed, 1);
            } else if (!stL[i]) stL[i] = rec;
            return;
        }
    }
    for (unsigned j = 0; j < na; j++) {
        if (bh_anogs[j].sym && !strcmp(bh_anogs[j].sym, sym)) {
            if (status == 0 && prev) {
                stA[j] = 1;
                if (bh_anogs[j].slot) { *bh_anogs[j].slot = prev; __sync_fetch_and_add(&bh_armed, 1); }
            } else if (!stA[j]) stA[j] = rec;
            if (firstOk && ai == (int)j && asym_nosym[ai]) {
                char sw[300];
                snprintf(sw, sizeof(sw), "=== SIGWATCH-PLT sym=%s importer=%s prev=NOSYM now=OK %s ===", sym, caller ? caller : "-", rv);
                LOGE("%s", sw);
                file_append(sw);
                evlog(sw);
            }
            return;
        }
    }
}
static long long bh_reg_ms = 0;
static void bh_reg_all(void) {
    unsigned nl = (unsigned)(sizeof(bh_libc) / sizeof(bh_libc[0]));
    unsigned na = (unsigned)(sizeof(bh_anogs) / sizeof(bh_anogs[0]));
    unsigned i;
    for (i = 0; i < nl; i++) {
        bh_stubL[i] = bytehook_hook_all(NULL, bh_libc[i].sym, bh_libc[i].newfn, hooked_cb, NULL);
        if (i + 1 < 160) hkNames[i + 1] = bh_libc[i].sym;
    }
    for (i = 0; i < na; i++) {
        bh_stubA[i] = bytehook_hook_all(NULL, bh_anogs[i].sym, bh_anogs[i].newfn, hooked_cb, NULL);
        if (100 + i < 160) hkNames[100 + i] = bh_anogs[i].sym;
    }
    bh_reg_ms = now_ms();
    { char *rec = bytehook_get_records(4294967295u);
      if (rec && rec[0]) { char rb[2048]; snprintf(rb, sizeof(rb), "bhook rec %.2000s", rec); LOGE("%s", rb); raw_append(rb); } }
}
static void bh_dump_table(void) {
    char lb[256];
    int o = snprintf(lb, sizeof(lb), "bhook tbl");
    unsigned nl = (unsigned)(sizeof(bh_libc) / sizeof(bh_libc[0]));
    unsigned na = (unsigned)(sizeof(bh_anogs) / sizeof(bh_anogs[0]));
    for (unsigned i = 0; i < nl + na; i++) {
        const char *s = i < nl ? bh_libc[i].sym : bh_anogs[i - nl].sym;
        int st = i < nl ? stL[i] : stA[i - nl];
        char eb[96];
        if (st == 0 && (!strcmp(s, "open64") || !strcmp(s, "openat64") || !strcmp(s, "fstatat64")))
            snprintf(eb, sizeof(eb), " %s=n/a-LP64", s);
        else if (st == 0) snprintf(eb, sizeof(eb), " %s=?", s);
        else if (st == 1) snprintf(eb, sizeof(eb), " %s=OK", s);
        else snprintf(eb, sizeof(eb), " %s=F%d", s, st - 1);
        if (o + (int)strlen(eb) >= (int)sizeof(lb) - 1) { LOGE("%s", lb); file_append(lb); o = snprintf(lb, sizeof(lb), "bhook tbl"); }
        o += snprintf(lb + o, sizeof(lb) - o, "%s", eb);
    }
    LOGE("%s", lb); file_append(lb);
    { char qb[512]; int qp = snprintf(qb, sizeof(qb), "quiet_mods over=%u", qmods_over);
      for (int i = 0; i < 16 && qp < (int)sizeof(qb) - 52; i++) {
          if (!qmods[i].base[0]) continue;
          qp += snprintf(qb + qp, sizeof(qb) - (size_t)qp, " %s:%u", qmods[i].base, qmods[i].n);
      }
      LOGE("%s", qb); file_append(qb); }
}
static unsigned bh_last_armed = 0;
static int bh_tbl_done = 0;
static int sig_done = 0;
static int bh_retried = 0;
static void bh_poll_armed(void) {
    if (bh_armed != bh_last_armed) {
        bh_last_armed = bh_armed;
        char ab[64];
        snprintf(ab, sizeof(ab), "bhook armed=%u quiet=%u", bh_armed, scan_quiet);
        LOGE("%s", ab);
        file_append(ab);
        bh_dump_table();
        bh_tbl_done = 1;
    } else if (!bh_tbl_done && bh_reg_ms && now_ms() - bh_reg_ms > 10000) {
        bh_tbl_done = 1;
        bh_dump_table();
    }
    if (!sig_done && (bh_armed > 0 || (proc_start_ms && now_ms() - proc_start_ms > 30000))) {
        sig_done = 1;
        installSigChain();
    }
    if (!bh_retried && bh_reg_ms && now_ms() - bh_reg_ms > 6000) {
        bh_retried = 1;
        if (!bh_armed) {
            LOGE("bhook retry");
            file_append("bhook retry");
            bh_reg_all();
        }
    }
}
static unsigned scan_n = 0;
static unsigned scan_newborn = 0;
static void bh_scanlog(void *elf, void *arg) {
    (void)arg;
    bh_elf_t *e = (bh_elf_t *)elf;
    const char *pn = (e && e->pathname) ? e->pathname : "?";
    int er = (e && e->error) ? 1 : 0;
    char lb[280];
    snprintf(lb, sizeof(lb), "scan_set elf=%s err=%d", pn, er);
    LOGE("%s", lb);
    file_append(lb);
    __sync_fetch_and_add(&scan_n, 1);
}
static void bh_late_newelf(void *elf, void *arg) {
    unsigned n = 0;
    unsigned nl = (unsigned)(sizeof(bh_libc) / sizeof(bh_libc[0]));
    unsigned na = (unsigned)(sizeof(bh_anogs) / sizeof(bh_anogs[0]));
    (void)arg;
    if (!elf) return;
    unsigned a0 = bh_armed;
    for (unsigned i = 0; i < nl; i++) {
        if (bh_stubL[i]) { bh_task_hook_elf(bh_stubL[i], elf); n++; }
    }
    for (unsigned j = 0; j < na; j++) {
        if (bh_stubA[j]) { bh_task_hook_elf(bh_stubA[j], elf); n++; }
    }
    bh_elf_t *e = (bh_elf_t *)elf;
    const char *pn = (e && e->pathname) ? e->pathname : "?";
    int er = (e && e->error) ? 1 : 0;
    unsigned q0 = scan_quiet;
    __sync_fetch_and_add(&scan_newborn, 1);
    { char lb[320]; snprintf(lb, sizeof(lb), "scan_pass elf=%s err=%d stubs=%u armed_d=%d quiet_d=%d newborn=%u", pn, er, n, (int)bh_armed - (int)a0, (int)scan_quiet - (int)q0, scan_newborn); LOGE("%s", lb); file_append(lb); }
}
static void reg_all(void) {
    if (!bh_init_done) {
        bh_init_done = 1;
        int bi = bytehook_init(BYTEHOOK_MODE_AUTOMATIC, true);
        LOGE("bhook ver=%s", bytehook_get_version());
        char bb[96];
        snprintf(bb, sizeof(bb), "bhook init=%d auto", bi);
        LOGE("%s", bb);
        file_append(bb);
        bytehook_add_ignore("libSignatureKiller.so");
        bytehook_add_ignore("libff_utils_.so");
    }
    bh_task_report_nosym = 1;
    bh_reg_all();
    if (!scan_n) {
        bh_elf_manager_iterate(bh_scanlog, NULL);
        char sb[96];
        snprintf(sb, sizeof(sb), "scan_set n_elf=%u", scan_n);
        LOGE("%s", sb);
        file_append(sb);
    }
    {
        char ab[96];
        snprintf(ab, sizeof(ab), "bhook reg slots=%u armed=%u", (unsigned)(sizeof(bh_libc) / sizeof(bh_libc[0]) + sizeof(bh_anogs) / sizeof(bh_anogs[0])), bh_armed);
        LOGE("%s", ab);
        file_append(ab);
    }
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)vm;
    (void)reserved;
    if (!proc_start_ms) proc_start_ms = now_ms();
    reg_all();
    safe_refresh("onload");

    setenv("SSLKEYLOGFILE", "/sdcard/Download/ffk_sslkey.log", 1);
    { int kw = old_open ? old_open("/sdcard/Download/ffk_sslkey.log", O_WRONLY | O_CREAT | O_APPEND, 0666) : -1; if (kw >= 0 && old_close) old_close(kw); char mb[96]; snprintf(mb, sizeof(mb), "v143 keylogw=%d fdhold tid sslring2 fullsslp imgui xres shot noseccomp fixegl swapaddr dlrefresh swapshot chrand syncrefresh sigchain sigmap ioctl70full sieve3 nosites remap ver reportdump ioctlname sizetag anogsfd evseq fp16 bancand nzfp ioctlx claimlen retfreq bhook auto noxhook evring hotthrottle banner nohexflag syslibskip tblreg treeh cbstat rawlog tbl2 shbypass latearm noinvoke swapdlsym lkring swapdamage sha256 annotate pktsha sysprop dedup lkname sigrep cls pb ptx sstat scanset resolvevia clsptr bhscan sigwatchplt atomics slotfail quietkey slotowner relaxed quietmod slotrange crashfix sigvalid fp16 on", kw >= 0); LOGE("%s", mb); file_append(mb); }
    LOGE("ffkn on");
    LOGE("sslkeylog+fullcap on");
    file_append("ffkn on");
    { char vb[160]; snprintf(vb, sizeof(vb), "ffkn v155 bytehook auto noxhook on"); LOGE("%s", vb); file_append(vb); }
    {
        int mn = refreshMaps();
        char mb[96];
        snprintf(mb, sizeof(mb), "maps ok n=%d", mn);
        LOGE("%s", mb);
        file_append(mb);
    }
    setupAnogsIfPresent();
    watcherStart();
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_ff_killer_Killer_hookApkPath(JNIEnv *env, __attribute__((unused)) jclass clazz, jstring apkPath, jstring repPath) {
    apkPath__ = (*env)->GetStringUTFChars(env, apkPath, 0);
    repPath__ = (*env)->GetStringUTFChars(env, repPath, 0);
    if (!proc_start_ms) proc_start_ms = now_ms();
    setenv("SSLKEYLOGFILE", "/sdcard/Download/ffk_sslkey.log", 1);
    { int kw = old_open ? old_open("/sdcard/Download/ffk_sslkey.log", O_WRONLY | O_CREAT | O_APPEND, 0666) : -1; if (kw >= 0 && old_close) old_close(kw); char mb[96]; snprintf(mb, sizeof(mb), "v143 keylogw=%d fdhold tid sslring2 fullsslp imgui xres shot noseccomp fixegl swapaddr dlrefresh swapshot chrand syncrefresh sigchain sigmap ioctl70full sieve3 nosites remap ver reportdump ioctlname sizetag anogsfd evseq fp16 bancand nzfp ioctlx claimlen retfreq bhook auto noxhook evring hotthrottle banner nohexflag syslibskip tblreg treeh cbstat rawlog tbl2 shbypass latearm noinvoke swapdlsym lkring swapdamage sha256 annotate pktsha sysprop dedup lkname sigrep cls pb ptx sstat scanset resolvevia clsptr bhscan sigwatchplt atomics slotfail quietkey slotowner relaxed quietmod slotrange crashfix sigvalid fp16 on", kw >= 0); LOGE("%s", mb); file_append(mb); }
    LOGE("ffkn paths set");
    LOGE("sslkeylog+fullcap on");
    { char vb[160]; snprintf(vb, sizeof(vb), "ffkn v155 bytehook auto noxhook on"); LOGE("%s", vb); file_append(vb); }
    reg_all();
    safe_refresh("apkpath");

    {
        int mn = refreshMaps();
        char mb[96];
        snprintf(mb, sizeof(mb), "maps ok n=%d", mn);
        LOGE("%s", mb);
        file_append(mb);
    }
    setupAnogsIfPresent();
    watcherStart();
}
