LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := SignatureKiller
LOCAL_CFLAGS := -Wall -fvisibility=hidden -w
LOCAL_CPPFLAGS := -w -std=c++17 -fvisibility=hidden -fno-rtti -fno-exceptions -fpermissive
LOCAL_LDFLAGS += -Wl,--gc-sections -llog -landroid -lEGL -lGLESv3 -lGLESv2 -lz
LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv3 -lGLESv2 -lz
LOCAL_SRC_FILES := mt_jni_ffguard.c xhook.c xh_core.c xh_elf.c xh_log.c xh_util.c xh_version.c ffk_imgui.cpp imgui.cpp imgui_draw.cpp imgui_tables.cpp imgui_widgets.cpp imgui_impl_android.cpp imgui_impl_opengl3.cpp
include $(BUILD_SHARED_LIBRARY)
