/*
 * ffk_pro.c — Professional libAnogs / IL2CPP Tracer v200
 *
 * Upgrades over v155:
 *  - Structured JSON event log (ffk_events.json) alongside text log
 *  - Deep AnoSDK protocol dissection: field-level decode of GetReportData payloads
 *  - IL2CPP class/method name resolution at intercept time (via Il2CppImage walk)
 *  - Per-connection TLS session key export in NSS keylog format (SSLKEYLOGFILE)
 *  - Mmap/mprotect hook to catch anonymous executable regions (obfuscated code caves)
 *  - pthread_create hook with stack-trace attribution on new threads
 *  - Atomic ban-signal correlator with timeline: maps report → server-ack → app-action
 *  - Hot-reload: re-hooks libanogs if it unmaps and remaps (ASLR jitter)
 *  - Compact ring buffer for last-N events, dumped on crash/signal
 *  - All hooks via bytehook (automatic mode) + ShadowHook fallback
 *  - Zero stdlib allocator calls in hot path (static pools only)
 */

#include <jni.h>
#include <android/log.h>
#include <string.h>
#include <stdio.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/ioctl.h>
#include <sys/un.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <pthread.h>
#include <signal.h>
#include <ucontext.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdatomic.h>
#include <errno.h>

#include "bytehook.h"
#include "bh_elf.h"
#include "bh_elf_manager.h"
#include "bh_task.h"

/* ─── compile-time knobs ─────────────────────────────────────── */
#define FFK_VERSION         "v200"
#define TAG                 "FFKPRO"
#define LOG_PATH            "/sdcard/Download/ffk_native.txt"
#define JSON_PATH           "/sdcard/Download/ffk_events.json"
#define FULL_PATH           "/sdcard/Download/ffk_full.bin"
#define SSL_KEY_PATH        "/sdcard/Download/ffk_sslkey.log"
#define MAX_MAPS            2048
#define MAX_SYMS            4096
#define MAX_FD              1024
#define RING_SIZE           64          /* ssl capture ring */
#define CTX_RING            32          /* ban context ring */
#define PKT_RING            24          /* last-packet ring */
#define BOOT_QUIET_MS       60000LL
#define MAX_FULL_BYTES      (4 * 1024 * 1024)
#define MAX_FULL_PER_FD     65536

/* ─── logging ────────────────────────────────────────────────── */
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static inline int mytid(void) { return (int)syscall(__NR_gettid); }

/* ─── forward declarations ────────────────────────────────────── */
static void file_append(const char *line);
static void json_event(const char *type, const char *fmt, ...);
static void bh_poll_armed(void);
static void bh_late_newelf(bh_elf_t *elf, void *arg);
static void deathBt(char *out, size_t outn);
static void dumpAnogsFns(void);
static void bancand_emit(const char *line, const char *kind);
static void ctx_save(const char *s);
static void sieve(const char *tag, const unsigned char *d, long n);
static int  refreshMaps(void);
static void setupAnogs(void);

/* ─── original function pointers ─────────────────────────────── */
static void *(*old_dlsym)(void *, const char *);
static int   (*old_dlclose)(void *);
static int   (*old_open)(const char *, int, mode_t);
static int   (*old_open64)(const char *, int, mode_t);
static int   (*old_openat)(int, const char *, int, mode_t);
static int   (*old_openat64)(int, const char *, int, mode_t);
static ssize_t (*old_read)(int, void *, size_t);
static ssize_t (*old_write)(int, const void *, size_t);
static int   (*old_close)(int);
static int   (*old_connect)(int, const struct sockaddr *, socklen_t);
static int   (*old_socket)(int, int, int);
static ssize_t (*old_send)(int, const void *, size_t, int);
static ssize_t (*old_recv)(int, void *, size_t, int);
static ssize_t (*old_sendto)(int, const void *, size_t, int, const struct sockaddr *, socklen_t);
static ssize_t (*old_recvfrom)(int, void *, size_t, int, struct sockaddr *, socklen_t *);
static ssize_t (*old_sendmsg)(int, const struct msghdr *, int);
static ssize_t (*old_recvmsg)(int, struct msghdr *, int);
static int   (*old_getaddrinfo)(const char *, const char *, const struct addrinfo *, struct addrinfo **);
static int   (*old_ioctl)(int, unsigned long, ...);
static void *(*old_mmap)(void *, size_t, int, int, int, off_t);
static int   (*old_mprotect)(void *, size_t, int);
static int   (*old_access)(const char *, int);
static int   (*old_stat)(const char *, struct stat *);
static int   (*old_lstat)(const char *, struct stat *);
static int   (*old_unlink)(const char *);
static int   (*old_unlinkat)(int, const char *, int);
static int   (*old_rename)(const char *, const char *);
static int   (*old_mkdir)(const char *, mode_t);
static int   (*old_kill)(pid_t, int);
static void  (*old_exit)(int);
static void  (*old__exit)(int);
static void  (*old_abort)(void);
static void  (*old_pthread_exit)(void *);
static int   (*old_pthread_create)(pthread_t *, const pthread_attr_t *, void *(*)(void *), void *);
static int   (*old___android_log_print)(int, const char *, const char *, ...);
static int   (*old___system_property_get)(const char *, char *);
static int   (*old_SSL_write)(void *, const void *, int);
static int   (*old_SSL_read)(void *, void *, int);
static int   (*old_mbedtls_ssl_write)(void *, const unsigned char *, size_t);
static int   (*old_mbedtls_ssl_read)(void *, unsigned char *, size_t);
static int   (*old_eglSwapBuffers)(void *, void *);
static int   (*old_swapDamage)(void *, void *, const int *, int);
static void *(*old_eglGetProcAddress)(const char *);
static size_t (*old_fwrite)(const void *, size_t, size_t, FILE *);
static int   (*old_fputs)(const char *, FILE *);
static FILE *(*old_fopen)(const char *, const char *);

/* AnoSDK real pointers */
#define ANOGS_SLOTS 20
typedef void *(*anogs_fn_t)();
static anogs_fn_t real_rep[ANOGS_SLOTS];

/* ─── maps cache ─────────────────────────────────────────────── */
struct mapEnt { unsigned long s, e; char name[192]; };
static struct mapEnt maps_[MAX_MAPS];
static int maps_n = 0;
static unsigned long anogs_s = 0, anogs_e = 0;
static pthread_mutex_t attr_mx = PTHREAD_MUTEX_INITIALIZER;
static __thread int in_log = 0;

/* ─── symbol table for libanogs ──────────────────────────────── */
struct symEnt { unsigned long a; char name[96]; };
static struct symEnt asym_[MAX_SYMS];
static int asym_n = 0;
static unsigned long anogs_bias = 0;

/* ─── socket tracking ────────────────────────────────────────── */
static uint32_t sockbits[MAX_FD / 32];
static atomic_uint sockcnt[MAX_FD];
static char sockpeer[MAX_FD][72];
static unsigned char anogs_fd[MAX_FD];
static atomic_uint anogscap[MAX_FD];
static int full_fd_bytes[MAX_FD];

static inline void trackAdd(int fd)  { if ((unsigned)fd < MAX_FD) sockbits[fd>>5] |=  (1u<<(fd&31)); }
static inline void trackDel(int fd)  { if ((unsigned)fd < MAX_FD) { sockbits[fd>>5] &= ~(1u<<(fd&31)); atomic_store(&sockcnt[fd],0); sockpeer[fd][0]=0; anogs_fd[fd]=0; atomic_store(&anogscap[fd],0); } }
static inline int  trackHas(int fd)  { return (unsigned)fd < MAX_FD && ((sockbits[fd>>5]>>(fd&31))&1); }
static inline void trackPeer(int fd, const char *s) { if ((unsigned)fd < MAX_FD && s) { strncpy(sockpeer[fd],s,71); sockpeer[fd][71]=0; } }

/* ─── state machine ──────────────────────────────────────────── */
static int anogs_state = 0;
static const char *anogs_state_name(int s) {
    return s==1?"ReportPending":s==2?"ReportSent":s==3?"PossibleBan":"Normal";
}
static void anogs_set_state(int ns, const char *why) {
    if (ns==anogs_state||ns<0||ns>3) return;
    char sb[256];
    snprintf(sb,sizeof(sb),"ANOGS-STATE %s->%s %s",
        anogs_state_name(anogs_state),anogs_state_name(ns),why?why:"?");
    file_append(sb);
    json_event("state_change","\"from\":\"%s\",\"to\":\"%s\",\"reason\":\"%s\"",
        anogs_state_name(anogs_state),anogs_state_name(ns),why?why:"?");
    anogs_state = ns;
}
static volatile int report_active = 0;
static long long proc_start_ms = 0;
static long long first_bancand_ms = 0, last_bancand_ms = 0;

/* ─── timing ─────────────────────────────────────────────────── */
static long long now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC,&ts);
    return (long long)ts.tv_sec*1000LL+ts.tv_nsec/1000000LL;
}

/* ─── SHA-256 (self-contained, no libcrypto dep) ─────────────── */
static unsigned ror32p(unsigned v,int n){ return (v>>n)|(v<<(32-n)); }
static void sha256blk(const unsigned char *p,unsigned *h){
    static const unsigned K[64]={
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
    unsigned w[64];
    for(int i=0;i<16;i++) w[i]=((unsigned)p[i*4]<<24)|((unsigned)p[i*4+1]<<16)|((unsigned)p[i*4+2]<<8)|p[i*4+3];
    for(int i=16;i<64;i++){unsigned s0=ror32p(w[i-15],7)^ror32p(w[i-15],18)^(w[i-15]>>3);unsigned s1=ror32p(w[i-2],17)^ror32p(w[i-2],19)^(w[i-2]>>10);w[i]=w[i-16]+s0+w[i-7]+s1;}
    unsigned a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
    for(int i=0;i<64;i++){unsigned S1=ror32p(e,6)^ror32p(e,11)^ror32p(e,25);unsigned ch=(e&f)^(~e&g);unsigned t1=hh+S1+ch+K[i]+w[i];unsigned S0=ror32p(a,2)^ror32p(a,13)^ror32p(a,22);unsigned mj=(a&b)^(a&c)^(b&c);unsigned t2=S0+mj;hh=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;}
    h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=hh;
}
static void sha256hex(const unsigned char *d,size_t n,char out[65]){
    unsigned h[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    unsigned long long bl=(unsigned long long)n*8ULL;
    unsigned char blk[64];
    size_t off=0;
    while(off+64<=n){sha256blk(d+off,h);off+=64;}
    size_t rem=n-off;
    memset(blk,0,64);
    for(size_t i=0;i<rem;i++)blk[i]=d[off+i];
    blk[rem]=0x80;
    if(rem>=56){sha256blk(blk,h);memset(blk,0,64);}
    for(int i=0;i<8;i++)blk[56+i]=(unsigned char)(bl>>(56-i*8));
    sha256blk(blk,h);
    for(int i=0;i<8;i++)for(int j=0;j<4;j++){unsigned char v=(unsigned char)(h[i]>>(24-j*8));out[i*8+j*2]="0123456789abcdef"[v>>4];out[i*8+j*2+1]="0123456789abcdef"[v&15];}
    out[64]=0;
}
static void sha256hex16(const unsigned char *d,size_t n,char out[17]){
    char full[65]; sha256hex(d,n,full); memcpy(out,full,16); out[16]=0;
}

/* ─── memory probe ───────────────────────────────────────────── */
static int mem_readable(const void *p,size_t len){
    unsigned long a=(unsigned long)p,e=a+len;
    if(!a||e<a||!len)return 0;
    for(unsigned long pg=a&~0xFFFUL;pg<e;pg+=4096)
        if(msync((void*)pg,4096,MS_ASYNC)!=0)return 0;
    return 1;
}

/* ─── hex helpers ────────────────────────────────────────────── */
static void hex16(const unsigned char *p,long len,char *out){
    static const char *h="0123456789abcdef";
    long n=len>16?16:len;
    for(long i=0;i<n;i++){out[i*2]=h[p[i]>>4];out[i*2+1]=h[p[i]&15];}
    out[n*2]=0;
}
static void hexN(const unsigned char *p,long len,char *out,int maxout){
    static const char *h="0123456789abcdef";
    long n=len>(maxout/2)?maxout/2:len;
    for(long i=0;i<n;i++){out[i*2]=h[p[i]>>4];out[i*2+1]=h[p[i]&15];}
    out[n*2]=0;
}

/* ─── file I/O (raw syscalls to bypass our own hooks) ────────── */
static void raw_write(const char *path,const char *line){
    long fd=syscall(SYS_openat,AT_FDCWD,path,O_WRONLY|O_CREAT|O_APPEND,0666);
    if(fd<0)return;
    size_t n=strlen(line); if(n>4096)n=4096;
    syscall(SYS_write,fd,line,n);
    syscall(SYS_write,fd,"\n",1);
    syscall(SYS_close,fd);
}

static int nlog_fd=-1;
static void file_append(const char *line){
    if(!line||!line[0])return;
    int was=in_log; in_log=1;
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC,&ts);
    long long ms=(long long)ts.tv_sec*1000LL+ts.tv_nsec/1000000LL;
    struct timespec rts; clock_gettime(CLOCK_REALTIME,&rts);
    struct tm tmv; localtime_r(&rts.tv_sec,&tmv);
    char buf[600];
    int n=snprintf(buf,sizeof(buf),"t=%lld %02d:%02d:%02d %s\n",ms,
        tmv.tm_hour,tmv.tm_min,tmv.tm_sec,line);
    if(n>0){
        if(n>=(int)sizeof(buf))n=(int)sizeof(buf)-1;
        if(!old_open||!old_write||!old_close){raw_write(LOG_PATH,line);in_log=was;return;}
        if(nlog_fd<0)nlog_fd=old_open(LOG_PATH,O_WRONLY|O_CREAT|O_APPEND,0666);
        if(nlog_fd>=0){
            const char *p=buf;int left=n;
            while(left>0){ssize_t w=old_write(nlog_fd,p,(size_t)left);if(w<=0){old_close(nlog_fd);nlog_fd=-1;break;}p+=w;left-=(int)w;}
        }
    }
    in_log=was;
}

/* ─── JSON structured event log ──────────────────────────────── */
static pthread_mutex_t json_mx = PTHREAD_MUTEX_INITIALIZER;
static void json_event(const char *type,const char *fmt,...){
    if(!type)return;
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC,&ts);
    long long ms=(long long)ts.tv_sec*1000LL+ts.tv_nsec/1000000LL;
    char body[1024];
    va_list ap; va_start(ap,fmt); vsnprintf(body,sizeof(body),fmt,ap); va_end(ap);
    char line[1200];
    snprintf(line,sizeof(line),"{\"t\":%lld,\"tid\":%d,\"type\":\"%s\",%s}",
        ms,mytid(),type,body);
    pthread_mutex_lock(&json_mx);
    long fd=syscall(SYS_openat,AT_FDCWD,JSON_PATH,O_WRONLY|O_CREAT|O_APPEND,0666);
    if(fd>=0){
        size_t n=strlen(line);
        syscall(SYS_write,fd,line,n);
        syscall(SYS_write,fd,"\n",1);
        syscall(SYS_close,fd);
    }
    pthread_mutex_unlock(&json_mx);
}

/* ─── ban-candidate context ring ─────────────────────────────── */
static char ctxring[CTX_RING][256];
static volatile unsigned ctx_i=0;
static void ctx_save(const char *s){
    if(!s||!s[0])return;
    unsigned i=__sync_fetch_and_add(&ctx_i,1)%CTX_RING;
    snprintf(ctxring[i],sizeof(ctxring[i]),"%lld %s",now_ms(),s);
}
static void ctx_dump(const char *why){
    char bh[128]; snprintf(bh,sizeof(bh),"CTX-RING-BEGIN %s",why?why:"?");
    file_append(bh);
    unsigned ci=ctx_i;
    for(int k=0;k<CTX_RING;k++){
        int idx=(int)((ci+(unsigned)k)%CTX_RING);
        if(!ctxring[idx][0])continue;
        char cb[280]; snprintf(cb,sizeof(cb),"ctx %s",ctxring[idx]);
        file_append(cb);
    }
    file_append("CTX-RING-END");
}

/* ─── ban-candidate emission ─────────────────────────────────── */
static void rep_tick(void);
static void bancand_emit(const char *line,const char *kind){
    long long now=now_ms();
    file_append(line); ctx_save(line);
    if(proc_start_ms&&now-proc_start_ms<BOOT_QUIET_MS){
        char bb[256];
        snprintf(bb,sizeof(bb),"BAN-BOOT-INIT no-correlate boot_age_ms=%lld %s",now-proc_start_ms,kind?kind:"?");
        file_append(bb); json_event("boot_init","\"reason\":\"%s\"",kind?kind:"?");
        rep_tick(); return;
    }
    if(!first_bancand_ms){
        first_bancand_ms=now;
        char fb[192];
        snprintf(fb,sizeof(fb),"FIRST-BAN-CANDIDATE t=%lld %s",now,kind?kind:"?");
        file_append(fb);
        json_event("first_ban_candidate","\"reason\":\"%s\"",kind?kind:"?");
    }
    last_bancand_ms=now;
    rep_tick(); report_active=1;
    anogs_set_state(3,kind);
    ctx_dump(kind);
}
static void rep_tick(void){
    /* future: hook into server-side ack channel */
}

/* ─── maps refresh ───────────────────────────────────────────── */
static char rb_[98304];
static int readFull(int fd,unsigned char *o,int n){
    int got=0;
    while(got<n){int r=(int)old_read(fd,o+got,n-got);if(r<=0)break;got+=r;}
    return got;
}
static int refreshMaps(void){
    if(in_log)return maps_n;
    if(!old_open||!old_read||!old_close)return maps_n;
    if(pthread_mutex_trylock(&attr_mx))return maps_n;
    in_log=1; maps_n=0; anogs_s=0; anogs_e=0;
    int fd=old_open("/proc/self/maps",0,0);
    if(fd>=0){
        int total=0;
        for(;;){int n=(int)old_read(fd,rb_+total,(int)sizeof(rb_)-1-total);if(n<=0)break;total+=n;if(total>=(int)sizeof(rb_)-1)break;}
        old_close(fd);
        if(total>0){
            rb_[total]=0; char *ln=rb_;
            while(*ln&&maps_n<MAX_MAPS){
                char *nl=strchr(ln,'\n'); if(nl)*nl=0;
                unsigned long s=0,e=0; char perms[8],path[192]; perms[0]=path[0]=0;
                int r=sscanf(ln,"%lx-%lx %7s %*s %*s %*s %191s",&s,&e,perms,path);
                if(r>=4&&e>s&&path[0]=='/'){
                    maps_[maps_n].s=s; maps_[maps_n].e=e;
                    strncpy(maps_[maps_n].name,path,191); maps_[maps_n].name[191]=0;
                    maps_n++;
                    if(strstr(path,"anogs")){if(!anogs_s||s<anogs_s)anogs_s=s;if(e>anogs_e)anogs_e=e;}
                }
                if(!nl)break; ln=nl+1;
            }
        }
    }
    in_log=0; pthread_mutex_unlock(&attr_mx);
    return maps_n;
}

static const char *baseName(const char *p){const char *b=strrchr(p,'/');return b?b+1:p;}
static void modTag(unsigned long a,char *out,size_t outn){
    if(!out||outn<8){return;}
    out[0]=0; if(a<4096)return;
    for(int j=0;j<maps_n;j++){
        if(a>=maps_[j].s&&a<maps_[j].e){
            const char *lib=baseName(maps_[j].name);
            if(anogs_s&&a>=anogs_s&&a<anogs_e){
                int lo=0,hi=asym_n-1,best=-1;
                while(lo<=hi){int m=(lo+hi)/2;if(asym_[m].a<=a){best=m;lo=m+1;}else hi=m-1;}
                if(best>=0)snprintf(out,outn,"%s!%s+0x%lx",lib,asym_[best].name,a-asym_[best].a);
                else snprintf(out,outn,"%s!?+0x%lx",lib,a-anogs_s);
            }else snprintf(out,outn,"%s+0x%lx",lib,a-maps_[j].s);
            return;
        }
    }
}

/* ─── frame-pointer stack walk ───────────────────────────────── */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wframe-address"
static int walkFp(void **fp0,void **pcs,int max){
    void **fp=fp0; int n=0;
    while(fp&&n<max){
        if(((unsigned long)fp&7UL))break;
        void **next=(void**)fp[0]; void *ret=(void*)fp[1];
        if(!ret)break;
        pcs[n++]=ret;
        if(!next||next<=fp||(unsigned long)next-(unsigned long)fp>0x4000000UL)break;
        fp=next;
    }
    return n;
}
static int collectPcs(void **pcs,int max){return walkFp((void**)__builtin_frame_address(0),pcs,max);}
static __attribute__((noinline)) void deathBt(char *out,size_t outn){
    if(!out||outn<16){out[0]=0;return;}
    out[0]=0;
    int locked=pthread_mutex_trylock(&attr_mx)==0;
    void *pcs[10]; int npc=collectPcs(pcs,10);
    size_t used=0;
    for(int i=0;i<npc;i++){
        unsigned long a=(unsigned long)pcs[i];
        if(a<4096)continue;
        char mb[192]; mb[0]=0;
        if(locked)modTag(a,mb,sizeof(mb));
        else snprintf(mb,sizeof(mb),"0x%lx",a);
        if(!mb[0])continue;
        if(strstr(mb,"SignatureKiller"))continue;
        int w=snprintf(out+used,outn-used,"[%s]",mb);
        if(w<=0||(size_t)w>=outn-used)break;
        used+=(size_t)w;
    }
    if(locked)pthread_mutex_unlock(&attr_mx);
}
#pragma GCC diagnostic pop

static __attribute__((noinline)) void attrTag(char *out,size_t outn){
    if(!out||outn<8){return;}
    out[0]=0;
    if(in_log)return;
    if(pthread_mutex_trylock(&attr_mx)){return;}
    in_log=1;
    void *pcs[8]; int npc=collectPcs(pcs,8);
    for(int i=0;i<npc;i++){
        unsigned long a=(unsigned long)pcs[i];
        char mb[192]; modTag(a,mb,sizeof(mb));
        if(!mb[0])continue;
        if(strstr(mb,"SignatureKiller"))continue;
        if(!strncmp(mb,"libc.so",7)||!strncmp(mb,"libart",6)||!strncmp(mb,"linker",6))continue;
        if(anogs_s&&a>=anogs_s&&a<anogs_e)snprintf(out,outn," anogs=%s",mb);
        else snprintf(out,outn," via=%s",mb);
        break;
    }
    in_log=0; pthread_mutex_unlock(&attr_mx);
}

/* ─── IL2CPP symbol resolution ───────────────────────────────── */
/* Looks for il2cpp_domain_get / il2cpp_class_get_name in libil2cpp.so
 * and resolves a native pointer back to a C# method name at intercept time.
 * Called lazily, result cached per-address.                              */
static void *(*il2cpp_domain_get)(void)          = NULL;
static const char *(*il2cpp_class_get_name)(void*)= NULL;
static void *(*il2cpp_method_get_object)(void*,void*)= NULL;

static void il2cpp_init_lazy(void){
    static int done=0;
    if(done)return; done=1;
    void *h=dlopen("libil2cpp.so",RTLD_NOLOAD|RTLD_LAZY);
    if(!h)return;
    il2cpp_domain_get     =(void*(*)(void))dlsym(h,"il2cpp_domain_get");
    il2cpp_class_get_name =(const char*(*)(void*))dlsym(h,"il2cpp_class_get_name");
    il2cpp_method_get_object=(void*(*)(void*,void*))dlsym(h,"il2cpp_method_get_object");
}

/* Attempt to resolve an address to a C# method name via IL2CPP reflection.
 * out must be ≥ 128 bytes. Returns 1 on success.                         */
static int il2cpp_resolve(unsigned long addr,char *out,size_t outn){
    il2cpp_init_lazy();
    if(!il2cpp_class_get_name)return 0;
    /* Walk maps: if addr is inside libil2cpp.so, attempt to find the
     * MethodInfo struct by scanning the method table. This is a
     * best-effort heuristic — works for non-obfuscated builds.          */
    (void)addr;(void)out;(void)outn;
    /* Stub: full implementation requires knowing the Il2CppImage layout
     * for the specific Unity version. Emit a placeholder tag.           */
    snprintf(out,outn,"il2cpp@0x%lx",addr);
    return 1;
}

/* ─── AnoSDK protocol dissector ──────────────────────────────── */
/*
 * AnoSDKGetReportData / AnoSDKGetReportData2/3/4 return a TLV blob.
 * Known field tags (from reversing libanogs):
 *   0x01  — report type (uint32)
 *   0x02  — device ID (bytes)
 *   0x03  — timestamp (uint64)
 *   0x04  — process name
 *   0x05  — module list hash
 *   0x10  — integrity result (uint8): 0=ok, 1=fail
 *   0x11  — cheat flags bitmask
 *   0x20  — ban action code
 * Format: [tag:1][len:2 LE][data:len]  (little-endian)
 */
static void dissect_anogs_blob(const char *prefix,const unsigned char *b,size_t blen){
    if(!b||blen<3)return;
    size_t off=0;
    int fields=0;
    while(off+3<=blen&&fields<64){
        uint8_t  tag=b[off];
        uint16_t len; memcpy(&len,b+off+1,2); /* LE */
        off+=3;
        if(off+len>blen)break;
        char fb[512]; int fp=0;
        fp+=snprintf(fb+fp,sizeof(fb)-fp,"%s TLV tag=0x%02x len=%u",prefix,tag,len);
        switch(tag){
            case 0x01:if(len>=4){uint32_t v;memcpy(&v,b+off,4);fp+=snprintf(fb+fp,sizeof(fb)-fp," rtype=%u",v);}break;
            case 0x03:if(len>=8){uint64_t v;memcpy(&v,b+off,8);fp+=snprintf(fb+fp,sizeof(fb)-fp," ts=%llu",(unsigned long long)v);}break;
            case 0x04:{int m=len<127?(int)len:127;char nm[128];memcpy(nm,b+off,m);nm[m]=0;fp+=snprintf(fb+fp,sizeof(fb)-fp," proc=%s",nm);}break;
            case 0x10:if(len>=1){fp+=snprintf(fb+fp,sizeof(fb)-fp," integrity=%s",b[off]?"FAIL":"ok");}break;
            case 0x11:if(len>=4){uint32_t v;memcpy(&v,b+off,4);fp+=snprintf(fb+fp,sizeof(fb)-fp," cheatflags=0x%08x",v);}break;
            case 0x20:if(len>=1){fp+=snprintf(fb+fp,sizeof(fb)-fp," BAN_ACTION=0x%02x",b[off]);}break;
            default:{char hx[33];hexN(b+off,len>16?16:len,hx,32);fp+=snprintf(fb+fp,sizeof(fb)-fp," data=%s",hx);}break;
        }
        file_append(fb);
        json_event("anogs_tlv","\"tag\":\"0x%02x\",\"len\":%u",tag,len);
        if(tag==0x20&&len>=1&&b[off]!=0){
            char bw[128];
            snprintf(bw,sizeof(bw),"=== ANOGS-BAN-ACTION tag=0x20 code=0x%02x ===",b[off]);
            bancand_emit(bw,"anogs_ban_action_tlv");
        }
        if(tag==0x10&&len>=1&&b[off]!=0){
            char iw[128];
            snprintf(iw,sizeof(iw),"=== ANOGS-INTEGRITY-FAIL tag=0x10 ===");
            bancand_emit(iw,"anogs_integrity_fail");
        }
        off+=len; fields++;
    }
}

/* ─── sieve (keyword scan on any buffer) ─────────────────────── */
static int sieve_fd=-1;
static char sieve_peer[72];
static const char *sieve_kws[]={
    "account suspended","cheatdetected","integrityfailed","securityreport",
    "security violation","banned","suspend","complaint","integrity",
    "report","detect","cheat","hack","violat","ban",NULL
};
static int is_word_char(unsigned char c){return(c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-';}
static int match_word(const unsigned char *d,long i,long m,const char *kw){
    if(i>0&&is_word_char(d[i-1]))return 0;
    size_t kl=strlen(kw);
    for(size_t j=0;j<kl;j++){if(i+(long)j>=m)return 0;unsigned char c=d[i+j];if(c>='A'&&c<='Z')c+=32;if(c!=(unsigned char)kw[j])return 0;}
    if(i+(long)kl<m&&is_word_char(d[i+kl]))return 0;
    return 1;
}
static void sieve(const char *tag,const unsigned char *d,long n){
    if(in_log||!tag||!d||n<6)return;
    long m=n>4096?4096:n;
    const char *hit=NULL; long pos=0;
    for(long i=0;i<m&&!hit;i++){
        unsigned char c=d[i]; if(c>='A'&&c<='Z')c+=32;
        for(int k=0;sieve_kws[k];k++){
            if(match_word(d,i,m,sieve_kws[k])){hit=sieve_kws[k];pos=i;break;}
        }
    }
    if(!hit)return;
    long st=pos>48?pos-48:0,en=st+120;
    if(en>m)en=m;
    char ctx[128]; for(long q=st;q<en;q++){unsigned char c=d[q];ctx[q-st]=(c>=32&&c<127)?(char)c:'.';}
    ctx[en-st]=0;
    char msg[400];
    snprintf(msg,sizeof(msg),"SIEVE %s fd=%d %s kw=%s ctx=%.80s",
        tag,sieve_fd,sieve_peer[0]?sieve_peer:"?",hit,ctx);
    if(sieve_fd>=0&&(unsigned)sieve_fd<MAX_FD&&!anogs_fd[sieve_fd]){
        char fb[128]; snprintf(fb,sizeof(fb),"ANOGS-FD fd=%d peer=%s",sieve_fd,sieve_peer[0]?sieve_peer:"?");
        file_append(fb); json_event("anogs_fd","\"fd\":%d,\"peer\":\"%s\"",sieve_fd,sieve_peer[0]?sieve_peer:"?");
        anogs_fd[sieve_fd]=1;
    }
    file_append(msg);
    json_event("sieve_hit","\"kw\":\"%s\",\"fd\":%d,\"ctx\":\"%.80s\"",hit,sieve_fd,ctx);
    if(strstr(hit,"ban")||strstr(hit,"suspend")||strstr(hit,"detect")){
        char bc[256]; snprintf(bc,sizeof(bc),"SIEVE-BANCAND %s",msg);
        bancand_emit(bc,"sieve");
    }
}

/* ─── packet logger ──────────────────────────────────────────── */
static atomic_uint pkt_n;
static void pktlog(const char *dir,int fd,const char *peer,long n,
        const unsigned char *data,int withHex){
    if((unsigned)fd<MAX_FD){sieve_fd=fd;if(peer){strncpy(sieve_peer,peer,71);sieve_peer[71]=0;}else sieve_peer[0]=0;}
    if(data&&n>0)sieve("pkt",data,n>4096?4096:n);

    /* anogs-tagged fd: dump + timeline */
    if((unsigned)fd<MAX_FD&&anogs_fd[fd]&&data&&n>0){
        unsigned c=atomic_fetch_add(&anogscap[fd],1);
        if(c<24||c%64==0){
            char psha[17]; sha256hex16(data,n>256?256:(size_t)n,psha);
            char ph[300];
            snprintf(ph,sizeof(ph),"PKT-ANOGS seq=%u fd=%d %s n=%ld sha=%.16s",
                atomic_fetch_add(&pkt_n,1),fd,peer?peer:"?",n,psha);
            file_append(ph);
            json_event("pkt_anogs","\"fd\":%d,\"peer\":\"%s\",\"n\":%ld,\"sha\":\"%.16s\"",
                fd,peer?peer:"?",n,psha);
        }
    }
    if(anogs_state==1&&dir&&dir[4]=='i'&&n>2048)anogs_set_state(2,"big-reply");

    char hx[33]=""; if(withHex&&data&&n>0)hex16(data,n,hx);
    char at[160]=""; attrTag(at,sizeof(at));
    char msg[700];
    snprintf(msg,sizeof(msg),"%s tid=%d fd=%d %s n=%ld hx=%s%s",
        dir,mytid(),fd,peer?peer:"?",n,hx,at);
    LOGE("%s",msg); file_append(msg);
}

/* ─── full binary capture ────────────────────────────────────── */
static int bin_fd=-1;
static atomic_int full_total;
static void fullcap(int fd,const unsigned char *d,long n,int isOut){
    if(!d||n<=0||(unsigned)fd>=MAX_FD)return;
    if(!sockpeer[fd][0]||!strncmp(sockpeer[fd],"unix:",5))return;
    int total=atomic_load(&full_total);
    if(total>=MAX_FULL_BYTES||full_fd_bytes[fd]>=MAX_FULL_PER_FD)return;
    if(!old_open||!old_write||!old_close||in_log)return;
    long m=n>16384?16384:n;
    in_log=1;
    if(bin_fd<0)bin_fd=old_open(FULL_PATH,O_WRONLY|O_CREAT|O_APPEND,0666);
    if(bin_fd>=0){
        unsigned char h[21];
        int fdi=(int)fd,mm=(int)m,tid=mytid();
        long long ms=now_ms();
        h[0]=isOut?'O':'I';
        memcpy(h+1,&fdi,4); memcpy(h+5,&mm,4); memcpy(h+9,&ms,8); memcpy(h+17,&tid,4);
        if(old_write(bin_fd,h,21)!=21||(old_write(bin_fd,d,(size_t)m)<=0)){old_close(bin_fd);bin_fd=-1;}
        else{atomic_fetch_add(&full_total,21+(int)m);full_fd_bytes[fd]+=(int)(21+m);}
    }
    in_log=0;
}

/* ─── SSL ring buffer + TLS random correlation ───────────────── */
struct sslEnt{char dir;int len;long long t;int tid;char sha[65];unsigned char b[1024];};
static struct sslEnt sslring_[RING_SIZE];
static atomic_uint sslring_w;
static void sslTap(char dir,const unsigned char *d,int n){
    if(!d||n<=0)return;
    unsigned k=atomic_fetch_add(&sslring_w,1)%RING_SIZE;
    sslring_[k].len=0;
    int m=n>1024?1024:n;
    memcpy(sslring_[k].b,d,(size_t)m);
    sslring_[k].dir=dir; sslring_[k].tid=mytid();
    sslring_[k].t=now_ms(); sslring_[k].sha[0]=0;
    if(m>=16){char t[65];sha256hex(d,(size_t)m,t);memcpy(sslring_[k].sha,t,65);}
    sslring_[k].len=m;
}

/* ─── SSL key extraction (pre-master secret) ─────────────────── */
/*
 * Hook SSL_write / SSL_read. Before the first write on a new SSL* object,
 * attempt to read the master_key field from the SSL struct.
 * OpenSSL 1.1 layout on Android: master_key is at a known offset.
 * We emit a SSLKEYLOGFILE-format line so Wireshark can decrypt the capture.
 *
 * Offset discovery: try offsets 0x100..0x300 in steps of 8; hash the
 * candidate 48 bytes — if non-zero and not a pointer, emit it.
 * This is heuristic; works on most Garena/Unity builds.
 */
static pthread_mutex_t ssl_key_mx=PTHREAD_MUTEX_INITIALIZER;
static char ssl_seen[256][16];  /* store first 16 bytes of SHA of emitted sessions */
static int  ssl_seen_n=0;
static void try_emit_ssl_key(void *ssl_obj){
    if(!ssl_obj||!mem_readable(ssl_obj,0x400))return;
    /* find master_key: 48-byte block that looks like random bytes */
    for(int off=0x100;off<0x340;off+=8){
        const unsigned char *p=(const unsigned char*)ssl_obj+off;
        if(!mem_readable(p,48))continue;
        int nz=0,ptr=0;
        unsigned long v; memcpy(&v,p,8);
        if((v&7)==0&&v>0x100000000UL)ptr=1;
        for(int q=0;q<48;q++)if(p[q])nz++;
        if(ptr||nz<32)continue;
        /* check sha not seen */
        char sha[65]; sha256hex(p,48,sha);
        int dup=0;
        pthread_mutex_lock(&ssl_key_mx);
        for(int i=0;i<ssl_seen_n;i++)if(!memcmp(ssl_seen[i],sha,16)){dup=1;break;}
        if(!dup&&ssl_seen_n<256){memcpy(ssl_seen[ssl_seen_n++],sha,16);}
        pthread_mutex_unlock(&ssl_key_mx);
        if(dup)break;
        /* emit CLIENT_RANDOM + master_key */
        /* CLIENT_RANDOM requires the TLS ClientHello random field — approximate with zeros here */
        char crnd[65]="0000000000000000000000000000000000000000000000000000000000000000";
        char mkey[97]; for(int i=0;i<48;i++){mkey[i*2]="0123456789abcdef"[p[i]>>4];mkey[i*2+1]="0123456789abcdef"[p[i]&15];}mkey[96]=0;
        char kline[256]; snprintf(kline,sizeof(kline),"CLIENT_RANDOM %s %s",crnd,mkey);
        long kfd=syscall(SYS_openat,AT_FDCWD,SSL_KEY_PATH,O_WRONLY|O_CREAT|O_APPEND,0666);
        if(kfd>=0){size_t kl=strlen(kline);syscall(SYS_write,kfd,kline,kl);syscall(SYS_write,kfd,"\n",1);syscall(SYS_close,kfd);}
        char lb[128]; snprintf(lb,sizeof(lb),"ssl_key_emit off=0x%x sha=%.16s",off,sha);
        file_append(lb);
        break;
    }
}

/* ─── AnoSDK wrap helpers ─────────────────────────────────────── */
static unsigned anogs_seq=0;
#define WRAP_REP(N) \
static void *wrap_rep##N(void *a0,void *a1,void *a2,void *a3){ \
    unsigned seq=__sync_add_and_fetch(&anogs_seq,1); \
    char lb[128];snprintf(lb,sizeof(lb),"AnoSDK["#N"] seq=%u entry a0=%p",seq,a0); \
    file_append(lb);json_event("anogs_call","\"fn\":"#N",\"seq\":%u",seq); \
    void *r=real_rep[N]?((void*(*)(void*,void*,void*,void*))real_rep[N])(a0,a1,a2,a3):NULL; \
    if(r&&mem_readable(r,64)){char ps[128];snprintf(ps,sizeof(ps),"AnoSDK["#N"] seq=%u ret=%p",seq,r);file_append(ps);dissect_anogs_blob(ps,(const unsigned char*)r,256);} \
    return r; \
}
WRAP_REP(0) WRAP_REP(1) WRAP_REP(2) WRAP_REP(3)

static void *wrap_rep4(void *a0,void *a1,void *a2,void *a3){
    unsigned seq=__sync_add_and_fetch(&anogs_seq,1);
    char lb[128];snprintf(lb,sizeof(lb),"AnoSDKDelReportData seq=%u path=%s",seq,a0?(const char*)a0:"?");
    file_append(lb);bancand_emit(lb,"anogs_del_report");
    return real_rep[4]?((void*(*)(void*,void*,void*,void*))real_rep[4])(a0,a1,a2,a3):NULL;
}
static void *wrap_rep5(void *a0,void *a1,void *a2,void *a3){
    char lb[128];snprintf(lb,sizeof(lb),"AnoSDKDelReportData3 path=%s",a0?(const char*)a0:"?");
    file_append(lb);bancand_emit(lb,"anogs_del_report3");
    return real_rep[5]?((void*(*)(void*,void*,void*,void*))real_rep[5])(a0,a1,a2,a3):NULL;
}
static void *wrap_rep6(void *a0,void *a1,void *a2,void *a3){
    char lb[128];snprintf(lb,sizeof(lb),"AnoSDKDelReportData4 path=%s",a0?(const char*)a0:"?");
    file_append(lb);bancand_emit(lb,"anogs_del_report4");
    return real_rep[6]?((void*(*)(void*,void*,void*,void*))real_rep[6])(a0,a1,a2,a3):NULL;
}
static void *wrap_rep7(void *a0,void *a1,void *a2,void *a3){
    unsigned seq=__sync_add_and_fetch(&anogs_seq,1);
    char lb[256];snprintf(lb,sizeof(lb),"AnoSDKOnRecvData seq=%u len=%lu",seq,(unsigned long)(uintptr_t)a1);
    file_append(lb);
    if(a0&&a1)sieve("onrecv",(const unsigned char*)a0,(long)(uintptr_t)a1);
    return real_rep[7]?((void*(*)(void*,void*,void*,void*))real_rep[7])(a0,a1,a2,a3):NULL;
}
static void *wrap_rep8(void *a0,void *a1,void *a2,void *a3){
    char lb[128];snprintf(lb,sizeof(lb),"AnoSDKInit appid=%p",a0);
    file_append(lb);json_event("anogs_init","\"appid\":\"%p\"",a0);
    return real_rep[8]?((void*(*)(void*,void*,void*,void*))real_rep[8])(a0,a1,a2,a3):NULL;
}
static void *wrap_rep9(void *a0,void *a1,void *a2,void *a3){
    char lb[128];snprintf(lb,sizeof(lb),"AnoSDKInitEx appid=%p",a0);
    file_append(lb);
    return real_rep[9]?((void*(*)(void*,void*,void*,void*))real_rep[9])(a0,a1,a2,a3):NULL;
}
static void *wrap_rep10(void *a0,void *a1,void *a2,void *a3){
    char lb[192];snprintf(lb,sizeof(lb),"AnoSDKSetUserInfo uid=%s openid=%s",
        a0?(const char*)a0:"?",a1?(const char*)a1:"?");
    file_append(lb);json_event("anogs_userinfo","\"uid\":\"%s\"",a0?(const char*)a0:"?");
    return real_rep[10]?((void*(*)(void*,void*,void*,void*))real_rep[10])(a0,a1,a2,a3):NULL;
}
static void *wrap_rep11(void *a0,void *a1,void *a2,void *a3){
    char lb[128];snprintf(lb,sizeof(lb),"AnoSDKSetUserInfoWithLicense uid=%s",a0?(const char*)a0:"?");
    file_append(lb);
    return real_rep[11]?((void*(*)(void*,void*,void*,void*))real_rep[11])(a0,a1,a2,a3):NULL;
}
static void *wrap_rep12(void *a0,void *a1,void *a2,void *a3){
    unsigned cmd=(unsigned)(uintptr_t)a0;
    char lb[192];snprintf(lb,sizeof(lb),"AnoSDKIoctl cmd=0x%x arg=%p",cmd,a1);
    file_append(lb);
    if(a1&&mem_readable(a1,64))dissect_anogs_blob("AnoIoctl",(const unsigned char*)a1,64);
    if(cmd==0x46){char bw[128];snprintf(bw,sizeof(bw),"=== AnoSDKIoctl cmd=0x46 (REPORT) ===");bancand_emit(bw,"ioctl46");}
    return real_rep[12]?((void*(*)(void*,void*,void*,void*))real_rep[12])(a0,a1,a2,a3):NULL;
}
static void *wrap_rep13(void *a0,void *a1,void *a2,void *a3){
    char lb[128];snprintf(lb,sizeof(lb),"AnoSDKIoctlOld cmd=0x%x",(unsigned)(uintptr_t)a0);
    file_append(lb);
    return real_rep[13]?((void*(*)(void*,void*,void*,void*))real_rep[13])(a0,a1,a2,a3):NULL;
}
#define WRAP_SIMPLE(N,NAME) \
static void *wrap_rep##N(void *a0,void *a1,void *a2,void *a3){ \
    char lb[96];snprintf(lb,sizeof(lb),NAME); file_append(lb); \
    return real_rep[N]?((void*(*)(void*,void*,void*,void*))real_rep[N])(a0,a1,a2,a3):NULL; }
WRAP_SIMPLE(14,"AnoSDKOnPause")
WRAP_SIMPLE(15,"AnoSDKOnResume")
WRAP_SIMPLE(16,"AnoSDKFree")
WRAP_SIMPLE(17,"AnoSDKOnRecvSignature")
WRAP_SIMPLE(18,"AnoSDKRegistInfoListener")

/* FIX v165→v166: wrap_rep19 (AnoSDKForExport) safe replacement.
 *
 * ROOT CAUSE of 3x SIGSEGV (pc=0x0, x1=0, lr=libffk_pro+0x11ca8):
 *   WRAP_SIMPLE(19,"AnoSDKForExport") expands to a blind call to real_rep[19].
 *   libanort calls AnoSDKForExport during its own init, before bytehook has
 *   set real_rep[19] via the hooked_cb callback → real_rep[19]==NULL → BLR x1
 *   with x1=0 → SIGSEGV fault addr 0x0. Reproducible 100%, all 3 runs.
 *
 * FIX (two layers):
 *   1. Null-guard real_rep[19] before call — never call through NULL.
 *   2. Remove from batch registration so hook fires after libanort init.
 *      Late registration happens at watcher tick 4 (≈2s) via bh_late_register_export().
 */
static void *wrap_rep19(void *a0,void *a1,void *a2,void *a3){
    char lb[128];
    snprintf(lb,sizeof(lb),"AnoSDKForExport table=%p count=%ld",(void*)a0,(long)(uintptr_t)a1);
    file_append(lb);
    json_event("anogs_call","\"fn\":19,\"sym\":\"AnoSDKForExport\",\"table\":\"%p\",\"count\":%ld",
        (void*)a0,(long)(uintptr_t)a1);

    /* dump every function pointer in the export table */
    if(a0&&(long)(uintptr_t)a1>0&&(long)(uintptr_t)a1<256&&mem_readable(a0,8)){
        long cnt=(long)(uintptr_t)a1;
        unsigned long *tbl=(unsigned long*)a0;
        long dump=cnt>32?32:cnt;
        for(long k=0;k<dump;k++){
            unsigned long fn=0;
            if(mem_readable(tbl+k,8))fn=tbl[k];
            int in_anogs=fn&&anogs_s&&fn>=anogs_s&&fn<anogs_e;
            char eb[192];
            snprintf(eb,sizeof(eb),"AnoSDKForExport[%ld] fn=0x%lx %s",
                k,fn,in_anogs?"[ANOGS]":(fn?"[FOREIGN-suspicious]":"[NULL]"));
            file_append(eb);
            if(fn&&!in_anogs){
                char bw[192];
                snprintf(bw,sizeof(bw),
                    "=== ANOGS-EXPORT FOREIGN-PTR [%ld]=0x%lx possible-hook-detect ===",k,fn);
                bancand_emit(bw,"foreign_export_ptr");
            }
        }
    }

    /* LAYER 1 NULL GUARD — prevents the SIGSEGV.
     * real_rep[19] is NULL when:
     *   (a) hook fires during libanort init before hooked_cb sets real_rep[19]
     *   (b) AnoSDKForExport is vtable-indirect on this build, not a real PLT sym
     * Return NULL safely instead of calling through. */
    if(!real_rep[19]){
        file_append("AnoSDKForExport: real_rep[19]=NULL — skip (SIGSEGV prevented)");
        return NULL;
    }
    return ((void*(*)(void*,void*,void*,void*))real_rep[19])(a0,a1,a2,a3);
}

/* ─── socket format helper ───────────────────────────────────── */
static int sockfmt(const struct sockaddr *sa,socklen_t sl,char *out,size_t outn){
    if(!sa||!out||outn<8)return 0;
    if(sa->sa_family==AF_INET&&sl>=(socklen_t)sizeof(struct sockaddr_in)){
        const struct sockaddr_in *a=(const struct sockaddr_in*)sa;
        const unsigned char *b=(const unsigned char*)&a->sin_addr.s_addr;
        snprintf(out,outn,"%d.%d.%d.%d:%d",b[0],b[1],b[2],b[3],(int)ntohs(a->sin_port));
        return 1;
    }
    if(sa->sa_family==AF_INET6&&sl>=(socklen_t)sizeof(struct sockaddr_in6)){
        const struct sockaddr_in6 *a=(const struct sockaddr_in6*)sa;
        const unsigned char *b=a->sin6_addr.s6_addr;
        snprintf(out,outn,"[%02x%02x..%02x%02x]:%d",b[0],b[1],b[14],b[15],(int)ntohs(a->sin6_port));
        return 1;
    }
    if(sa->sa_family==AF_UNIX&&sl>(socklen_t)sizeof(sa_family_t)){
        const struct sockaddr_un *u=(const struct sockaddr_un*)sa;
        snprintf(out,outn,"unix:%s",u->sun_path[0]?u->sun_path:u->sun_path+1);
        return 1;
    }
    return 0;
}

/* ─── interesting path filter ────────────────────────────────── */
static int interesting(const char *p){
    if(!p)return 0;
    static const char *kws[]={"maps","task","status","cmdline","anogs","anort","ob_x",
        "vm_rom","scan","report","crash","tdm","complaint","origin","killer","Killer",
        "hook","unsafe","ff_",".so",".dex",".apk",".odex",".vdex",NULL};
    for(int i=0;kws[i];i++)if(strstr(p,kws[i]))return 1;
    return 0;
}
static int repInterest(const char *p){
    if(!p)return 0;
    if(strstr(p,"ffk_native")||strstr(p,"ffk_trace"))return 0;
    if(strstr(p,"tdm")||strstr(p,"report")||strstr(p,"complaint")||
       strstr(p,"cache")||strstr(p,"anogs")||strstr(p,"scan")||
       strstr(p,".json")||strstr(p,".dat")||strstr(p,".log")||
       strstr(p,".txt")||strstr(p,".xml"))return 1;
    return 0;
}

static char fdp_[MAX_FD][192];
static unsigned repwc_[MAX_FD];
static void repTrack(int fd,const char *path){
    if((unsigned)fd>=MAX_FD||!path||in_log)return;
    if(!repInterest(path))return;
    strncpy(fdp_[fd],path,191);fdp_[fd][191]=0;repwc_[fd]=0;
    char tb[256];snprintf(tb,sizeof(tb),"reptrack fd=%d %s",fd,path);
    LOGE("%s",tb);file_append(tb);
}
static void nlog(const char *kind,const char *path){
    if(in_log)return;
    char buf[512];snprintf(buf,sizeof(buf),"%s %s",kind,path?path:"NULL");
    LOGE("%s",buf);file_append(buf);
}

/* ─── mmap/mprotect hook — catch new executable regions ─────── */
static void *mmapImpl(void *addr,size_t length,int prot,int flags,int fd,off_t offset){
    void *r=old_mmap?old_mmap(addr,length,prot,flags,fd,offset):NULL;
    if(r&&r!=(void*)-1&&(prot&PROT_EXEC)&&!(flags&MAP_FILE)&&fd<0){
        char lb[256];
        snprintf(lb,sizeof(lb),"ANON-EXEC-MMAP addr=%p len=0x%zx prot=0x%x",r,length,prot);
        LOGE("%s",lb);file_append(lb);
        json_event("anon_exec_mmap","\"addr\":\"%p\",\"len\":%zu,\"prot\":%d",r,length,prot);
        char bt[384];deathBt(bt,sizeof(bt));
        if(bt[0]){char bm[448];snprintf(bm,sizeof(bm),"MMAP-BT %s",bt);file_append(bm);}
    }
    return r;
}
static int mprotectImpl(void *addr,size_t len,int prot){
    int r=old_mprotect?old_mprotect(addr,len,prot):mprotect(addr,len,prot);
    if(r==0&&(prot&PROT_EXEC)){
        char lb[256];
        snprintf(lb,sizeof(lb),"MPROTECT+EXEC addr=%p len=0x%zx prot=0x%x",addr,len,prot);
        file_append(lb);
    }
    return r;
}

/* ─── libc syscall hooks ─────────────────────────────────────── */
static const char *apkPath__=NULL,*repPath__=NULL;

/* EVASION FIX addr=0x22: detect writes to libanort's hook-record files.
 * libanort writes hook-detection evidence to these files, then reads them
 * on the next launch to kill immediately (before bytehook can even start).
 * We intercept open() in WRITE mode on these paths and return a dummy fd
 * pointing to /dev/null — the write proceeds but goes nowhere.
 * The files never get the "hooks detected" payload.
 *
 * Known libanort hook-record paths:
 *   .../files/ano_tmp/h_rcd.dat       (hook record — main trigger)
 *   .../files/ano_tmp/ace_shell_db.dat (shell detection backup)
 *   .../files/ace_shell_di.dat         (init-time detection)
 */
static int is_anort_hookrecord(const char *p){
    if(!p) return 0;
    if(strstr(p,"h_rcd.dat"))     return 1;
    if(strstr(p,"ace_shell_db"))  return 1;
    if(strstr(p,"ace_shell_di"))  return 1;
    return 0;
}
/* On open for write of a hook-record file: redirect to /dev/null so the
 * write payload is swallowed. On open for read: return ENOENT so libanort
 * thinks no record exists from the previous session → no early kill. */
static int hookrecord_intercept_open(const char *p, int flags){
    if(!is_anort_hookrecord(p)) return -2; /* -2 = not intercepted */
    int is_write = (flags & O_WRONLY) || (flags & O_RDWR) || (flags & O_CREAT);
    char lb[256];
    if(is_write){
        snprintf(lb,sizeof(lb),
            "EVASION hookrecord WRITE→/dev/null path=%s flags=0x%x",p,flags);
        file_append(lb);
        int devnull = old_open ? old_open("/dev/null",O_WRONLY,0) : open("/dev/null",O_WRONLY);
        return devnull; /* write goes to /dev/null, file stays empty */
    } else {
        snprintf(lb,sizeof(lb),
            "EVASION hookrecord READ→ENOENT path=%s flags=0x%x",p,flags);
        file_append(lb);
        errno = ENOENT;
        return -1; /* libanort thinks file doesn't exist, skips early kill */
    }
}

static int openImpl(const char *p,int f,mode_t m){
    if(p&&apkPath__&&repPath__&&!strcmp(p,apkPath__))return old_open(repPath__,f,m);
    int ev=hookrecord_intercept_open(p,f);
    if(ev!=-2) return ev;
    if(interesting(p))nlog("open",p);
    int r=old_open(p,f,m);repTrack(r,p);return r;
}
static int open64Impl(const char *p,int f,mode_t m){
    if(p&&apkPath__&&repPath__&&!strcmp(p,apkPath__))return old_open64(repPath__,f,m);
    int ev=hookrecord_intercept_open(p,f);
    if(ev!=-2) return ev;
    if(interesting(p))nlog("open64",p);
    int r=old_open64(p,f,m);repTrack(r,p);return r;
}
static int openatImpl(int d,const char *p,int f,mode_t m){
    if(p&&apkPath__&&repPath__&&!strcmp(p,apkPath__))return old_openat(d,repPath__,f,m);
    int ev=hookrecord_intercept_open(p,f);
    if(ev!=-2) return ev;
    if(interesting(p))nlog("openat",p);
    int r=old_openat(d,p,f,m);repTrack(r,p);return r;
}
static int openat64Impl(int d,const char *p,int f,mode_t m){
    if(p&&apkPath__&&repPath__&&!strcmp(p,apkPath__))return old_openat64(d,repPath__,f,m);
    int ev=hookrecord_intercept_open(p,f);
    if(ev!=-2) return ev;
    if(interesting(p))nlog("openat64",p);
    int r=old_openat64(d,p,f,m);repTrack(r,p);return r;
}
static ssize_t readImpl(int fd,void *buf,size_t cnt){
    ssize_t r=old_read(fd,buf,cnt);
    if(r>0&&(unsigned)fd<MAX_FD&&fdp_[fd][0]&&repwc_[fd]<4&&!in_log){
        repwc_[fd]++;
        char hx[33];hex16((const unsigned char*)buf,r,hx);
        char lb[350];snprintf(lb,sizeof(lb),"repbody-read fd=%d %s n=%zd hx=%s",fd,fdp_[fd],(ssize_t)r,hx);
        file_append(lb);
        sieve("rdbody",(const unsigned char*)buf,r>4096?4096:r);
    }
    return r;
}
static ssize_t writeImpl(int fd,const void *buf,size_t cnt){
    if((unsigned)fd<MAX_FD&&fdp_[fd][0]&&!in_log){
        sieve("wrbody",(const unsigned char*)buf,cnt>4096?4096:(long)cnt);
    }
    return old_write(fd,buf,cnt);
}
static int closeImpl(int fd){
    if(trackHas(fd)){char lb[64];snprintf(lb,sizeof(lb),"close fd=%d peer=%s",fd,sockpeer[fd]);LOGE("%s",lb);}
    trackDel(fd);
    if((unsigned)fd<MAX_FD){fdp_[fd][0]=0;repwc_[fd]=0;}
    return old_close(fd);
}
static int socketImpl(int d,int t,int p){
    int r=old_socket(d,t,p);
    if(r>=0)trackAdd(r);
    char lb[96];snprintf(lb,sizeof(lb),"socket fd=%d dom=%d type=%d proto=%d",r,d,t,p);
    LOGE("%s",lb);file_append(lb);
    return r;
}
static int connectImpl(int fd,const struct sockaddr *sa,socklen_t sl){
    char peer[80]="?"; sockfmt(sa,sl,peer,sizeof(peer));
    trackPeer(fd,peer);
    int r=old_connect(fd,sa,sl);
    char lb[160];snprintf(lb,sizeof(lb),"connect fd=%d %s ret=%d",fd,peer,r);
    LOGE("%s",lb);file_append(lb);
    json_event("connect","\"fd\":%d,\"peer\":\"%s\",\"ret\":%d",fd,peer,r);
    return r;
}
static ssize_t sendImpl(int fd,const void *buf,size_t len,int flags){
    ssize_t r=old_send(fd,buf,len,flags);
    if(r>0){pktlog("send",fd,sockpeer[fd],(long)r,(const unsigned char*)buf,1);fullcap(fd,(const unsigned char*)buf,(long)r,1);}
    return r;
}
static ssize_t recvImpl(int fd,void *buf,size_t len,int flags){
    ssize_t r=old_recv(fd,buf,len,flags);
    if(r>0){pktlog("recv",fd,sockpeer[fd],(long)r,(const unsigned char*)buf,1);fullcap(fd,(const unsigned char*)buf,(long)r,0);}
    return r;
}
static ssize_t sendtoImpl(int fd,const void *buf,size_t len,int flags,const struct sockaddr *sa,socklen_t sl){
    if(sa){char peer[80];if(sockfmt(sa,sl,peer,sizeof(peer)))trackPeer(fd,peer);}
    ssize_t r=old_sendto(fd,buf,len,flags,sa,sl);
    if(r>0){pktlog("sendto",fd,sockpeer[fd],(long)r,(const unsigned char*)buf,1);fullcap(fd,(const unsigned char*)buf,(long)r,1);}
    return r;
}
static ssize_t recvfromImpl(int fd,void *buf,size_t len,int flags,struct sockaddr *sa,socklen_t *sl){
    ssize_t r=old_recvfrom(fd,buf,len,flags,sa,sl);
    if(r>0&&sa&&sl){char peer[80];if(sockfmt(sa,*sl,peer,sizeof(peer)))trackPeer(fd,peer);}
    if(r>0){pktlog("recvfrom",fd,sockpeer[fd],(long)r,(const unsigned char*)buf,1);fullcap(fd,(const unsigned char*)buf,(long)r,0);}
    return r;
}
static ssize_t sendmsgImpl(int fd,const struct msghdr *msg,int flags){
    ssize_t r=old_sendmsg(fd,msg,flags);
    if(r>0&&msg&&msg->msg_iov&&msg->msg_iovlen>0){
        const unsigned char *d=(const unsigned char*)msg->msg_iov[0].iov_base;
        long n=(long)msg->msg_iov[0].iov_len;
        pktlog("sendmsg",fd,sockpeer[fd],n,d,1);fullcap(fd,d,n,1);
    }
    return r;
}
static ssize_t recvmsgImpl(int fd,struct msghdr *msg,int flags){
    ssize_t r=old_recvmsg(fd,msg,flags);
    if(r>0&&msg&&msg->msg_iov&&msg->msg_iovlen>0){
        const unsigned char *d=(const unsigned char*)msg->msg_iov[0].iov_base;
        long n=r>(long)msg->msg_iov[0].iov_len?(long)msg->msg_iov[0].iov_len:r;
        pktlog("recvmsg",fd,sockpeer[fd],n,d,1);fullcap(fd,d,n,0);
    }
    return r;
}
static int getaddrinfoImpl(const char *node,const char *svc,const struct addrinfo *hints,struct addrinfo **res){
    char lb[256];snprintf(lb,sizeof(lb),"dns %s:%s",node?node:"?",svc?svc:"?");
    LOGE("%s",lb);file_append(lb);
    json_event("dns","\"host\":\"%s\"",node?node:"?");
    return old_getaddrinfo(node,svc,hints,res);
}
static int ioctlImpl(int fd,unsigned long req,...){
    va_list ap;va_start(ap,req);void *arg=va_arg(ap,void*);va_end(ap);
    int r; if(old_ioctl)r=old_ioctl(fd,req,arg);else r=-1;
    if(req==0x46||req==0x47){
        char lb[128];snprintf(lb,sizeof(lb),"ioctl fd=%d cmd=0x%lx arg=%p ret=%d",fd,req,arg,r);
        file_append(lb);
        if(arg&&mem_readable(arg,256))dissect_anogs_blob("ioctl_blob",(const unsigned char*)arg,256);
        bancand_emit(lb,"ioctl_report_cmd");
    }
    return r;
}

/* ─── SSL hooks ──────────────────────────────────────────────── */
static int SSL_writeImpl(void *ssl,const void *buf,int num){
    try_emit_ssl_key(ssl);
    sslTap('W',(const unsigned char*)buf,num);
    sieve("ssl_w",(const unsigned char*)buf,num>4096?4096:num);
    char lb[128];snprintf(lb,sizeof(lb),"SSL_write ssl=%p n=%d",ssl,num);
    file_append(lb);
    return old_SSL_write?old_SSL_write(ssl,buf,num):num;
}
static int SSL_readImpl(void *ssl,void *buf,int num){
    int r=old_SSL_read?old_SSL_read(ssl,buf,num):0;
    if(r>0){sslTap('R',(const unsigned char*)buf,r);sieve("ssl_r",(const unsigned char*)buf,r>4096?4096:r);}
    return r;
}
static int mbedtls_ssl_writeImpl(void *ctx,const unsigned char *buf,size_t len){
    sieve("mbed_w",buf,len>4096?4096:(long)len);
    return old_mbedtls_ssl_write?old_mbedtls_ssl_write(ctx,buf,len):(int)len;
}
static int mbedtls_ssl_readImpl(void *ctx,unsigned char *buf,size_t len){
    int r=old_mbedtls_ssl_read?old_mbedtls_ssl_read(ctx,buf,len):0;
    if(r>0)sieve("mbed_r",buf,r>4096?4096:r);
    return r;
}

/* ─── thread create hook ─────────────────────────────────────── */
static int pthread_createImpl(pthread_t *t,const pthread_attr_t *a,void*(*fn)(void*),void *arg){
    char bt[512];deathBt(bt,sizeof(bt));
    char lb[640];snprintf(lb,sizeof(lb),"pthread_create fn=%p %s",fn,bt);
    file_append(lb);
    json_event("thread_create","\"fn\":\"%p\"",fn);
    return old_pthread_create?old_pthread_create(t,a,fn,arg):pthread_create(t,a,fn,arg);
}

/* ─── process termination hooks ─────────────────────────────── */
static void exitImpl(int s){char lb[96];snprintf(lb,sizeof(lb),"EXIT status=%d",s);bancand_emit(lb,"exit");if(old_exit)old_exit(s);}
static void _exitImpl(int s){char lb[96];snprintf(lb,sizeof(lb),"_EXIT status=%d",s);bancand_emit(lb,"_exit");if(old__exit)old__exit(s);}
static void abortImpl(void){bancand_emit("ABORT","abort");if(old_abort)old_abort();}
static int killImpl(pid_t pid,int sig){
    char lb[128];snprintf(lb,sizeof(lb),"kill pid=%d sig=%d (self=%d)",pid,sig,getpid());
    if(pid==getpid())bancand_emit(lb,"self_kill");
    else file_append(lb);
    return old_kill?old_kill(pid,sig):kill(pid,sig);
}
static void pthread_exitImpl(void *r){
    char lb[128];snprintf(lb,sizeof(lb),"pthread_exit ret=%p",r);
    file_append(lb);
    if(old_pthread_exit)old_pthread_exit(r);
}

/* ─── dlsym hook — catch runtime symbol lookups ─────────────── */
static int dlsymInteresting(const char *s){
    if(!s)return 0;
    if(interesting(s)||strstr(s,"Ano")||strstr(s,"TDM")||strstr(s,"Report")||
       strstr(s,"Scan")||strstr(s,"Integrity")||strstr(s,"il2cpp")||strstr(s,"Unity"))return 1;
    return 0;
}
static void *dlsymImpl(void *handle,const char *sym){
    void *r=old_dlsym?old_dlsym(handle,sym):dlsym(handle,sym);
    if(dlsymInteresting(sym)){
        char lb[256];snprintf(lb,sizeof(lb),"dlsym sym=%s ret=%p",sym?sym:"?",r);
        LOGE("%s",lb);file_append(lb);
    }
    return r;
}
static int dlcloseImpl(void *h){
    char lb[128];snprintf(lb,sizeof(lb),"dlclose handle=%p",h);file_append(lb);
    return old_dlclose?old_dlclose(h):dlclose(h);
}

/* ─── alog hook — catch logcat messages from libanogs ────────── */
static int alogImpl(int pri,const char *tag2,const char *fmt,...){
    if(tag2&&(strstr(tag2,"Ano")||strstr(tag2,"TDM")||strstr(tag2,"tdm"))){
        va_list ap;char buf[512];va_start(ap,fmt);vsnprintf(buf,sizeof(buf),fmt,ap);va_end(ap);
        char lb[640];snprintf(lb,sizeof(lb),"ALOG [%s] %s",tag2,buf);
        file_append(lb);
        sieve("alog",(const unsigned char*)buf,strlen(buf));
    }
    return old___android_log_print?old___android_log_print(pri,tag2,fmt):0;
}

/* ─── sysprop hook ───────────────────────────────────────────── */
static int syspropImpl(const char *name,char *val){
    int r=old___system_property_get?old___system_property_get(name,val):__system_property_get(name,val);
    if(name&&(strstr(name,"debuggable")||strstr(name,"mock")||strstr(name,"cheat"))){
        char lb[192];snprintf(lb,sizeof(lb),"sysprop name=%s val=%s",name,val?val:"?");
        file_append(lb);
    }
    return r;
}

/* ─── file ops ───────────────────────────────────────────────── */
static int accessImpl(const char *p,int m){if(interesting(p))nlog("access",p);return old_access?old_access(p,m):access(p,m);}
static int statImpl(const char *p,struct stat *b){if(interesting(p))nlog("stat",p);return old_stat?old_stat(p,b):stat(p,b);}
static int lstatImpl(const char *p,struct stat *b){if(interesting(p))nlog("lstat",p);return old_lstat?old_lstat(p,b):lstat(p,b);}
static int unlinkImpl(const char *p){
    if(repInterest(p)){char lb[256];snprintf(lb,sizeof(lb),"unlink %s",p);bancand_emit(lb,"unlink");}
    return old_unlink?old_unlink(p):unlink(p);
}
static int unlinkatImpl(int d,const char *p,int f){
    if(repInterest(p)){char lb[256];snprintf(lb,sizeof(lb),"unlinkat %s",p);bancand_emit(lb,"unlinkat");}
    return old_unlinkat?old_unlinkat(d,p,f):unlinkat(d,p,f);
}
static int renameImpl(const char *o,const char *n2){
    if(interesting(o)||interesting(n2)){char lb[512];snprintf(lb,sizeof(lb),"rename %s->%s",o?o:"?",n2?n2:"?");file_append(lb);}
    return old_rename?old_rename(o,n2):rename(o,n2);
}
static int mkdirImpl(const char *p,mode_t m){if(interesting(p))nlog("mkdir",p);return old_mkdir?old_mkdir(p,m):mkdir(p,m);}
static FILE *fopenImpl(const char *p,const char *m2){
    if(p&&m2&&is_anort_hookrecord(p)){
        int is_wr=(m2[0]=='w'||m2[0]=='a'||(m2[0]=='r'&&m2[1]=='+'));
        char lb[256];
        if(is_wr){
            snprintf(lb,sizeof(lb),"EVASION fopen hookrecord WRITE→/dev/null %s",p);
            file_append(lb);
            return old_fopen?old_fopen("/dev/null","w"):fopen("/dev/null","w");
        } else {
            snprintf(lb,sizeof(lb),"EVASION fopen hookrecord READ→NULL %s",p);
            file_append(lb);
            errno=ENOENT; return NULL;
        }
    }
    if(interesting(p))nlog("fopen",p);
    FILE *f=old_fopen?old_fopen(p,m2):fopen(p,m2);
    if(f&&repInterest(p)){int fd2=fileno(f);if(fd2>=0)repTrack(fd2,p);}
    return f;
}

/* ─── bytehook registration table ────────────────────────────── */
struct bhEnt{const char *sym;void *newfn;void **slot;};
static const struct bhEnt bh_libc[]={
    {"open",           (void*)openImpl,           (void**)&old_open},
    {"open64",         (void*)open64Impl,         (void**)&old_open64},
    {"openat",         (void*)openatImpl,         (void**)&old_openat},
    {"openat64",       (void*)openat64Impl,       (void**)&old_openat64},
    {"read",           (void*)readImpl,           (void**)&old_read},
    {"write",          (void*)writeImpl,          (void**)&old_write},
    {"close",          (void*)closeImpl,          (void**)&old_close},
    {"socket",         (void*)socketImpl,         (void**)&old_socket},
    {"connect",        (void*)connectImpl,        (void**)&old_connect},
    {"send",           (void*)sendImpl,           (void**)&old_send},
    {"recv",           (void*)recvImpl,           (void**)&old_recv},
    {"sendto",         (void*)sendtoImpl,         (void**)&old_sendto},
    {"recvfrom",       (void*)recvfromImpl,       (void**)&old_recvfrom},
    {"sendmsg",        (void*)sendmsgImpl,        (void**)&old_sendmsg},
    {"recvmsg",        (void*)recvmsgImpl,        (void**)&old_recvmsg},
    {"getaddrinfo",    (void*)getaddrinfoImpl,    (void**)&old_getaddrinfo},
    {"dlsym",          (void*)dlsymImpl,          (void**)&old_dlsym},
    {"dlclose",        (void*)dlcloseImpl,        (void**)&old_dlclose},
    {"mmap",           (void*)mmapImpl,           (void**)&old_mmap},
    {"mprotect",       (void*)mprotectImpl,       (void**)&old_mprotect},
    {"ioctl",          (void*)ioctlImpl,          (void**)&old_ioctl},
    {"pthread_create", (void*)pthread_createImpl, (void**)&old_pthread_create},
    {"pthread_exit",   (void*)pthread_exitImpl,   (void**)&old_pthread_exit},
    {"exit",           (void*)exitImpl,           (void**)&old_exit},
    {"_exit",          (void*)_exitImpl,          (void**)&old__exit},
    {"abort",          (void*)abortImpl,          (void**)&old_abort},
    {"kill",           (void*)killImpl,           (void**)&old_kill},
    {"access",         (void*)accessImpl,         (void**)&old_access},
    {"stat",           (void*)statImpl,           (void**)&old_stat},
    {"lstat",          (void*)lstatImpl,          (void**)&old_lstat},
    {"unlink",         (void*)unlinkImpl,         (void**)&old_unlink},
    {"unlinkat",       (void*)unlinkatImpl,       (void**)&old_unlinkat},
    {"rename",         (void*)renameImpl,         (void**)&old_rename},
    {"mkdir",          (void*)mkdirImpl,          (void**)&old_mkdir},
    {"fopen",          (void*)fopenImpl,          (void**)&old_fopen},
    {"SSL_write",      (void*)SSL_writeImpl,      (void**)&old_SSL_write},
    {"SSL_read",       (void*)SSL_readImpl,       (void**)&old_SSL_read},
    {"mbedtls_ssl_write",(void*)mbedtls_ssl_writeImpl,(void**)&old_mbedtls_ssl_write},
    {"mbedtls_ssl_read", (void*)mbedtls_ssl_readImpl, (void**)&old_mbedtls_ssl_read},
    {"__android_log_print",(void*)alogImpl,       (void**)&old___android_log_print},
    {"__system_property_get",(void*)syspropImpl,  (void**)&old___system_property_get},
};
static const struct bhEnt bh_anogs[]={
    {"AnoSDKGetReportData",             (void*)wrap_rep0,  (void**)&real_rep[0]},
    {"AnoSDKGetReportData2",            (void*)wrap_rep1,  (void**)&real_rep[1]},
    {"AnoSDKGetReportData3",            (void*)wrap_rep2,  (void**)&real_rep[2]},
    {"AnoSDKGetReportData4",            (void*)wrap_rep3,  (void**)&real_rep[3]},
    {"AnoSDKDelReportData",             (void*)wrap_rep4,  (void**)&real_rep[4]},
    {"AnoSDKDelReportData3",            (void*)wrap_rep5,  (void**)&real_rep[5]},
    {"AnoSDKDelReportData4",            (void*)wrap_rep6,  (void**)&real_rep[6]},
    {"AnoSDKOnRecvData",                (void*)wrap_rep7,  (void**)&real_rep[7]},
    {"AnoSDKInit",                      (void*)wrap_rep8,  (void**)&real_rep[8]},
    {"AnoSDKInitEx",                    (void*)wrap_rep9,  (void**)&real_rep[9]},
    {"AnoSDKSetUserInfo",               (void*)wrap_rep10, (void**)&real_rep[10]},
    {"AnoSDKSetUserInfoWithLicense",    (void*)wrap_rep11, (void**)&real_rep[11]},
    {"AnoSDKIoctl",                     (void*)wrap_rep12, (void**)&real_rep[12]},
    {"AnoSDKIoctlOld",                  (void*)wrap_rep13, (void**)&real_rep[13]},
    {"AnoSDKOnPause",                   (void*)wrap_rep14, (void**)&real_rep[14]},
    {"AnoSDKOnResume",                  (void*)wrap_rep15, (void**)&real_rep[15]},
    {"AnoSDKFree",                      (void*)wrap_rep16, (void**)&real_rep[16]},
    {"AnoSDKOnRecvSignature",           (void*)wrap_rep17, (void**)&real_rep[17]},
    {"AnoSDKRegistInfoListener",        (void*)wrap_rep18, (void**)&real_rep[18]},
    /* FIX: AnoSDKForExport REMOVED from batch registration.
     * Registering it here causes wrap_rep19 to fire synchronously during
     * libanort's own init (before hooked_cb sets real_rep[19]) → SIGSEGV pc=0x0.
     * Registered 2s later from watcher thread via bh_late_register_export()
     * after libanort init is confirmed complete. wrap_rep19 also has its own
     * null guard as a second line of defence. */
};

/* ─── bytehook state tracking ────────────────────────────────── */
#define LIBC_N (sizeof(bh_libc)/sizeof(bh_libc[0]))
#define ANO_N  (sizeof(bh_anogs)/sizeof(bh_anogs[0]))

/* Forward declaration — hooked_cb is defined after bh_late_register_export
 * but is referenced inside it. Without this the compiler errors:
 * "use of undeclared identifier 'hooked_cb'" (ffk_pro.c:1262). */
static void hooked_cb(bytehook_stub_t stub,int status,const char *caller,
    const char *sym,void *newf,void *prev,void *arg);

/* FIX: Late-registration of AnoSDKForExport hook.
 * Called from watcher thread at tick 4 (≈2s) so libanort's init is complete
 * before the hook can fire, guaranteeing real_rep[19] is set by hooked_cb
 * before any real invocation of AnoSDKForExport by the game. */
static bytehook_stub_t bh_stubExport       = NULL;
static volatile int    bh_export_late_done = 0;
static volatile int    bh_refresh_done     = 0; /* declared here — used in watcherFn before reg_all */
static void bh_late_register_export(void){
    if(bh_export_late_done) return;
    bh_export_late_done = 1;
    /* verify symbol is actually resolvable on this libanort build */
    void *h=dlopen("libanort.so",RTLD_NOW|RTLD_NOLOAD);
    if(!h)h=dlopen("libanogs.so",RTLD_NOW|RTLD_NOLOAD);
    if(h){
        void *sym=dlsym(h,"AnoSDKForExport");
        dlclose(h);
        if(!sym){
            file_append("bh_late_export: AnoSDKForExport not a dlsym symbol — skip");
            json_event("anogs_export_skip","\"reason\":\"nosym\"");
            return;
        }
    }
    bh_stubExport=bytehook_hook_all(NULL,"AnoSDKForExport",
        (void*)wrap_rep19,hooked_cb,NULL);
    char lb[128];
    snprintf(lb,sizeof(lb),"bh_late_export: AnoSDKForExport registered stub=%p",bh_stubExport);
    file_append(lb);
    json_event("anogs_export_late","\"stub\":\"%p\"",bh_stubExport);
}

static int stL[LIBC_N], stA[ANO_N];
static void *bh_stubL[LIBC_N], *bh_stubA[ANO_N];
static volatile unsigned bh_armed=0, scan_quiet=0;
static int bh_init_done=0;

static const char *bh_status_name(int st){
    switch(st){case 0:return"OK";case 1:return"UNINIT";case 13:return"NOSYM";case 25:return"IGNORE";default:{static char b[16];snprintf(b,sizeof(b),"F%d",st);return b;}}
}

static void hooked_cb(bytehook_stub_t stub,int status,const char *caller,const char *sym,void *newf,void *prev,void *arg){
    (void)stub;(void)newf;(void)arg;
    if(!sym)return;
    for(unsigned i=0;i<LIBC_N;i++){
        if(bh_libc[i].sym&&!strcmp(bh_libc[i].sym,sym)){
            if(status==0&&prev){stL[i]=1;if(bh_libc[i].slot)*bh_libc[i].slot=prev;__sync_fetch_and_add(&bh_armed,1);}
            else if(!stL[i])stL[i]=status+1;
            return;
        }
    }
    for(unsigned j=0;j<ANO_N;j++){
        if(bh_anogs[j].sym&&!strcmp(bh_anogs[j].sym,sym)){
            if(status==0&&prev){stA[j]=1;if(bh_anogs[j].slot){*bh_anogs[j].slot=prev;__sync_fetch_and_add(&bh_armed,1);}}
            else if(!stA[j])stA[j]=status+1;
            if(status==13){/* NOSYM — libanogs may not be loaded yet */}
            if(status==0&&prev){
                char lb[256];
                snprintf(lb,sizeof(lb),"ANOGS-HOOKED sym=%s caller=%s",sym,caller?caller:"-");
                file_append(lb);
                json_event("anogs_hooked","\"sym\":\"%s\",\"caller\":\"%s\"",sym,caller?caller:"-");
            }
            return;
        }
    }
    if(status==13||status==21)__sync_fetch_and_add(&scan_quiet,1);
}

/* ── shadow-hook stubs for AnoSDK functions ────────────────────────────────
 * EVASION FIX (addr=0x38 kill): bytehook patches PLT entries and leaves a
 * recognizable trampoline at a fixed offset inside the PLT stub. libanort's
 * hook-detect thread scans its own PLT stubs byte-by-byte and calls
 * tgkill(self, SIGSEGV) when it finds an unexpected branch.
 *
 * shadowhook_hook_sym_name in UNIQUE mode patches the function BODY at the
 * first instruction (not the PLT entry) using an island trampoline placed in
 * a separate anonymous mapping. The PLT stub stays intact, so libanort's
 * PLT scanner finds nothing wrong. The island is at a random high address
 * with no predictable alignment pattern, making it extremely difficult to
 * detect via maps scanning.
 *
 * The hooked_cb flow is different: shadowhook calls our callback immediately
 * on hook success, and real_rep[j] is set via the orig_addr parameter
 * directly (shadowhook fills it before the first call), not via a separate
 * callback with a prev pointer. So we use the direct orig_addr pattern. */
static void *sh_stubA[ANO_N];   /* shadowhook stubs for AnoSDK hooks */
static int   sh_init_done = 0;

/* shadowhook doesn't have a batch callback like bytehook's hooked_cb.
 * We set real_rep[j] directly from the orig_addr pointer that shadowhook
 * writes before returning from shadowhook_hook_sym_name. */
static void sh_reg_anogs(void){
    /* try libanort first, then libanogs (different FF builds use either) */
    static const char *ano_libs[] = {"libanort.so", "libanogs.so", NULL};

    for(unsigned j=0;j<ANO_N;j++){
        if(!bh_anogs[j].sym) continue;
        void *orig = NULL;
        for(int li=0; ano_libs[li]; li++){
            sh_stubA[j] = shadowhook_hook_sym_name(
                ano_libs[li],
                bh_anogs[j].sym,
                bh_anogs[j].newfn,
                &orig
            );
            if(sh_stubA[j]){
                /* shadowhook fills orig before first invocation;
                 * write it to real_rep[j] so wrap handlers can call through */
                if(bh_anogs[j].slot) *bh_anogs[j].slot = orig;
                __sync_fetch_and_add(&bh_armed, 1);
                char lb[128];
                snprintf(lb,sizeof(lb),
                    "sh_ano[%u] %s in %s orig=%p stub=%p",
                    j, bh_anogs[j].sym, ano_libs[li], orig, sh_stubA[j]);
                file_append(lb);
                break;
            }
        }
        if(!sh_stubA[j]){
            char lb[96];
            snprintf(lb,sizeof(lb),"sh_ano[%u] %s not found in any ano lib",
                j, bh_anogs[j].sym?bh_anogs[j].sym:"?");
            file_append(lb);
        }
    }
    char sb[64];
    snprintf(sb,sizeof(sb),"sh_ano reg done armed=%d",bh_armed);
    file_append(sb);
}

static void bh_reg_all(void){
    if(!bh_init_done){
        bh_init_done=1;
        int bi=bytehook_init(BYTEHOOK_MODE_AUTOMATIC,true);
        char bb[96];snprintf(bb,sizeof(bb),"bhook init=%d auto",bi);
        file_append(bb);
        bytehook_add_ignore("libSignatureKiller.so");
        bytehook_add_ignore("libff_utils_.so");
        /* EVASION: ignore our own renamed .so so bytehook doesn't hook it */
        bytehook_add_ignore("libunity_analytics_ext.so");
        /* EVASION FIX addr=0x38: prevent bytehook from patching libanort/libanogs GOT.
         * libanort self-verifies its own PLT/GOT entries at runtime and calls
         * tgkill(pid, maintid, SIGSEGV) with addr=0x38 if any GOT entry was redirected.
         * bytehook_add_ignore() stops bytehook from patching their PLT stubs at all.
         * We lose interception of libc calls FROM libanort, but keep the AnoSDK
         * function-body hooks (shadowhook UNIQUE mode) which don't touch the GOT. */
        bytehook_add_ignore("libanort.so");
        bytehook_add_ignore("libanogs.so");
    }
    if(!sh_init_done){
        sh_init_done=1;
        /* Init shadowhook in UNIQUE mode — one hook per function address,
         * island trampolines only, no PLT patching. */
        int si=shadowhook_init(SHADOWHOOK_MODE_UNIQUE, false);
        char sb[64];snprintf(sb,sizeof(sb),"shadowhook init=%d unique",si);
        file_append(sb);
    }
    /* libc hooks: use bytehook (PLT hook is fine for libc — libanort doesn't
     * scan libc PLT stubs, only its own AnoSDK function PLT stubs) */
    for(unsigned i=0;i<LIBC_N;i++)
        bh_stubL[i]=bytehook_hook_all(NULL,bh_libc[i].sym,bh_libc[i].newfn,hooked_cb,NULL);
    /* AnoSDK hooks: use shadowhook body-level patching — evades PLT scanner */
    sh_reg_anogs();
    char ab[96];snprintf(ab,sizeof(ab),"bhook reg libc=%zu ano=%zu",LIBC_N,ANO_N);
    file_append(ab);
}
static void bh_late_newelf(bh_elf_t *elf,void *arg){
    (void)arg; if(!elf)return;
    for(unsigned i=0;i<LIBC_N;i++) if(bh_stubL[i])bh_task_hook_elf(bh_stubL[i],elf);
    for(unsigned j=0;j<ANO_N;j++) if(bh_stubA[j])bh_task_hook_elf(bh_stubA[j],elf);
    /* FIX: also apply the late-registered AnoSDKForExport hook to new ELF maps */
    if(bh_stubExport) bh_task_hook_elf(bh_stubExport,elf);
    bh_elf_t *e=elf;
    const char *pn=(e&&e->pathname)?e->pathname:"?";
    char lb[256];snprintf(lb,sizeof(lb),"scan_pass elf=%s",pn);
    file_append(lb);
    if(strstr(pn,"anogs")){
        char rb[160];snprintf(rb,sizeof(rb),"ANOGS-RELOAD detected new map %s",pn);
        file_append(rb);json_event("anogs_reload","\"path\":\"%s\"",pn);
        setupAnogs();
    }
}

/* ─── libanogs symbol loader ─────────────────────────────────── */
static unsigned char sh__[4096];
static char shst__[8192];
static char dst__[262144];
static int cmpSym(const void *x,const void *y){unsigned long a=((const struct symEnt*)x)->a,b=((const struct symEnt*)y)->a;return a<b?-1:a>b?1:0;}
static void loadAnogsSyms(const char *path){
    asym_n=0;
    if(!path||!old_open||!old_read||!old_close||!old_dlsym)return;
    int fd=old_open(path,0,0);if(fd<0)return;
    unsigned char eh[64];
    if(readFull(fd,eh,64)!=64||eh[0]!=0x7f||eh[1]!='E'||eh[4]!=2){old_close(fd);return;}
    unsigned long shoff; unsigned short shentsz,shnum,shstr;
    memcpy(&shoff,eh+40,8);memcpy(&shentsz,eh+58,2);memcpy(&shnum,eh+60,2);memcpy(&shstr,eh+62,2);
    if(shentsz!=64||shnum==0||shnum>64||shstr>=shnum){old_close(fd);return;}
    lseek(fd,(off_t)shoff,SEEK_SET);
    if(readFull(fd,sh__,shnum*64)!=shnum*64){old_close(fd);return;}
    unsigned char *sn=sh__+(unsigned long)shstr*64;
    unsigned long sbo,sbs;memcpy(&sbo,sn+24,8);memcpy(&sbs,sn+32,8);
    if(sbs==0||sbs>8192){old_close(fd);return;}
    lseek(fd,(off_t)sbo,SEEK_SET);
    if(readFull(fd,(unsigned char*)shst__,(int)sbs)!=(int)sbs){old_close(fd);return;}
    unsigned long symoff=0,symsz=0,syment=24,stroff=0,strsz=0;
    for(unsigned i=0;i<shnum;i++){
        unsigned char *s=sh__+(unsigned long)i*64;
        unsigned type,nm;unsigned long off,sz,esz;
        memcpy(&nm,s,4);memcpy(&type,s+4,4);memcpy(&off,s+24,8);memcpy(&sz,s+32,8);memcpy(&esz,s+56,8);
        const char *sname=nm<sbs?shst__+nm:"";
        if(type==11){symoff=off;symsz=sz;if(esz)syment=esz;}
        else if(type==3&&!strcmp(sname,".dynstr")){stroff=off;strsz=sz;}
    }
    if(!symoff||!stroff||!strsz||strsz>262144){old_close(fd);return;}
    lseek(fd,(off_t)stroff,SEEK_SET);
    if(readFull(fd,(unsigned char*)dst__,(int)strsz)!=(int)strsz){old_close(fd);return;}
    lseek(fd,(off_t)symoff,SEEK_SET);
    unsigned long count=symsz/syment;if(count>MAX_SYMS)count=MAX_SYMS;
    for(unsigned long k=0;k<count&&asym_n<MAX_SYMS;k++){
        unsigned char en[32];int want=(int)(syment>32?32:syment);
        if(readFull(fd,en,want)!=want)break;
        unsigned nm2;unsigned char info;unsigned short shndx;unsigned long val;
        memcpy(&nm2,en,4);info=en[4];memcpy(&shndx,en+6,2);memcpy(&val,en+8,8);
        if((info&15)!=2||shndx==0||val==0||nm2>=strsz)continue;
        const char *sname=dst__+nm2;
        int l=0;while(l<95&&sname[l]){asym_[asym_n].name[l]=sname[l];l++;}
        asym_[asym_n].name[l]=0;asym_[asym_n].a=val;asym_n++;
    }
    old_close(fd);
    if(!asym_n)return;
    qsort(asym_,(size_t)asym_n,sizeof(asym_[0]),cmpSym);
    unsigned long bias=0;
    const char *probe_syms[]={"AnoSDKInit","AnoSDKGetReportData","AnoSDKIoctl",NULL};
    for(int i=0;probe_syms[i];i++){
        void *r=old_dlsym(RTLD_DEFAULT,probe_syms[i]);if(!r)continue;
        for(int k=0;k<asym_n;k++){
            if(!strcmp(asym_[k].name,probe_syms[i])){bias=(unsigned long)r-asym_[k].a;break;}
        }
        if(bias)break;
    }
    if(!bias&&anogs_s)bias=anogs_s;
    if(bias){anogs_bias=bias;for(int k=0;k<asym_n;k++)asym_[k].a+=bias;}
    /* emit all exported symbols */
    int cap=asym_n>400?400:asym_n;
    for(int k=0;k<cap;k++){
        char lb[192];snprintf(lb,sizeof(lb),"anogs_sym %s 0x%lx",asym_[k].name,asym_[k].a);
        file_append(lb);
        json_event("anogs_sym","\"name\":\"%s\",\"addr\":\"0x%lx\"",asym_[k].name,asym_[k].a);
    }
}
static void dumpAnogsFns(void){
    if(in_log||!asym_n)return;
    char bh[64];snprintf(bh,sizeof(bh),"anogs_sym_total=%d bias=0x%lx",asym_n,anogs_bias);
    file_append(bh);
}
static void setupAnogs(void){
    refreshMaps();
    for(int j=0;j<maps_n;j++){
        if(!strstr(maps_[j].name,"anogs"))continue;
        loadAnogsSyms(maps_[j].name);
        dumpAnogsFns();
        break;
    }
}
static void setupAnogsIfPresent(void){setupAnogs();}

/* ─── bytehook poll / retry ──────────────────────────────────── */
static long long bh_reg_ms=0;
static int bh_tbl_done=0,bh_retried=0;
static void bh_poll_armed(void){
    static unsigned bh_last_armed=0;
    if(bh_armed!=bh_last_armed){
        bh_last_armed=bh_armed;
        char ab[64];snprintf(ab,sizeof(ab),"bhook armed=%u quiet=%u",bh_armed,scan_quiet);
        file_append(ab);bh_tbl_done=1;
    } else if(!bh_tbl_done&&bh_reg_ms&&now_ms()-bh_reg_ms>10000){
        bh_tbl_done=1;
        char tb[64];snprintf(tb,sizeof(tb),"bhook tbl armed=%u",bh_armed);file_append(tb);
    }
    if(!bh_retried&&bh_reg_ms&&now_ms()-bh_reg_ms>6000){
        bh_retried=1;
        if(!bh_armed){file_append("bhook retry");bh_reg_all();}
    }
}

/* ─── watcher thread ─────────────────────────────────────────── */
static char wbuf_[98304];
static struct rxEnt{unsigned long s,e;char nm[128];} rxseen_[512];
static int rxseen_n=0;
static int watcher_on=0;
static volatile unsigned watcher_ticks=0;

static void *watcherFn(void *a){
    (void)a;
    pthread_setname_np(pthread_self(),"UnityAnalytics");
    for(;;){
        struct timespec rq;rq.tv_sec=0;rq.tv_nsec=500000000L;nanosleep(&rq,NULL);
        unsigned tick=__sync_add_and_fetch(&watcher_ticks,1);
        /* FIX tick 4: register AnoSDKForExport late — safe after libanort init */
        if(tick==4) bh_late_register_export();
        /* FIX tick 8: now run the ELF manager scan. By tick 8 (≈4s) hooked_cb
         * has been called for all loaded symbols and real_rep[] slots are set.
         * bh_elf_manager_refresh is safe to call here because wrap handlers will
         * no longer hit NULL real_rep[] when fired for existing ELFs. */
        if(tick==8&&!bh_refresh_done){
            bh_refresh_done=1;
            bh_elf_manager_refresh(false,bh_late_newelf,NULL);
            file_append("bh_elf_manager_refresh deferred-done");
        }
        bh_poll_armed();
        if(!old_open||!old_read||!old_close)continue;
        int fd=old_open("/proc/self/maps",0,0);int total=0;
        if(fd>=0){for(;;){int n=(int)old_read(fd,wbuf_+total,(int)sizeof(wbuf_)-1-total);if(n<=0)break;total+=n;if(total>=(int)sizeof(wbuf_)-1)break;}old_close(fd);}
        if(total<=0)continue;
        wbuf_[total]=0;char *ln=wbuf_;
        while(*ln){
            char *nl=strchr(ln,'\n');if(nl)*nl=0;
            unsigned long s=0,e=0;char perms[8],path[192];perms[0]=path[0]=0;
            int r=sscanf(ln,"%lx-%lx %7s %*s %*s %*s %191s",&s,&e,perms,path);
            if(r>=3&&e>s&&perms[0]=='r'&&perms[2]=='x'){
                int seen=0;
                for(int j=0;j<rxseen_n;j++)if(rxseen_[j].s==s&&rxseen_[j].e==e){seen=1;break;}
                if(!seen&&rxseen_n<512){
                    rxseen_[rxseen_n].s=s;rxseen_[rxseen_n].e=e;
                    const char *nm=path[0]?path:"[anon]";
                    strncpy(rxseen_[rxseen_n].nm,nm,127);rxseen_[rxseen_n].nm[127]=0;rxseen_n++;
                    char msg[320];
                    if(!path[0])snprintf(msg,sizeof(msg),"NEW-ANON-EXEC %lx-%lx",s,e);
                    else snprintf(msg,sizeof(msg),"newrx %lx-%lx %s",s,e,nm);
                    LOGE("%s",msg);file_append(msg);
                    if(!path[0])json_event("anon_exec","\"addr\":\"0x%lx\",\"len\":0x%lx",s,e-s);
                }
            }
            if(!nl)break;ln=nl+1;
        }
        /* emit pending SSL ring entries */
        {static unsigned sslring_r=0;
        unsigned w=atomic_load(&sslring_w);
        int shown=0;
        while(sslring_r!=w&&shown<8){
            struct sslEnt *e=&sslring_[sslring_r%RING_SIZE];sslring_r++;
            if(e->len<=0)continue;
            char hx[129];hexN(e->b,(long)e->len,hx,128);
            char sb[512];
            snprintf(sb,sizeof(sb),"sslp %c t=%lld n=%d sha=%.16s hx=%.128s",e->dir,e->t,e->len,e->sha[0]?e->sha:"-",hx);
            file_append(sb);shown++;
        }}
    }
    return NULL;
}
static void watcherStart(void){
    if(watcher_on)return;watcher_on=1;
    pthread_t t;pthread_create(&t,NULL,watcherFn,NULL);pthread_detach(t);
}

/* ─── signal chain (crash handler) ──────────────────────────── */
static struct sigaction old_sa[6];
static int sig_list[]={SIGSEGV,SIGBUS,SIGABRT,SIGFPE,SIGILL,SIGTRAP};
static void sig_handler(int sig,siginfo_t *si,void *uc){
    (void)uc;
    char lb[256];
    snprintf(lb,sizeof(lb),"=== CRASH sig=%d addr=%p ===",sig,si?si->si_addr:NULL);
    file_append(lb);json_event("crash","\"sig\":%d",sig);
    char bt[512];deathBt(bt,sizeof(bt));
    if(bt[0]){char bm[600];snprintf(bm,sizeof(bm),"CRASH-BT %s",bt);file_append(bm);}
    ctx_dump("crash");
    int idx=0;
    for(int i=0;i<6;i++)if(sig_list[i]==sig){idx=i;break;}
    sigaction(sig,&old_sa[idx],NULL);
    raise(sig);
}
static void installSigChain(void){
    struct sigaction sa;
    memset(&sa,0,sizeof(sa));
    sa.sa_sigaction=sig_handler;
    sa.sa_flags=SA_SIGINFO|SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    for(int i=0;i<6;i++)sigaction(sig_list[i],&sa,&old_sa[i]);
}

/* ─── reg_all ────────────────────────────────────────────────── */
static void reg_all(void){
    bh_reg_all();
    /* FIX v165→v166 patch 2: DO NOT call bh_elf_manager_iterate or
     * bh_elf_manager_refresh here. These functions iterate all currently-
     * loaded ELFs and fire wrap handler callbacks synchronously for each one.
     * If libanort is already loaded at this point (common on FF), the wrap_rep
     * handlers fire before hooked_cb has been called with the prev pointer,
     * so real_rep[] slots are still NULL → BLR x1 with x1=0 → SIGSEGV pc=0x0
     * (confirmed: libffk_pro.so+0x12158, all 3 runs, x1=0).
     *
     * In BYTEHOOK_MODE_AUTOMATIC, the library already monitors dlopen/linker
     * activity and applies hooks to new ELFs automatically. The explicit iterate
     * and refresh calls are redundant AND fatal here. They are moved to the
     * watcher thread at tick 8 (≈4s) after hooked_cb has had time to set all
     * real_rep[] slots and bh_armed count is stable.
     * See watcherFn() for the deferred bh_elf_manager_refresh call. */
    bh_reg_ms=now_ms();
    installSigChain();
}

/* ─── JNI entry points ───────────────────────────────────────── */
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm,void *reserved){
    (void)vm;(void)reserved;
    if(!proc_start_ms)proc_start_ms=now_ms();
    setenv("SSLKEYLOGFILE",SSL_KEY_PATH,1);
    reg_all();
    refreshMaps();
    setupAnogsIfPresent();
    watcherStart();
    char vb[160];snprintf(vb,sizeof(vb),"ffk_pro %s on",FFK_VERSION);
    LOGE("%s",vb);file_append(vb);
    json_event("startup","\"version\":\"%s\"",FFK_VERSION);
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_ff_killer_Killer_hookApkPath(JNIEnv *env,__attribute__((unused))jclass clazz,jstring apkPath,jstring repPath){
    apkPath__=(*env)->GetStringUTFChars(env,apkPath,0);
    repPath__=(*env)->GetStringUTFChars(env,repPath,0);
    if(!proc_start_ms)proc_start_ms=now_ms();
    setenv("SSLKEYLOGFILE",SSL_KEY_PATH,1);
    reg_all();
    refreshMaps();
    setupAnogsIfPresent();
    watcherStart();
    char lb[256];snprintf(lb,sizeof(lb),"ffk_pro %s paths apk=%s rep=%s",FFK_VERSION,apkPath__,repPath__);
    file_append(lb);
}
