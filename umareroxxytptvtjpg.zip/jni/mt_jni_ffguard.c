#include <jni.h>
#include <android/log.h>
#include <string.h>
#include <stdio.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/ioctl.h>
#include <sys/un.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdarg.h>
#include "xhook.h"

#define TAG "FFKN"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static const char *apkPath__ = NULL;
static const char *repPath__ = NULL;

static void file_append(const char *line);
static void deathBt(char *out, size_t outn);
static void dumpAnogsFns(void);
void *(*old_dlsym)(void *, const char *);
int (*old_open)(const char *, int, mode_t);
ssize_t (*old_read)(int, void *, size_t);
ssize_t (*old_write)(int, const void *, size_t);
int (*old_close)(int);

static unsigned sockbits[32];
static unsigned sockcnt[1024];
static char sockpeer[1024][64];

static inline void trackAdd(int fd) {
    if (fd >= 0 && fd < 1024) sockbits[fd >> 5] |= 1u << (fd & 31);
}
static inline void trackDel(int fd) {
    if (fd >= 0 && fd < 1024) {
        sockbits[fd >> 5] &= ~(1u << (fd & 31));
        sockcnt[fd] = 0;
        sockpeer[fd][0] = 0;
    }
}
static inline int trackHas(int fd) {
    return fd >= 0 && fd < 1024 && ((sockbits[fd >> 5] >> (fd & 31)) & 1u);
}
static inline void trackPeer(int fd, const char *s) {
    if (fd >= 0 && fd < 1024 && s) {
        strncpy(sockpeer[fd], s, 63);
        sockpeer[fd][63] = 0;
    }
}
static inline unsigned trackBump(int fd) {
    if (fd < 0 || fd >= 1024) return 0;
    return ++sockcnt[fd];
}

static void hex16(const unsigned char *p, long len, char *out) {
    static const char *h = "0123456789abcdef";
    long n = len > 16 ? 16 : len;
    for (long i = 0; i < n; i++) {
        out[i * 2] = h[p[i] >> 4];
        out[i * 2 + 1] = h[p[i] & 15];
    }
    out[n * 2] = 0;
}

static int interesting(const char *p) {
    if (!p) return 0;
    if (strstr(p, "maps")) return 1;
    if (strstr(p, "task")) return 1;
    if (strstr(p, "status")) return 1;
    if (strstr(p, "cmdline")) return 1;
    if (strstr(p, "anogs")) return 1;
    if (strstr(p, "anort")) return 1;
    if (strstr(p, "ob_x")) return 1;
    if (strstr(p, "vm_rom")) return 1;
    if (strstr(p, "scan")) return 1;
    if (strstr(p, "report")) return 1;
    if (strstr(p, "crash")) return 1;
    if (strstr(p, "tdm")) return 1;
    if (strstr(p, "complaint")) return 1;
    if (strstr(p, "origin")) return 1;
    if (strstr(p, "killer")) return 1;
    if (strstr(p, "Killer")) return 1;
    if (strstr(p, "hook")) return 1;
    if (strstr(p, "unsafe")) return 1;
    if (strstr(p, "ff_")) return 1;
    if (strstr(p, ".so")) return 1;
    if (strstr(p, ".dex")) return 1;
    if (strstr(p, ".apk")) return 1;
    if (strstr(p, ".odex")) return 1;
    if (strstr(p, ".vdex")) return 1;
    return 0;
}

FILE *(*old_fopen)(const char *, const char *);

static int dlsymInteresting(const char *s) {
    if (!s) return 0;
    if (interesting(s)) return 1;
    if (strstr(s, "Ano")) return 1;
    if (strstr(s, "TDM") || strstr(s, "tdm")) return 1;
    if (strstr(s, "Report") || strstr(s, "report")) return 1;
    if (strstr(s, "Complaint")) return 1;
    if (strstr(s, "Scan") || strstr(s, "scan")) return 1;
    if (strstr(s, "Cheat") || strstr(s, "cheat")) return 1;
    if (strstr(s, "Hack") || strstr(s, "hack")) return 1;
    if (strstr(s, "Integrity")) return 1;
    if (strstr(s, "il2cpp")) return 1;
    if (strstr(s, "unity") || strstr(s, "Unity")) return 1;
    return 0;
}
static __thread int in_log = 0;
static pthread_mutex_t attr_mx = PTHREAD_MUTEX_INITIALIZER;
static unsigned attr_ok = 0, attr_busy = 0;
static const char *baseName(const char *p) {
    const char *b = strrchr(p, '/');
    return b ? b + 1 : p;
}
struct mapEnt { unsigned long s, e; char name[192]; };
static struct mapEnt maps_[2048];
static int maps_n = 0;
static unsigned long anogs_s = 0, anogs_e = 0;
static char rb_[98304];
static int refreshMaps(void) {
    if (in_log) return maps_n;
    if (!old_open || !old_read || !old_close) return maps_n;
    if (pthread_mutex_trylock(&attr_mx)) return maps_n;
    in_log = 1;
    maps_n = 0;
    anogs_s = 0;
    anogs_e = 0;
    int fd = old_open("/proc/self/maps", 0, 0);
    if (fd >= 0) {
        int total = 0;
        for (;;) {
            int n = (int)old_read(fd, rb_ + total, (int)sizeof(rb_) - 1 - total);
            if (n <= 0) break;
            total += n;
            if (total >= (int)sizeof(rb_) - 1) break;
        }
        old_close(fd);
        if (total > 0) {
            rb_[total] = 0;
            char *ln = rb_;
            while (*ln && maps_n < 2048) {
                char *nl = strchr(ln, '\n');
                if (nl) *nl = 0;
                unsigned long s = 0, e = 0;
                char perms[8];
                char path[192];
                perms[0] = 0;
                path[0] = 0;
                int r = sscanf(ln, "%lx-%lx %7s %*s %*s %*s %191s", &s, &e, perms, path);
                if (r >= 4 && e > s && path[0] == '/') {
                    maps_[maps_n].s = s;
                    maps_[maps_n].e = e;
                    strncpy(maps_[maps_n].name, path, 191);
                    maps_[maps_n].name[191] = 0;
                    maps_n++;
                    if (strstr(path, "anogs")) {
                        if (!anogs_s || s < anogs_s) anogs_s = s;
                        if (e > anogs_e) anogs_e = e;
                    }
                }
                if (!nl) break;
                ln = nl + 1;
            }
        }
    }
    in_log = 0;
    pthread_mutex_unlock(&attr_mx);
    return maps_n;
}
static const char *anogs_syms[] = {
    "AnoSDKGetReportData1", "AnoSDKGetReportData2",
    "AnoSDKGetReportData3", "AnoSDKGetReportData4",
    "AnoSDKDelReportData", "AnoSDKInit", "AnoSDKStart",
    "tdm_report", "ReportComplaint", "AnoSDKIoctl", "AnoSDKIoctlOld", NULL
};
struct symEnt { unsigned long a; char name[64]; };
static struct symEnt asym_[2048];
static int asym_n = 0;
static unsigned long anogs_bias = 0;
static int cmpSym(const void *x, const void *y) {
    unsigned long a = ((const struct symEnt *)x)->a;
    unsigned long b = ((const struct symEnt *)y)->a;
    return a < b ? -1 : a > b ? 1 : 0;
}
static int readFull(int fd, unsigned char *o, int n) {
    int got = 0;
    while (got < n) {
        int r = (int)old_read(fd, o + got, n - got);
        if (r <= 0) break;
        got += r;
    }
    return got;
}
static unsigned char sh_[4096];
static char shst_[8192];
static char dst_[262144];
static void loadAnogsSyms(const char *path) {
    asym_n = 0;
    if (!path || !old_open || !old_read || !old_close || !old_dlsym) return;
    int fd = old_open(path, 0, 0);
    if (fd < 0) return;
    unsigned char eh[64];
    if (readFull(fd, eh, 64) != 64 || eh[0] != 0x7f || eh[1] != 'E' || eh[2] != 'L' || eh[3] != 'F' || eh[4] != 2) { old_close(fd); return; }
    unsigned long shoff;
    unsigned short shentsz, shnum, shstr;
    memcpy(&shoff, eh + 40, 8);
    memcpy(&shentsz, eh + 58, 2);
    memcpy(&shnum, eh + 60, 2);
    memcpy(&shstr, eh + 62, 2);
    if (shentsz != 64 || shnum == 0 || shnum > 64 || shstr >= shnum) { old_close(fd); return; }
    lseek(fd, (off_t)shoff, SEEK_SET);
    if (readFull(fd, sh_, shnum * 64) != shnum * 64) { old_close(fd); return; }
    unsigned char *sn = sh_ + (unsigned long)shstr * 64;
    unsigned long sbo, sbs;
    memcpy(&sbo, sn + 24, 8);
    memcpy(&sbs, sn + 32, 8);
    if (sbs == 0 || sbs > 8192) { old_close(fd); return; }
    lseek(fd, (off_t)sbo, SEEK_SET);
    if (readFull(fd, (unsigned char *)shst_, (int)sbs) != (int)sbs) { old_close(fd); return; }
    unsigned long symoff = 0, symsz = 0, syment = 24, stroff = 0, strsz = 0;
    for (unsigned i = 0; i < shnum; i++) {
        unsigned char *s = sh_ + (unsigned long)i * 64;
        unsigned type;
        unsigned nm;
        unsigned long off, sz, esz;
        memcpy(&nm, s, 4);
        memcpy(&type, s + 4, 4);
        memcpy(&off, s + 24, 8);
        memcpy(&sz, s + 32, 8);
        memcpy(&esz, s + 56, 8);
        const char *sname = nm < sbs ? shst_ + nm : "";
        if (type == 11) { symoff = off; symsz = sz; if (esz) syment = esz; }
        else if (type == 3 && !strcmp(sname, ".dynstr")) { stroff = off; strsz = sz; }
    }
    if (!symoff || !stroff || !strsz || strsz > 262144) { old_close(fd); return; }
    lseek(fd, (off_t)stroff, SEEK_SET);
    if (readFull(fd, (unsigned char *)dst_, (int)strsz) != (int)strsz) { old_close(fd); return; }
    lseek(fd, (off_t)symoff, SEEK_SET);
    unsigned long count = symsz / syment;
    if (count > 8192) count = 8192;
    for (unsigned long k = 0; k < count && asym_n < 2048; k++) {
        unsigned char en[32];
        int want = syment > 32 ? 32 : (int)syment;
        if (readFull(fd, en, want) != want) break;
        unsigned nm;
        unsigned char info;
        unsigned short shndx;
        unsigned long val;
        memcpy(&nm, en, 4);
        info = en[4];
        memcpy(&shndx, en + 6, 2);
        memcpy(&val, en + 8, 8);
        if ((info & 15) != 2 || shndx == 0 || val == 0) continue;
        if (nm >= strsz) continue;
        const char *sname = dst_ + nm;
        int l = 0;
        while (l < 63 && sname[l]) { asym_[asym_n].name[l] = sname[l]; l++; }
        asym_[asym_n].name[l] = 0;
        asym_[asym_n].a = val;
        asym_n++;
    }
    old_close(fd);
    if (!asym_n) return;
    qsort(asym_, (size_t)asym_n, sizeof(asym_[0]), cmpSym);
    unsigned long bias = 0;
    for (int i = 0; anogs_syms[i]; i++) {
        void *r = old_dlsym(RTLD_DEFAULT, anogs_syms[i]);
        if (!r) continue;
        for (int k = 0; k < asym_n; k++) {
            if (!strcmp(asym_[k].name, anogs_syms[i])) { bias = (unsigned long)r - asym_[k].a; break; }
        }
        if (bias) break;
    }
    if (!bias && anogs_s) bias = anogs_s;
    if (bias) {
        anogs_bias = bias;
        for (int k = 0; k < asym_n; k++) asym_[k].a += bias;
    }
}
static void setupAnogs(void) {
    refreshMaps();
    for (int j = 0; j < maps_n; j++) {
        if (strstr(maps_[j].name, "anogs")) { loadAnogsSyms(maps_[j].name); break; }
    }
    dumpAnogsFns();
}
static void modTag(unsigned long a, char *out, size_t outn) {
    if (!out || outn < 8) return;
    out[0] = 0;
    if (a < 4096) return;
    const char *lib = NULL;
    for (int j = 0; j < maps_n; j++) {
        if (a >= maps_[j].s && a < maps_[j].e) { lib = baseName(maps_[j].name); break; }
    }
    if (!lib) return;
    if (anogs_s && a >= anogs_s && a < anogs_e) {
        int lo = 0, hi = asym_n - 1, best = -1;
        while (lo <= hi) {
            int m = (lo + hi) / 2;
            if (asym_[m].a <= a) { best = m; lo = m + 1; } else hi = m - 1;
        }
        if (best >= 0) snprintf(out, outn, "%s!%s+0x%lx", lib, asym_[best].name, a - asym_[best].a);
        else snprintf(out, outn, "%s!?+0x%lx", lib, a - anogs_s);
        return;
    }
    snprintf(out, outn, "%s", lib);
}
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wframe-address"
static int collectPcs(void **pcs, int max) {
    void **fp = (void **)__builtin_frame_address(0);
    int n = 0;
    while (fp && n < max) {
        if (((unsigned long)fp & 7UL)) break;
        void **next = (void **)fp[0];
        void *ret = (void *)fp[1];
        if (!ret) break;
        pcs[n++] = ret;
        if (!next || next <= fp || (unsigned long)next - (unsigned long)fp > 0x4000000UL) break;
        fp = next;
    }
    return n;
}
static __attribute__((noinline)) void attrTag(char *out, size_t outn) {
    if (!out || outn < 8) return;
    out[0] = 0;
    if (in_log) return;
    if (pthread_mutex_trylock(&attr_mx)) { attr_busy++; return; }
    attr_ok++;
    in_log = 1;
    void *pcs[6];
    int npc = collectPcs(pcs, 6);
    for (int i = 0; i < npc; i++) {
        unsigned long a = (unsigned long)pcs[i];
        char mb[160];
        modTag(a, mb, sizeof(mb));
        if (!mb[0]) continue;
        if (strstr(mb, "SignatureKiller")) continue;
        if (!strncmp(mb, "libc.so", 7) || !strncmp(mb, "libm.so", 7) || !strncmp(mb, "libart", 6) || !strncmp(mb, "linker", 6)) continue;
        if (anogs_s && a >= anogs_s && a < anogs_e) snprintf(out, outn, " anogs=%s", mb);
        else snprintf(out, outn, " via=%s", mb);
        break;
    }
    in_log = 0;
    pthread_mutex_unlock(&attr_mx);
}
#pragma GCC diagnostic pop



static char sgs_[98304];
static void dumpAnogsSegs(void) {
    if (!old_open || !old_read || !old_close) return;
    int fd = old_open("/proc/self/maps", 0, 0);
    if (fd < 0) return;
    int total = 0;
    for (;;) {
        int n = (int)old_read(fd, sgs_ + total, (int)sizeof(sgs_) - 1 - total);
        if (n <= 0) break;
        total += n;
        if (total >= (int)sizeof(sgs_) - 1) break;
    }
    old_close(fd);
    if (total <= 0) return;
    sgs_[total] = 0;
    char *ln = sgs_;
    while (*ln) {
        char *nl = strchr(ln, '\n');
        if (nl) *nl = 0;
        if (strstr(ln, "anogs")) {
            char msg[640];
            snprintf(msg, sizeof(msg), "anogs_seg=%s", ln);
            LOGE("%s", msg);
            file_append(msg);
        }
        if (!nl) break;
        ln = nl + 1;
    }
}

FILE *(*old_fopen)(const char *, const char *);

static void file_append(const char *line) {
    if (!old_open || !old_write || !old_close) return;
    int was = in_log;
    in_log = 1;
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    long long ms = (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
    char buf[560];
    int n = snprintf(buf, sizeof(buf), "t=%lld %s\n", ms, line ? line : "");
    if (n > 0) {
        if (n >= (int)sizeof(buf)) n = (int)sizeof(buf) - 1;
        int fd = old_open("/sdcard/Download/ffk_native.txt", O_WRONLY | O_CREAT | O_APPEND, 0666);
        if (fd >= 0) {
            const char *p = buf;
            int left = n;
            while (left > 0) {
                ssize_t w = old_write(fd, p, (size_t)left);
                if (w <= 0) break;
                p += w;
                left -= (int)w;
            }
            old_close(fd);
        }
    }
    in_log = was;
}

static void nlog(const char *kind, const char *path) {
    if (in_log) return;
    char buf[512];
    snprintf(buf, sizeof(buf), "%s %s", kind, path ? path : "NULL");
    LOGE("%s", buf);
    file_append(buf);
}
static int repInterest(const char *p) {
    if (!p) return 0;
    if (strstr(p, "ffk_native") || strstr(p, "ffk_trace")) return 0;
    if (strstr(p, "tdm") || strstr(p, "report") || strstr(p, "complaint") ||
            strstr(p, "cache") || strstr(p, "anogs") || strstr(p, "scan") ||
            strstr(p, ".json") || strstr(p, ".dat") || strstr(p, ".log") ||
            strstr(p, ".txt") || strstr(p, ".xml")) return 1;
    return 0;
}
static char fdp_[1024][192];
static unsigned repwc_[1024];
static unsigned self_n = 0;
static int selfWatch(const char *p) {
    if (!p) return 0;
    if (strstr(p, "ffk_trace") || strstr(p, "ffk_native")) return 1;
    return 0;
}
static void repTrack(int fd, const char *path) {
    if (fd < 0 || fd >= 1024 || !path || in_log) return;
    if (selfWatch(path)) {
        snprintf(fdp_[fd], sizeof(fdp_[fd]), "SELF:%s", baseName(path));
        repwc_[fd] = 0;
        char sb[256];
        snprintf(sb, sizeof(sb), "selfopen fd=%d %s", fd, path);
        LOGE("%s", sb);
        file_append(sb);
        return;
    }
    if (!repInterest(path)) return;
    strncpy(fdp_[fd], path, 191);
    fdp_[fd][191] = 0;
    repwc_[fd] = 0;
    char tb[256];
    snprintf(tb, sizeof(tb), "reptrack fd=%d %s", fd, path);
    LOGE("%s", tb);
    file_append(tb);
}
static int matchAt(const unsigned char *d, long i, long m, const char *kw) {
    for (long j = 0; kw[j]; j++) {
        if (i + j >= m) return 0;
        unsigned char c = d[i + j];
        if (c >= 'A' && c <= 'Z') c += 32;
        if (c != (unsigned char)kw[j]) return 0;
    }
    return 1;
}
static void sieve(const char *tag, const unsigned char *d, long n) {
    if (in_log || !tag || !d || n < 3) return;

    long m = n > 512 ? 512 : n;
    const char *hit = NULL;
    long pos = 0;
    for (long i = 0; i < m && !hit; i++) {
        unsigned char c = d[i];
        if (c >= 'A' && c <= 'Z') c += 32;
        switch (c) {
            case 'b':
                if (matchAt(d, i, m, "banned")) hit = "banned";
                else if (matchAt(d, i, m, "ban")) hit = "ban";
                break;
            case 'c':
                if (matchAt(d, i, m, "cheatdetected")) hit = "cheatdetected";
                else if (matchAt(d, i, m, "complaint")) hit = "complaint";
                else if (matchAt(d, i, m, "cheat")) hit = "cheat";
                break;
            case 'i':
                if (matchAt(d, i, m, "integrityfailed")) hit = "integrityfailed";
                else if (matchAt(d, i, m, "integrity")) hit = "integrity";
                break;
            case 's':
                if (matchAt(d, i, m, "securityreport")) hit = "securityreport";
                else if (matchAt(d, i, m, "security violation")) hit = "security violation";
                else if (matchAt(d, i, m, "suspend")) hit = "suspend";
                break;
            case 'a':
                if (matchAt(d, i, m, "account suspended")) hit = "account suspended";
                break;
            case 'r':
                if (matchAt(d, i, m, "report")) hit = "report";
                break;
            case 'h':
                if (matchAt(d, i, m, "hack")) hit = "hack";
                break;
            case 'd':
                if (matchAt(d, i, m, "detect")) hit = "detect";
                break;
            case 'v':
                if (matchAt(d, i, m, "violat")) hit = "violat";
                break;
            default:
                break;
        }
        if (hit) pos = i;
    }
    if (!hit) return;
    char ctx[100];
    long st = pos > 32 ? pos - 32 : 0;
    long en = st + 96;
    if (en > m) en = m;
    for (long q = st; q < en; q++) {
        unsigned char c = d[q];
        ctx[q - st] = (c >= 32 && c < 127) ? (char)c : '.';
    }
    ctx[en - st] = 0;
    char msg[384];
    snprintf(msg, sizeof(msg), "sieve %s kw=%s ctx=%s", tag, hit, ctx);
    LOGE("%s", msg);
    file_append(msg);
}

static unsigned pkt_n = 0;
static unsigned achain_n = 0;
static void pktlog(const char *dir, int fd, const char *peer, long n,
        const unsigned char *data, int withHex) {
    char hx[33];
    char msg[640];
    char at[128];
    char tx[65];
    int ti = 0;
    at[0] = 0;
    if (data && n > 0) sieve("pkt", data, n > 512 ? 512 : n);
    if ((++pkt_n % 2000) == 0) refreshMaps();
    if (withHex && data && n > 0) hex16(data, n, hx);
    else hx[0] = 0;
    if (withHex && data && n > 2 && data[0] >= 32 && data[0] < 127 &&
            data[1] >= 32 && data[1] < 127) {
        for (long i = 0; i < n && ti < 64; i++) {
            unsigned char c = data[i];
            if (c < 32 || c >= 127) break;
            tx[ti++] = (char)c;
        }
    }
    tx[ti] = 0;
    attrTag(at, sizeof(at));
    snprintf(msg, sizeof(msg), "%s fd=%d %s n=%ld hx=%s%s%s%s%s",
        dir, fd, (peer && peer[0]) ? peer : "?", n, hx,
        ti ? " t='" : "", ti ? tx : "", ti ? "'" : "", at);
    LOGE("%s", msg);
    file_append(msg);
    if (at[0] && strstr(at, "anogs=") && !in_log) {
        unsigned k = achain_n++;
        if (k < 12 || k % 50 == 0) {
            char ch[640];
            ch[0] = 0;
            deathBt(ch, sizeof(ch));
            if (ch[0]) {
                char cm[768];
                snprintf(cm, sizeof(cm), "achain fd=%d %s %s", fd,
                    (peer && peer[0]) ? peer : "?", ch);
                LOGE("%s", cm);
                file_append(cm);
            }
        }
    }
}

static int sockfmt(const struct sockaddr *sa, socklen_t sl, char *out, size_t outn) {
    if (!sa || !out || outn < 8) return 0;
    if (sa->sa_family == AF_INET && sl >= (socklen_t)sizeof(struct sockaddr_in)) {
        const struct sockaddr_in *a = (const struct sockaddr_in *)sa;
        const unsigned char *b = (const unsigned char *)&a->sin_addr.s_addr;
        snprintf(out, outn, "%d.%d.%d.%d:%d",
            b[0], b[1], b[2], b[3], (int)ntohs(a->sin_port));
        return 1;
    }
    if (sa->sa_family == AF_UNIX && sl > (socklen_t)sizeof(sa_family_t)) {
        const struct sockaddr_un *u = (const struct sockaddr_un *)sa;
        unsigned long plen = (unsigned long)sl - sizeof(sa_family_t);
        if (plen > sizeof(u->sun_path)) plen = sizeof(u->sun_path);
        int absx = (plen > 0 && u->sun_path[0] == 0);
        unsigned long start = absx ? 1 : 0;
        char nm[56];
        unsigned long k = 0;
        while (start + k < plen && k + 1 < sizeof(nm) && u->sun_path[start + k]) {
            nm[k] = u->sun_path[start + k];
            k++;
        }
        nm[k] = 0;
        if (!k) return 0;
        snprintf(out, outn, "unix:%s%s", absx ? "@" : "", nm);
        return 1;
    }
    if (sa->sa_family == AF_INET6 && sl >= (socklen_t)sizeof(struct sockaddr_in6)) {
        const struct sockaddr_in6 *a = (const struct sockaddr_in6 *)sa;
        const unsigned char *b = a->sin6_addr.s6_addr;
        snprintf(out, outn, "[%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x]:%d",
            b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7],
            b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15],
            (int)ntohs(a->sin6_port));
        return 1;
    }
    return 0;
}

static int selfnoise(const unsigned char *d, long n) {
    if (!d || n <= 0) return 0;
    long m = n > 128 ? 128 : n;
    static const char *marks[] = {"FFKX", "FFKN", "pkt ", "close fd=",
        "socket fd=", "connect ", "sendto ", "sendmsg ", "dns ", "dlopen"};
    for (int k = 0; k < 10; k++) {
        const char *mk = marks[k];
        size_t ml = strlen(mk);
        for (long i = 0; i + (long)ml <= m; i++) {
            if (memcmp(d + i, mk, ml) == 0) return 1;
        }
    }
    return 0;
}
static pthread_mutex_t ring_mx = PTHREAD_MUTEX_INITIALIZER;
struct ringEnt { int fd; char dir[8]; char peer[64]; long len; char hx[65]; long long t; };
static struct ringEnt ring_[12];
static int ring_i = 0, ring_full = 0;
static void mirror(const char *tag, int fd, const unsigned char *d, long seg, long total) {
    if (!tag || !d || seg <= 0 || total <= 0) return;
    if (fd < 0 || fd >= 1024 || !sockpeer[fd][0]) return;
    if (seg > 512) seg = 512;
    if (selfnoise(d, seg)) return;
    sieve(tag, d, seg);
    if (pthread_mutex_trylock(&ring_mx)) return;
    struct ringEnt *e = &ring_[ring_i];
    e->fd = fd;
    strncpy(e->dir, tag, 7);
    e->dir[7] = 0;
    strncpy(e->peer, sockpeer[fd], 63);
    e->peer[63] = 0;
    e->len = total;
    long m = seg > 32 ? 32 : seg;
    static const char *h = "0123456789abcdef";
    for (long i = 0; i < m; i++) {
        e->hx[i * 2] = h[d[i] >> 4];
        e->hx[i * 2 + 1] = h[d[i] & 15];
    }
    e->hx[m * 2] = 0;
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    e->t = (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
    ring_i = (ring_i + 1) % 12;
    if (ring_i == 0) ring_full = 1;
    pthread_mutex_unlock(&ring_mx);
}
static void repBody(const char *tag, int fd, const unsigned char *d, long n) {
    if (!tag || !d || n < 4 || fd < 0 || fd >= 1024) return;
    if (!fdp_[fd][0] || repwc_[fd] >= 3 || in_log) return;
    if (selfnoise(d, n)) return;
    int isSelf = fdp_[fd][0] == 'S' && fdp_[fd][1] == 'E' && fdp_[fd][2] == 'L' && fdp_[fd][3] == 'F';
    if (isSelf) {
        if (self_n >= 8) return;
        self_n++;
    }
    repwc_[fd]++;
    char hx[33];
    hex16(d, n, hx);
    char tx[65];
    int ti = 0;
    if (d[0] >= 32 && d[0] < 127 && n > 1 && d[1] >= 32 && d[1] < 127) {
        for (long i = 0; i < n && ti < 64; i++) {
            unsigned char c = d[i];
            if (c < 32 || c >= 127) break;
            tx[ti++] = (char)c;
        }
    }
    tx[ti] = 0;
    sieve("rep", d, n > 512 ? 512 : n);
    char at[128];
    at[0] = 0;
    attrTag(at, sizeof(at));
    char msg[640];
    snprintf(msg, sizeof(msg), "%s %s n=%ld hx=%s%s%s%s%s", tag, fdp_[fd], n, hx,
        ti ? " t='" : "", ti ? tx : "", ti ? "'" : "", at);
    LOGE("%s", msg);
    file_append(msg);
}
static void repDel(const char *path) {
    if (!path || in_log || !old_open || !old_read || !old_close) return;
    if (!repInterest(path)) return;
    in_log = 1;
    int fd = old_open(path, 0, 0);
    if (fd >= 0) {
        unsigned char b[512];
        int n = (int)old_read(fd, b, sizeof(b));
        old_close(fd);
        if (n > 0) {
            char hx[33];
            hex16(b, n, hx);
            char tx[65];
            int ti = 0;
            if (b[0] >= 32 && b[0] < 127 && n > 1 && b[1] >= 32 && b[1] < 127) {
                for (int i = 0; i < n && ti < 64; i++) {
                    if (b[i] < 32 || b[i] >= 127) break;
                    tx[ti++] = (char)b[i];
                }
            }
            tx[ti] = 0;
            in_log = 0;
            char at[128];
            at[0] = 0;
            attrTag(at, sizeof(at));
            char msg[640];
            snprintf(msg, sizeof(msg), "repdel %s n=%d hx=%s%s%s%s%s", path, n, hx,
                ti ? " t='" : "", ti ? tx : "", ti ? "'" : "", at);
            sieve("repdel", b, n > 512 ? 512 : n);
            LOGE("%s", msg);
            file_append(msg);
            return;
        }
    }
    in_log = 0;
}
static void dumpRing(void) {
    if (pthread_mutex_trylock(&ring_mx)) return;
    int total = ring_full ? 12 : ring_i;
    for (int k = 0; k < total; k++) {
        int idx = ring_full ? (ring_i + k) % 12 : k;
        struct ringEnt *e = &ring_[idx];
        char msg[320];
        snprintf(msg, sizeof(msg), "lastpkt %s fd=%d %s n=%ld hx=%s t=%lld",
            e->dir, e->fd, e->peer[0] ? e->peer : "?",
            e->len, e->hx, e->t);
        LOGE("%s", msg);
        file_append(msg);
    }
    {
        char ab[96];
        snprintf(ab, sizeof(ab), "attr ok=%u busy=%u", attr_ok, attr_busy);
        LOGE("%s", ab);
        file_append(ab);
    }
    pthread_mutex_unlock(&ring_mx);
}
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wframe-address"
static __attribute__((noinline)) void deathBt(char *out, size_t outn) {
    if (!out || outn < 16) return;
    out[0] = 0;
    int locked = pthread_mutex_trylock(&attr_mx) == 0;
    if (locked) attr_ok++;
    void *pcs[8];
    int npc = collectPcs(pcs, 8);
    size_t used = 0;
    for (int i = 0; i < npc; i++) {
        unsigned long a = (unsigned long)pcs[i];
        if (a < 4096) continue;
        char mb[160];
        mb[0] = 0;
        if (locked) modTag(a, mb, sizeof(mb));
        else snprintf(mb, sizeof(mb), "0x%lx", a);
        if (!mb[0]) continue;
        if (strstr(mb, "SignatureKiller")) continue;
        int w = snprintf(out + used, outn - used, "[%s]", mb);
        if (w <= 0 || (size_t)w >= outn - used) break;
        used += (size_t)w;
    }
    if (locked) pthread_mutex_unlock(&attr_mx);
}
#pragma GCC diagnostic pop
struct rxEnt { unsigned long s, e; char nm[128]; };
static struct rxEnt rxseen_[512];
static int rxseen_n = 0;
static int watcher_logged_ok = 0;
static char wbuf_[98304];
static void *watcherFn(void *a) {
    (void)a;
    pthread_setname_np(pthread_self(), "FFKWatch");
    for (;;) {
        struct timespec rq;
        rq.tv_sec = 0;
        rq.tv_nsec = 500000000L;
        nanosleep(&rq, NULL);
        if (!old_open || !old_read || !old_close) continue;
        int fd = old_open("/proc/self/maps", 0, 0);
        int total = 0;
        if (fd >= 0) {
            for (;;) {
                int n = (int)old_read(fd, wbuf_ + total, (int)sizeof(wbuf_) - 1 - total);
                if (n <= 0) break;
                total += n;
                if (total >= (int)sizeof(wbuf_) - 1) break;
            }
            old_close(fd);
        }
        if (total > 0) {
            wbuf_[total] = 0;
            if (!watcher_logged_ok) {
                watcher_logged_ok = 1;
                char wb[96];
                snprintf(wb, sizeof(wb), "watcher ok");
                LOGE("%s", wb);
                file_append(wb);
            }
            int logged = 0;
            char *ln = wbuf_;
            while (*ln) {
                char *nl = strchr(ln, '\n');
                if (nl) *nl = 0;
                unsigned long s = 0, e = 0;
                char perms[8];
                char path[192];
                perms[0] = 0;
                path[0] = 0;
                int r = sscanf(ln, "%lx-%lx %7s %*s %*s %*s %191s", &s, &e, perms, path);
                if (r >= 3 && e > s && perms[0] == 'r' && perms[2] == 'x') {
                    int seen = 0;
                    for (int j = 0; j < rxseen_n; j++) {
                        if (rxseen_[j].s == s && rxseen_[j].e == e) { seen = 1; break; }
                    }
                    if (!seen && rxseen_n < 512) {
                        rxseen_[rxseen_n].s = s;
                        rxseen_[rxseen_n].e = e;
                        const char *nm = path[0] ? path : "[anon]";
                        strncpy(rxseen_[rxseen_n].nm, nm, 127);
                        rxseen_[rxseen_n].nm[127] = 0;
                        rxseen_n++;
                        if (logged < 12) {
                            char msg[448];
                            if (!path[0])
                                snprintf(msg, sizeof(msg), "hidemod anon r-xp %lx-%lx", s, e);
                            else
                                snprintf(msg, sizeof(msg), "newrx %lx-%lx %s", s, e, nm);
                            LOGE("%s", msg);
                            file_append(msg);
                            logged++;
                        }
                    }
                }
                if (!nl) break;
                ln = nl + 1;
            }
        }
    }
    return NULL;
}
static int watcher_on = 0;
static void watcherStart(void) {
    if (watcher_on) return;
    watcher_on = 1;
    pthread_t t;
    pthread_create(&t, NULL, watcherFn, NULL);
    pthread_detach(t);
}

int (*old_open)(const char *, int, mode_t);
static int openImpl(const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_open(repPath__, flags, mode);
    if (interesting(pathname)) nlog("open", pathname);
    int r = old_open(pathname, flags, mode);
    repTrack(r, pathname);
    return r;
}

int (*old_open64)(const char *, int, mode_t);
static int open64Impl(const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_open64(repPath__, flags, mode);
    if (interesting(pathname)) nlog("open64", pathname);
    int r = old_open64(pathname, flags, mode);
    repTrack(r, pathname);
    return r;
}

int (*old_openat)(int, const char *, int, mode_t);
static int openatImpl(int fd, const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_openat(fd, repPath__, flags, mode);
    if (interesting(pathname)) nlog("openat", pathname);
    int r = old_openat(fd, pathname, flags, mode);
    repTrack(r, pathname);
    return r;
}

int (*old_openat64)(int, const char *, int, mode_t);
static int openat64Impl(int fd, const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_openat64(fd, repPath__, flags, mode);
    if (interesting(pathname)) nlog("openat64", pathname);
    int r = old_openat64(fd, pathname, flags, mode);
    repTrack(r, pathname);
    return r;
}

int (*old_access)(const char *, int);
static int accessImpl(const char *pathname, int mode_) {
    if (interesting(pathname)) nlog("access", pathname);
    return old_access(pathname, mode_);
}

static FILE *fopenImpl(const char *pathname, const char *mode_) {
    if (interesting(pathname)) nlog("fopen", pathname);
    FILE *f = old_fopen(pathname, mode_);
    if (f && pathname && repInterest(pathname) && !in_log) {
        int fd = fileno(f);
        repTrack(fd, pathname);
    }
    return f;
}

int (*old_stat)(const char *, struct stat *);
static int statImpl(const char *pathname, struct stat *buf) {
    if (interesting(pathname)) nlog("stat", pathname);
    return old_stat(pathname, buf);
}

int (*old_stat64)(const char *, void *);
static int stat64Impl(const char *pathname, void *buf) {
    if (interesting(pathname)) nlog("stat64", pathname);
    return old_stat64(pathname, buf);
}

int (*old_lstat)(const char *, struct stat *);
static int lstatImpl(const char *pathname, struct stat *buf) {
    if (interesting(pathname)) nlog("lstat", pathname);
    return old_lstat(pathname, buf);
}

int (*old_lstat64)(const char *, void *);
static int lstat64Impl(const char *pathname, void *buf) {
    if (interesting(pathname)) nlog("lstat64", pathname);
    return old_lstat64(pathname, buf);
}

int (*old_fstatat)(int, const char *, struct stat *, int);
static int fstatatImpl(int fd, const char *pathname, struct stat *buf, int flag) {
    if (interesting(pathname)) nlog("fstatat", pathname);
    return old_fstatat(fd, pathname, buf, flag);
}

int (*old_fstatat64)(int, const char *, void *, int);
static int fstatat64Impl(int fd, const char *pathname, void *buf, int flag) {
    if (interesting(pathname)) nlog("fstatat64", pathname);
    return old_fstatat64(fd, pathname, buf, flag);
}

int (*old_unlink)(const char *);
static int unlinkImpl(const char *pathname) {
    repDel(pathname);
    if (interesting(pathname)) nlog("unlink", pathname);
    return old_unlink(pathname);
}

int (*old_unlinkat)(int, const char *, int);
static int unlinkatImpl(int fd, const char *pathname, int flag) {
    repDel(pathname);
    if (interesting(pathname)) nlog("unlinkat", pathname);
    return old_unlinkat(fd, pathname, flag);
}

int (*old_rename)(const char *, const char *);
static int renameImpl(const char *oldp, const char *newp) {
    if (interesting(oldp) || interesting(newp)) {
        char buf[512];
        snprintf(buf, sizeof(buf), "rename %s -> %s", oldp ? oldp : "NULL", newp ? newp : "NULL");
        LOGE("%s", buf);
        file_append(buf);
    }
    return old_rename(oldp, newp);
}

int (*old_mkdir)(const char *, mode_t);
static int mkdirImpl(const char *pathname, mode_t mode) {
    if (interesting(pathname)) nlog("mkdir", pathname);
    return old_mkdir(pathname, mode);
}

static void dumpAnogsApi(void) {
    if (!old_dlsym || in_log) return;
    in_log = 1;
    for (int i = 0; anogs_syms[i]; i++) {
        void *a = old_dlsym(RTLD_DEFAULT, anogs_syms[i]);
        if (a) {
            char buf[256];
            snprintf(buf, sizeof(buf), "anogs_api %s=%p", anogs_syms[i], a);
            LOGE("%s", buf);
            file_append(buf);
        }
    }
    in_log = 0;
}
static void dumpAnogsFns(void) {
    if (in_log || !asym_n) return;
    in_log = 1;
    {
        int cap = asym_n > 400 ? 400 : asym_n;
        for (int k = 0; k < cap; k++) {
            char buf[160];
            snprintf(buf, sizeof(buf), "anogs_fn %s 0x%lx", asym_[k].name, asym_[k].a);
            in_log = 0;
            LOGE("%s", buf);
            file_append(buf);
            in_log = 1;
        }
    }
    {
        unsigned long sites[2] = {0x2f58acUL, 0x2f5410UL};
        for (int s = 0; s < 2; s++) {
            unsigned long ra = anogs_bias ? anogs_bias + sites[s] : 0;
            char mb[160];
            mb[0] = 0;
            if (ra && anogs_s && ra >= anogs_s && ra < anogs_e && asym_n > 0) {
                int lo = 0, hi = asym_n - 1, best = -1;
                while (lo <= hi) {
                    int m = (lo + hi) / 2;
                    if (asym_[m].a <= ra) { best = m; lo = m + 1; } else hi = m - 1;
                }
                if (best >= 0) snprintf(mb, sizeof(mb), "%s+0x%lx", asym_[best].name, ra - asym_[best].a);
                else snprintf(mb, sizeof(mb), "?+0x%lx", ra - anogs_s);
            }
            char sb[288];
            snprintf(sb, sizeof(sb), "anogs_site 0x%lx %s @0x%lx", sites[s], mb[0] ? mb : "?", ra);
            in_log = 0;
            LOGE("%s", sb);
            file_append(sb);
            in_log = 1;
        }
    }
    for (int j = 0; j < maps_n; j++) {
        if (!strstr(maps_[j].name, "anogs")) continue;
        const char *path = maps_[j].name;
        int fd = old_open(path, 0, 0);
        if (fd < 0) continue;
        unsigned char eh[64];
        if (readFull(fd, eh, 64) != 64 || eh[0] != 0x7f) { old_close(fd); continue; }
        unsigned long phoff = 0, shoff = 0;
        unsigned short phentsz = 0, phnum = 0, shentsz = 0, shnum = 0, shstr = 0;
        memcpy(&phoff, eh + 32, 8);
        memcpy(&phentsz, eh + 54, 2);
        memcpy(&phnum, eh + 56, 2);
        memcpy(&shoff, eh + 40, 8);
        memcpy(&shentsz, eh + 58, 2);
        memcpy(&shnum, eh + 60, 2);
        memcpy(&shstr, eh + 62, 2);
        if (phentsz == 56 && phnum > 0 && phnum <= 16) {
            lseek(fd, (off_t)phoff, SEEK_SET);
            for (unsigned q = 0; q < phnum; q++) {
                unsigned char ph[56];
                if (readFull(fd, ph, 56) != 56) break;
                unsigned pt = 0, pf = 0;
                unsigned long po = 0, pv = 0, pfsz = 0, pmsz = 0;
                memcpy(&pt, ph, 4);
                memcpy(&pf, ph + 4, 4);
                memcpy(&po, ph + 8, 8);
                memcpy(&pv, ph + 16, 8);
                memcpy(&pfsz, ph + 32, 8);
                memcpy(&pmsz, ph + 40, 8);
                char pb[192];
                snprintf(pb, sizeof(pb), "anogs_ph t=%u f=%u off=0x%lx v=0x%lx fsz=0x%lx msz=0x%lx",
                    pt, pf, po, pv, pfsz, pmsz);
                in_log = 0;
                LOGE("%s", pb);
                file_append(pb);
                in_log = 1;
            }
        }
        if (shentsz == 64 && shnum > 0 && shnum <= 64 && shstr < shnum) {
            lseek(fd, (off_t)shoff, SEEK_SET);
            if (readFull(fd, sh_, shnum * 64) == shnum * 64) {
                unsigned char *sn = sh_ + (unsigned long)shstr * 64;
                unsigned long bo = 0, bs = 0;
                memcpy(&bo, sn + 24, 8);
                memcpy(&bs, sn + 32, 8);
                if (bs > 0 && bs <= 8192) {
                    lseek(fd, (off_t)bo, SEEK_SET);
                    if (readFull(fd, (unsigned char *)shst_, (int)bs) == (int)bs) {
                        for (unsigned q = 0; q < shnum; q++) {
                            unsigned char *sc = sh_ + (unsigned long)q * 64;
                            unsigned nm = 0, ty = 0;
                            unsigned long of = 0, sz = 0;
                            memcpy(&nm, sc, 4);
                            memcpy(&ty, sc + 4, 4);
                            memcpy(&of, sc + 24, 8);
                            memcpy(&sz, sc + 32, 8);
                            const char *sname = nm < bs ? shst_ + nm : "";
                            char lb[160];
                            snprintf(lb, sizeof(lb), "anogs_sh %.48s t=%u off=0x%lx sz=0x%lx", sname, ty, of, sz);
                            in_log = 0;
                            LOGE("%s", lb);
                            file_append(lb);
                            in_log = 1;
                        }
                    }
                }
            }
        }
        {
            unsigned long sites[2] = {0x2f58acUL, 0x2f5410UL};
            for (int s = 0; s < 2; s++) {
                lseek(fd, (off_t)sites[s], SEEK_SET);
                unsigned char tb[96];
                int n = readFull(fd, tb, 96);
                if (n > 0) {
                    for (int o = 0; o < n; o += 32) {
                        int m = n - o > 32 ? 32 : n - o;
                        char hx[65];
                        for (int q = 0; q < m; q++) {
                            hx[q * 2] = "0123456789abcdef"[tb[o + q] >> 4];
                            hx[q * 2 + 1] = "0123456789abcdef"[tb[o + q] & 15];
                        }
                        hx[m * 2] = 0;
                        char tl[160];
                        snprintf(tl, sizeof(tl), "anogs_tx 0x%lx+%d %s", sites[s], o, hx);
                        in_log = 0;
                        LOGE("%s", tl);
                        file_append(tl);
                        in_log = 1;
                    }
                }
            }
        }
        old_close(fd);
        break;
    }
    in_log = 0;
}
static void setupAnogsIfPresent(void) {
    for (int j = 0; j < maps_n; j++) {
        if (strstr(maps_[j].name, "anogs")) {
            dumpAnogsSegs();
            dumpAnogsApi();
            setupAnogs();
            break;
        }
    }
}
void *(*old_dlopen)(const char *, int);
static void *dlopenImpl(const char *filename, int flags) {
    nlog("dlopen", filename ? filename : "NULL");
    if (filename && strstr(filename, "anogs")) {
        dumpAnogsSegs();
        dumpAnogsApi();
        setupAnogs();
    }
    return old_dlopen(filename, flags);
}

void *(*old_android_dlopen_ext)(const char *, int, const void *);
static void *android_dlopen_extImpl(const char *filename, int flags, const void *extinfo) {
    (void)extinfo;
    nlog("dlopen_ext", filename ? filename : "NULL");
    if (filename && strstr(filename, "anogs")) {
        dumpAnogsSegs();
        dumpAnogsApi();
        setupAnogs();
    }
    return old_android_dlopen_ext(filename, flags, extinfo);
}

int (*old_socket)(int, int, int);
static int socketImpl(int domain, int type, int proto) {
    int fd = old_socket(domain, type, proto);
    if (fd >= 0) {
        trackAdd(fd);
        char buf[80];
        snprintf(buf, sizeof(buf), "socket fd=%d dom=%d type=%d", fd, domain, type);
        LOGE("%s", buf);
        file_append(buf);
    }
    return fd;
}

int (*old_close)(int);
static int closeImpl(int fd) {
    int r = old_close(fd);
    if (fd >= 0 && fd < 1024) { fdp_[fd][0] = 0; repwc_[fd] = 0; }
    if (trackHas(fd)) {
        char buf[160];
        snprintf(buf, sizeof(buf), "close fd=%d pkts=%u peer=%s",
            fd, sockcnt[fd], sockpeer[fd][0] ? sockpeer[fd] : "?");
        LOGE("%s", buf);
        file_append(buf);
        trackDel(fd);
    }
    return r;
}

int (*old_connect)(int, const struct sockaddr *, socklen_t);
static int connectImpl(int fd, const struct sockaddr *addr, socklen_t len) {
    char peer[96];
    if (sockfmt(addr, len, peer, sizeof(peer))) {
        char buf[224];
        snprintf(buf, sizeof(buf), "connect fd=%d %s", fd, peer);
        LOGE("%s", buf);
        file_append(buf);
        trackPeer(fd, peer);
    }
    return old_connect(fd, addr, len);
}

ssize_t (*old_sendto)(int, const void *, size_t, int, const struct sockaddr *, socklen_t);
static ssize_t sendtoImpl(int fd, const void *buf_, size_t len, int flags,
        const struct sockaddr *addr, socklen_t alen) {
    char peer[96];
    if (sockfmt(addr, alen, peer, sizeof(peer))) {
        trackPeer(fd, peer);
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)len))
            pktlog("pkt out", fd, peer, (long)len, (const unsigned char *)buf_, c <= 30);
    } else if (trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)len))
            pktlog("pkt out", fd, sockpeer[fd], (long)len, (const unsigned char *)buf_, c <= 30);
    }
    mirror("pktout", fd, (const unsigned char *)buf_, (long)len, (long)len);
    return old_sendto(fd, buf_, len, flags, addr, alen);
}

ssize_t (*old_sendmsg)(int, const struct msghdr *, int);
static ssize_t sendmsgImpl(int fd, const struct msghdr *msg, int flags) {
    if (trackHas(fd) || (msg && msg->msg_name)) {
        size_t total = 0;
        if (msg) {
            size_t n = msg->msg_iovlen > 8 ? 8 : msg->msg_iovlen;
            if (msg->msg_iov) for (size_t i = 0; i < n; i++) total += msg->msg_iov[i].iov_len;
        }
        const char *peer = sockpeer[fd];
        char tmp[96];
        if (msg && msg->msg_name &&
                sockfmt((const struct sockaddr *)msg->msg_name, msg->msg_namelen, tmp, sizeof(tmp))) {
            trackPeer(fd, tmp);
            peer = tmp;
        }
        unsigned c = trackBump(fd);
        if (c <= 30 || c % 50 == 0)
            pktlog("pkt out", fd, peer, (long)total, NULL, 0);
        if (msg && msg->msg_iov && msg->msg_iovlen > 0 && msg->msg_iov[0].iov_base)
            mirror("pktout", fd, (const unsigned char *)msg->msg_iov[0].iov_base,
                (long)msg->msg_iov[0].iov_len, (long)total);
    }
    return old_sendmsg(fd, msg, flags);
}

ssize_t (*old_send)(int, const void *, size_t, int);
static ssize_t sendImpl(int fd, const void *buf_, size_t len, int flags) {
    if (trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)len))
            pktlog("pkt out", fd, sockpeer[fd], (long)len, (const unsigned char *)buf_, c <= 30);
    }
    mirror("pktout", fd, (const unsigned char *)buf_, (long)len, (long)len);
    return old_send(fd, buf_, len, flags);
}

ssize_t (*old_recv)(int, void *, size_t, int);
static ssize_t recvImpl(int fd, void *buf_, size_t len, int flags) {
    ssize_t r = old_recv(fd, buf_, len, flags);
    if (r > 0 && trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)r))
            pktlog("pkt in", fd, sockpeer[fd], (long)r, (const unsigned char *)buf_, c <= 30);
    }
    if (r > 0) mirror("pktin", fd, (const unsigned char *)buf_, r, r);
    return r;
}

ssize_t (*old_recvfrom)(int, void *, size_t, int, struct sockaddr *, socklen_t *);
static ssize_t recvfromImpl(int fd, void *buf_, size_t len, int flags,
        struct sockaddr *addr, socklen_t *alen) {
    ssize_t r = old_recvfrom(fd, buf_, len, flags, addr, alen);
    if (r > 0 && trackHas(fd)) {
        char tmp[96];
        const char *peer = sockpeer[fd];
        if (addr && alen && sockfmt(addr, *alen, tmp, sizeof(tmp)))
            peer = tmp;
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)r))
            pktlog("pkt in", fd, peer, (long)r, (const unsigned char *)buf_, c <= 30);
    }
    if (r > 0) mirror("pktin", fd, (const unsigned char *)buf_, r, r);
    return r;
}

ssize_t (*old_recvmsg)(int, struct msghdr *, int);
static ssize_t recvmsgImpl(int fd, struct msghdr *msg, int flags) {
    ssize_t r = old_recvmsg(fd, msg, flags);
    if (r > 0 && trackHas(fd)) {
        const char *peer = sockpeer[fd];
        char tmp[96];
        if (msg && msg->msg_name &&
                sockfmt((const struct sockaddr *)msg->msg_name, msg->msg_namelen, tmp, sizeof(tmp)))
            peer = tmp;
        const unsigned char *sample = NULL;
        if (msg && msg->msg_iovlen > 0 && msg->msg_iov) sample = (const unsigned char *)msg->msg_iov[0].iov_base;
        unsigned c = trackBump(fd);
        if (c <= 30 || c % 50 == 0)
            pktlog("pkt in", fd, peer, (long)r, sample, c <= 30);
        if (r > 0 && sample && msg && msg->msg_iov && msg->msg_iovlen > 0) {
            long seg0 = (long)msg->msg_iov[0].iov_len;
            if (seg0 > r) seg0 = r;
            mirror("pktin", fd, sample, seg0, r);
        }
    }
    return r;
}

ssize_t (*old_read)(int, void *, size_t);
static ssize_t readImpl(int fd, void *buf_, size_t n) {
    ssize_t r = old_read(fd, buf_, n);
    if (r > 0 && trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)r))
            pktlog("pkt in", fd, sockpeer[fd], (long)r, (const unsigned char *)buf_, c <= 30);
    }
    if (r > 0) mirror("pktin", fd, (const unsigned char *)buf_, r, r);
    if (r > 0) repBody("repr", fd, (const unsigned char *)buf_, r);
    return r;
}

static ssize_t writeImpl(int fd, const void *buf_, size_t n) {
    if (trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)n))
            pktlog("pkt out", fd, sockpeer[fd], (long)n, (const unsigned char *)buf_, c <= 30);
    }
    mirror("pktout", fd, (const unsigned char *)buf_, (long)n, (long)n);
    ssize_t r = old_write(fd, buf_, n);
    if (r > 0) repBody("repw", fd, (const unsigned char *)buf_, (long)n);
    return r;
}

int (*old_getaddrinfo)(const char *, const char *, const struct addrinfo *, struct addrinfo **);
static int getaddrinfoImpl(const char *node, const char *service,
        const struct addrinfo *hints, struct addrinfo **res) {
    if (node) {
        char buf[448];
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        snprintf(buf, sizeof(buf), "dns %s%s", node, at);
        LOGE("%s", buf);
        file_append(buf);
    }
    return old_getaddrinfo(node, service, hints, res);
}

static void UnitySendMessageImpl(const char *obj, const char *method, const char *msg);
static void (*usm_real)(const char *, const char *, const char *);
static int usm_armed = 0;
static int dlsymWatch(const char *s) {
    if (!s || !s[0]) return 0;
    static const char *kws[] = {"report", "complaint", "scan", "cheat", "hack", "ban",
        "suspend", "integrity", "tdm", "anosdk", "detect", "violat", NULL};
    for (int w = 0; kws[w]; w++) {
        const char *kw = kws[w];
        size_t kl = strlen(kw);
        for (const char *p = s; *p; p++) {
            size_t i = 0;
            while (i < kl && p[i]) {
                char a = p[i], b = kw[i];
                if (a >= 'A' && a <= 'Z') a += 32;
                if (a != b) break;
                i++;
            }
            if (i == kl) return 1;
        }
    }
    return 0;
}
static void *dlsymImpl(void *handle, const char *sym) {
    if (dlsymInteresting(sym) && !in_log) nlog("dlsym", sym);
    void *r = old_dlsym(handle, sym);
    if (r && sym && !strcmp(sym, "UnitySendMessage")) {
        usm_real = (void (*)(const char *, const char *, const char *))r;
        if (!usm_armed) {
            usm_armed = 1;
            if (!in_log) {
                char ab[96];
                snprintf(ab, sizeof(ab), "usm_armed %p", r);
                LOGE("%s", ab);
                file_append(ab);
            }
        }
        return r;
    }
    if (r && sym && dlsymWatch(sym) && !in_log) {
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        char wb[512];
        snprintf(wb, sizeof(wb), "watch HIT %s -> %p%s", sym, r, at);
        LOGE("%s", wb);
        file_append(wb);
    }
    if (r && dlsymInteresting(sym) && !in_log) {
        char mb[160];
        if (pthread_mutex_trylock(&attr_mx) == 0) {
            modTag((unsigned long)r, mb, sizeof(mb));
            pthread_mutex_unlock(&attr_mx);
        } else mb[0] = 0;
        char buf[448];
        snprintf(buf, sizeof(buf), "dlsym_ret %s -> %p %s", sym, r, mb[0] ? mb : "?");
        LOGE("%s", buf);
        file_append(buf);
    }
    return r;
}

int (*old_ioctl)(int, unsigned long, void *);
static unsigned ioctl_seen[1024];
static int ioctlImpl(int fd, unsigned long req, void *arg) {
    unsigned c = (fd >= 0 && fd < 1024) ? ++ioctl_seen[fd] : 999;
    if (c <= 12) {
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        char buf[320];
        snprintf(buf, sizeof(buf), "ioctl fd=%d req=0x%lx%s", fd, req, at);
        LOGE("%s", buf);
        file_append(buf);
    }
    return old_ioctl(fd, req, arg);
}

void (*old_UnitySendMessage)(const char *, const char *, const char *);
static char usm_last[256];
static unsigned usm_rep = 0;
static void UnitySendMessageImpl(const char *obj, const char *method, const char *msg) {
    char key[256];
    snprintf(key, sizeof(key), "%.100s|%.100s", obj ? obj : "?", method ? method : "?");
    if (!strcmp(key, usm_last)) {
        usm_rep++;
    } else {
        if (usm_rep) {
            char rb[320];
            snprintf(rb, sizeof(rb), "usmsame %s x%u", usm_last, usm_rep + 1);
            LOGE("%s", rb);
            file_append(rb);
        }
        strncpy(usm_last, key, sizeof(usm_last) - 1);
        usm_last[sizeof(usm_last) - 1] = 0;
        usm_rep = 0;
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        char buf[1536];
        size_t ml = msg ? strnlen(msg, 1024) : 0;
        char mcpy[1025];
        if (ml) { strncpy(mcpy, msg, ml); mcpy[ml] = 0; } else mcpy[0] = 0;
        snprintf(buf, sizeof(buf), "usm %s m=%s%s", key, mcpy, at);
        LOGE("%s", buf);
        file_append(buf);
        if (msg && ml) sieve("usm", (const unsigned char *)msg, (long)ml);
    }
    if (usm_real) usm_real(obj, method, msg);
    else if (old_UnitySendMessage) old_UnitySendMessage(obj, method, msg);
}

int (*old_pthread_create)(void *, const void *, void *(*)(void *), void *);
static int pthread_createImpl(void *t, const void *a, void *(*fn)(void *), void *arg) {
    char buf[320];
    char mb[192];
    mb[0] = 0;
    if (fn && pthread_mutex_trylock(&attr_mx) == 0) {
        char tmp[160];
        modTag((unsigned long)fn, tmp, sizeof(tmp));
        pthread_mutex_unlock(&attr_mx);
        if (tmp[0]) snprintf(mb, sizeof(mb), " mod=%s", tmp);
    }
    snprintf(buf, sizeof(buf), "thread start=%p%s", (void *)fn, mb);
    LOGE("%s", buf);
    file_append(buf);
    return old_pthread_create(t, a, fn, arg);
}

static unsigned sslw_n = 0, sslr_n = 0, mbw_n = 0, mbr_n = 0;

static void tlslog(const char *dir, long n, const unsigned char *data, int withHex) {
    char hx[97];
    char msg[384];
    if (withHex && data && n > 0) {
        long m = n > 48 ? 48 : n;
        static const char *h = "0123456789abcdef";
        for (long i = 0; i < m; i++) {
            hx[i * 2] = h[data[i] >> 4];
            hx[i * 2 + 1] = h[data[i] & 15];
        }
        hx[m * 2] = 0;
    } else hx[0] = 0;
    snprintf(msg, sizeof(msg), "%s n=%ld hx=%s", dir, n, hx);
    LOGE("%s", msg);
    file_append(msg);
}

int (*old_SSL_write)(void *, const void *, int);
static int SSL_writeImpl(void *s, const void *b, int n) {
    unsigned c = ++sslw_n;
    if (n > 0 && 0 && (c <= 20 || c % 200 == 0))
        tlslog("tls_plain out", (long)n, (const unsigned char *)b, c <= 20);
    return old_SSL_write(s, b, n);
}

int (*old_SSL_read)(void *, void *, int);
static int SSL_readImpl(void *s, void *b, int n) {
    int r = old_SSL_read(s, b, n);
    if (r > 0) {
        unsigned c = ++sslr_n;
        if (0 && (c <= 20 || c % 200 == 0))
            tlslog("tls_plain in", (long)r, (const unsigned char *)b, c <= 20);
    }
    return r;
}

int (*old_mbedtls_ssl_write)(void *, const unsigned char *, unsigned long);
static int mbedtls_ssl_writeImpl(void *c_, const unsigned char *b, unsigned long n) {
    unsigned c = ++mbw_n;
    if (n > 0 && 0 && (c <= 20 || c % 200 == 0))
        tlslog("tls_plain out", (long)n, b, c <= 20);
    return old_mbedtls_ssl_write(c_, b, n);
}

int (*old_mbedtls_ssl_read)(void *, unsigned char *, unsigned long);
static int mbedtls_ssl_readImpl(void *c_, unsigned char *b, unsigned long n) {
    int r = old_mbedtls_ssl_read(c_, b, n);
    if (r > 0) {
        unsigned c = ++mbr_n;
        if (0 && (c <= 20 || c % 200 == 0))
            tlslog("tls_plain in", (long)r, b, c <= 20);
    }
    return r;
}

void (*old_exit)(int);
static void exitImpl(int code) {
    if (1) {
        char bt[640];
        deathBt(bt, sizeof(bt));
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        char buf[1024];
        snprintf(buf, sizeof(buf), "proc_exit exit code=%d%s bt=%s", code, at, bt);
        LOGE("%s", buf);
        file_append(buf);
        dumpRing();
    }
    old_exit(code);
}
void (*old__exit)(int);
static void _exitImpl(int code) {
    if (1) {
        char bt[640];
        deathBt(bt, sizeof(bt));
        char buf[768];
        snprintf(buf, sizeof(buf), "proc_exit _exit code=%d bt=%s", code, bt);
        LOGE("%s", buf);
        file_append(buf);
        dumpRing();
    }
    old__exit(code);
}
void (*old_abort)(void);
static void abortImpl(void) {
    if (1) {
        char bt[640];
        deathBt(bt, sizeof(bt));
        char buf[768];
        snprintf(buf, sizeof(buf), "proc_exit abort bt=%s", bt);
        LOGE("%s", buf);
        file_append(buf);
        dumpRing();
    }
    old_abort();
}
int (*old_kill)(pid_t, int);
static int killImpl(pid_t pid, int sig) {
    if (1) {
        char bt[640];
        deathBt(bt, sizeof(bt));
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        char buf[1024];
        snprintf(buf, sizeof(buf), "kill pid=%d sig=%d%s bt=%s", (int)pid, sig, at, bt);
        LOGE("%s", buf);
        file_append(buf);
        dumpRing();
    }
    return old_kill(pid, sig);
}
void (*old_pthread_exit)(void *);
static void pthread_exitImpl(void *v) {
    if (1) {
        char bt[640];
        deathBt(bt, sizeof(bt));
        char buf[768];
        snprintf(buf, sizeof(buf), "proc_exit pthread_exit bt=%s", bt);
        LOGE("%s", buf);
        file_append(buf);
        dumpRing();
    }
    old_pthread_exit(v);
}
int (*old___android_log_print)(int, const char *, const char *, ...);
static int (*vprint_)(int, const char *, const char *, va_list) = NULL;
static int alogImpl(int prio, const char *tag, const char *fmt, ...) {
    char msg[2048];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt ? fmt : "", ap);
    if (!in_log && tag && tag[0] && strcmp(tag, "FFKN") != 0 &&
            !(tag[0] == 'F' && tag[1] == 'F' && tag[2] == 'K')) {
        if (1) {
            char line[2300];
            snprintf(line, sizeof(line), "alog %d %s %s", prio, tag, msg);
            LOGE("%s", line);
            file_append(line);
        }
        sieve("alog", (const unsigned char *)msg, (long)strlen(msg));
    }
    int r;
    if (!vprint_ && old_dlsym)
        vprint_ = (int (*)(int, const char *, const char *, va_list))old_dlsym(RTLD_DEFAULT, "__android_log_vprint");
    if (vprint_) {
        va_list aq;
        va_copy(aq, ap);
        r = vprint_(prio, tag, fmt ? fmt : "", aq);
        va_end(aq);
    } else {
        r = old___android_log_print(prio, tag, "%s", msg);
    }
    va_end(ap);
    return r;
}
size_t (*old_fwrite)(const void *, size_t, size_t, FILE *);
static size_t fwriteImpl(const void *p, size_t sz, size_t n, FILE *f) {
    if (!in_log && p && sz && n) {
        unsigned long total = (unsigned long)sz * n;
        if (total >= 4)
            sieve("fwrite", (const unsigned char *)p, total > 512 ? 512 : (long)total);
    }
    return old_fwrite(p, sz, n, f);
}
int (*old_fputs)(const char *, FILE *);
static int fputsImpl(const char *s, FILE *f) {
    if (!in_log && s) {
        size_t l = strnlen(s, 513);
        if (l >= 4) sieve("fputs", (const unsigned char *)s, l > 512 ? 512 : (long)l);
    }
    return old_fputs(s, f);
}
int (*old_dlclose)(void *);
static int dlcloseImpl(void *h) {
    if (!in_log && h) {
        char buf[128];
        snprintf(buf, sizeof(buf), "dlclose %p", h);
        LOGE("%s", buf);
        file_append(buf);
    }
    return old_dlclose(h);
}
int (*old_close_range)(unsigned, unsigned, int);
static int close_rangeImpl(unsigned fd, unsigned max, int flags) {
    int r = old_close_range(fd, max, flags);
    unsigned lo = fd < 1024 ? fd : 1024, hi = max < 1024 ? max : 1024;
    for (unsigned i = lo; i <= hi && i < 1024; i++) { fdp_[i][0] = 0; repwc_[i] = 0; }
    return r;
}
int (*old_dup2)(int, int);
static int dup2Impl(int o, int n) {
    int r = old_dup2(o, n);
    if (n >= 0 && n < 1024 && !in_log) {
        fdp_[n][0] = 0; repwc_[n] = 0;
        if (o >= 0 && o < 1024 && fdp_[o][0]) {
            strncpy(fdp_[n], fdp_[o], 191);
            fdp_[n][191] = 0;
            repwc_[n] = repwc_[o];
        }
    }
    return r;
}
int (*old_dup3)(int, int, int);
static int dup3Impl(int o, int n, int flags) {
    int r = old_dup3(o, n, flags);
    if (n >= 0 && n < 1024 && !in_log) {
        fdp_[n][0] = 0; repwc_[n] = 0;
        if (o >= 0 && o < 1024 && fdp_[o][0]) {
            strncpy(fdp_[n], fdp_[o], 191);
            fdp_[n][191] = 0;
            repwc_[n] = repwc_[o];
        }
    }
    return r;
}
static void reg_all(void) {
    xhook_register(".*\\.so$", "openat64", (void *)openat64Impl, (void **)&old_openat64);
    xhook_register(".*\\.so$", "openat", (void *)openatImpl, (void **)&old_openat);
    xhook_register(".*\\.so$", "open64", (void *)open64Impl, (void **)&old_open64);
    xhook_register(".*\\.so$", "open", (void *)openImpl, (void **)&old_open);
    xhook_register(".*\\.so$", "access", (void *)accessImpl, (void **)&old_access);
    xhook_register(".*\\.so$", "fopen", (void *)fopenImpl, (void **)&old_fopen);
    xhook_register(".*\\.so$", "stat", (void *)statImpl, (void **)&old_stat);
    xhook_register(".*\\.so$", "stat64", (void *)stat64Impl, (void **)&old_stat64);
    xhook_register(".*\\.so$", "lstat", (void *)lstatImpl, (void **)&old_lstat);
    xhook_register(".*\\.so$", "lstat64", (void *)lstat64Impl, (void **)&old_lstat64);
    xhook_register(".*\\.so$", "fstatat", (void *)fstatatImpl, (void **)&old_fstatat);
    xhook_register(".*\\.so$", "fstatat64", (void *)fstatat64Impl, (void **)&old_fstatat64);
    xhook_register(".*\\.so$", "unlink", (void *)unlinkImpl, (void **)&old_unlink);
    xhook_register(".*\\.so$", "unlinkat", (void *)unlinkatImpl, (void **)&old_unlinkat);
    xhook_register(".*\\.so$", "rename", (void *)renameImpl, (void **)&old_rename);
    xhook_register(".*\\.so$", "mkdir", (void *)mkdirImpl, (void **)&old_mkdir);
    xhook_register(".*\\.so$", "dlopen", (void *)dlopenImpl, (void **)&old_dlopen);
    xhook_register(".*\\.so$", "android_dlopen_ext", (void *)android_dlopen_extImpl, (void **)&old_android_dlopen_ext);
    xhook_register(".*\\.so$", "socket", (void *)socketImpl, (void **)&old_socket);
    xhook_register(".*\\.so$", "close", (void *)closeImpl, (void **)&old_close);
    xhook_register(".*\\.so$", "close_range", (void *)close_rangeImpl, (void **)&old_close_range);
    xhook_register(".*\\.so$", "dup2", (void *)dup2Impl, (void **)&old_dup2);
    xhook_register(".*\\.so$", "dup3", (void *)dup3Impl, (void **)&old_dup3);
    xhook_register(".*\\.so$", "connect", (void *)connectImpl, (void **)&old_connect);
    xhook_register(".*\\.so$", "sendto", (void *)sendtoImpl, (void **)&old_sendto);
    xhook_register(".*\\.so$", "sendmsg", (void *)sendmsgImpl, (void **)&old_sendmsg);
    xhook_register(".*\\.so$", "send", (void *)sendImpl, (void **)&old_send);
    xhook_register(".*\\.so$", "recv", (void *)recvImpl, (void **)&old_recv);
    xhook_register(".*\\.so$", "recvfrom", (void *)recvfromImpl, (void **)&old_recvfrom);
    xhook_register(".*\\.so$", "recvmsg", (void *)recvmsgImpl, (void **)&old_recvmsg);
    xhook_register(".*\\.so$", "read", (void *)readImpl, (void **)&old_read);
    xhook_register(".*\\.so$", "write", (void *)writeImpl, (void **)&old_write);
    xhook_register(".*\\.so$", "getaddrinfo", (void *)getaddrinfoImpl, (void **)&old_getaddrinfo);
    xhook_register(".*\\.so$", "dlsym", (void *)dlsymImpl, (void **)&old_dlsym);
    xhook_register(".*\\.so$", "pthread_create", (void *)pthread_createImpl, (void **)&old_pthread_create);
    xhook_register(".*\\.so$", "SSL_write", (void *)SSL_writeImpl, (void **)&old_SSL_write);
    xhook_register(".*\\.so$", "SSL_read", (void *)SSL_readImpl, (void **)&old_SSL_read);
    xhook_register(".*\\.so$", "mbedtls_ssl_write", (void *)mbedtls_ssl_writeImpl, (void **)&old_mbedtls_ssl_write);
    xhook_register(".*\\.so$", "mbedtls_ssl_read", (void *)mbedtls_ssl_readImpl, (void **)&old_mbedtls_ssl_read);
    xhook_register(".*\\.so$", "exit", (void *)exitImpl, (void **)&old_exit);
    xhook_register(".*\\.so$", "_exit", (void *)_exitImpl, (void **)&old__exit);
    xhook_register(".*\\.so$", "abort", (void *)abortImpl, (void **)&old_abort);
    xhook_register(".*\\.so$", "kill", (void *)killImpl, (void **)&old_kill);
    xhook_register(".*\\.so$", "pthread_exit", (void *)pthread_exitImpl, (void **)&old_pthread_exit);
    xhook_register(".*\\.so$", "dlclose", (void *)dlcloseImpl, (void **)&old_dlclose);
    xhook_register(".*\\.so$", "__android_log_print", (void *)alogImpl, (void **)&old___android_log_print);
    xhook_register(".*\\.so$", "fwrite", (void *)fwriteImpl, (void **)&old_fwrite);
    xhook_register(".*\\.so$", "fputs", (void *)fputsImpl, (void **)&old_fputs);
    xhook_register(".*\\.so$", "ioctl", (void *)ioctlImpl, (void **)&old_ioctl);
    xhook_register(".*\\.so$", "UnitySendMessage", (void *)UnitySendMessageImpl, (void **)&old_UnitySendMessage);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)vm;
    (void)reserved;
    reg_all();
    xhook_refresh(0);
    LOGE("ffkn on");
    file_append("ffkn on");
    {
        int mn = refreshMaps();
        char mb[96];
        snprintf(mb, sizeof(mb), "maps ok n=%d", mn);
        LOGE("%s", mb);
        file_append(mb);
    }
    setupAnogsIfPresent();
    watcherStart();
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_ff_killer_Killer_hookApkPath(JNIEnv *env, __attribute__((unused)) jclass clazz, jstring apkPath, jstring repPath) {
    apkPath__ = (*env)->GetStringUTFChars(env, apkPath, 0);
    repPath__ = (*env)->GetStringUTFChars(env, repPath, 0);
    LOGE("ffkn paths set");
    reg_all();
    xhook_refresh(0);
    {
        int mn = refreshMaps();
        char mb[96];
        snprintf(mb, sizeof(mb), "maps ok n=%d", mn);
        LOGE("%s", mb);
        file_append(mb);
    }
    setupAnogsIfPresent();
    watcherStart();
}
