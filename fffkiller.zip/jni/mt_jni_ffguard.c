#include <jni.h>
#include <android/log.h>
#include <string.h>
#include <stdio.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include "xhook.h"

#define TAG "FFKN"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static const char *apkPath__ = NULL;
static const char *repPath__ = NULL;

static void file_append(const char *line);
void *(*old_dlsym)(void *, const char *);
int (*old_open)(const char *, int, mode_t);
ssize_t (*old_read)(int, void *, size_t);
int (*old_close)(int);

static unsigned sockbits[32];
static unsigned sockcnt[1024];
static char sockpeer[1024][64];

static inline void trackAdd(int fd) {
    if (fd >= 0 && fd < 1024) sockbits[fd >> 5] |= 1u << (fd & 31);
}
static inline void trackDel(int fd) {
    if (fd >= 0 && fd < 1024) {
        sockbits[fd >> 5] &= ~(1u << (fd & 31));
        sockcnt[fd] = 0;
        sockpeer[fd][0] = 0;
    }
}
static inline int trackHas(int fd) {
    return fd >= 0 && fd < 1024 && ((sockbits[fd >> 5] >> (fd & 31)) & 1u);
}
static inline void trackPeer(int fd, const char *s) {
    if (fd >= 0 && fd < 1024 && s) {
        strncpy(sockpeer[fd], s, 63);
        sockpeer[fd][63] = 0;
    }
}
static inline unsigned trackBump(int fd) {
    if (fd < 0 || fd >= 1024) return 0;
    return ++sockcnt[fd];
}

static void hex16(const unsigned char *p, long len, char *out) {
    static const char *h = "0123456789abcdef";
    long n = len > 16 ? 16 : len;
    for (long i = 0; i < n; i++) {
        out[i * 2] = h[p[i] >> 4];
        out[i * 2 + 1] = h[p[i] & 15];
    }
    out[n * 2] = 0;
}

static int interesting(const char *p) {
    if (!p) return 0;
    if (strstr(p, "maps")) return 1;
    if (strstr(p, "task")) return 1;
    if (strstr(p, "status")) return 1;
    if (strstr(p, "cmdline")) return 1;
    if (strstr(p, "anogs")) return 1;
    if (strstr(p, "anort")) return 1;
    if (strstr(p, "ob_x")) return 1;
    if (strstr(p, "vm_rom")) return 1;
    if (strstr(p, "scan")) return 1;
    if (strstr(p, "report")) return 1;
    if (strstr(p, "crash")) return 1;
    if (strstr(p, "tdm")) return 1;
    if (strstr(p, "complaint")) return 1;
    if (strstr(p, "origin")) return 1;
    if (strstr(p, "killer")) return 1;
    if (strstr(p, "Killer")) return 1;
    if (strstr(p, "hook")) return 1;
    if (strstr(p, "unsafe")) return 1;
    if (strstr(p, "ff_")) return 1;
    if (strstr(p, ".so")) return 1;
    if (strstr(p, ".dex")) return 1;
    if (strstr(p, ".apk")) return 1;
    if (strstr(p, ".odex")) return 1;
    if (strstr(p, ".vdex")) return 1;
    return 0;
}

FILE *(*old_fopen)(const char *, const char *);

static int dlsymInteresting(const char *s) {
    if (!s) return 0;
    if (interesting(s)) return 1;
    if (strstr(s, "Ano")) return 1;
    if (strstr(s, "TDM") || strstr(s, "tdm")) return 1;
    if (strstr(s, "Report") || strstr(s, "report")) return 1;
    if (strstr(s, "Complaint")) return 1;
    if (strstr(s, "Scan") || strstr(s, "scan")) return 1;
    if (strstr(s, "Cheat") || strstr(s, "cheat")) return 1;
    if (strstr(s, "Hack") || strstr(s, "hack")) return 1;
    if (strstr(s, "Integrity")) return 1;
    if (strstr(s, "il2cpp")) return 1;
    if (strstr(s, "unity") || strstr(s, "Unity")) return 1;
    return 0;
}
static __thread int in_log = 0;
static const char *baseName(const char *p) {
    const char *b = strrchr(p, '/');
    return b ? b + 1 : p;
}
struct mapEnt { unsigned long s, e; char name[192]; };
static struct mapEnt maps_[384];
static int maps_n = 0;
static unsigned long anogs_s = 0, anogs_e = 0;
static char rb_[98304];
static void refreshMaps(void) {
    if (in_log) return;
    if (!old_open || !old_read || !old_close) return;
    in_log = 1;
    maps_n = 0;
    anogs_s = 0;
    anogs_e = 0;
    int fd = old_open("/proc/self/maps", 0, 0);
    if (fd >= 0) {
        int total = 0;
        for (;;) {
            int n = (int)old_read(fd, rb_ + total, (int)sizeof(rb_) - 1 - total);
            if (n <= 0) break;
            total += n;
            if (total >= (int)sizeof(rb_) - 1) break;
        }
        old_close(fd);
        if (total > 0) {
            rb_[total] = 0;
            char *ln = rb_;
            while (*ln && maps_n < 384) {
                char *nl = strchr(ln, '\n');
                if (nl) *nl = 0;
                unsigned long s = 0, e = 0;
                char perms[8];
                char path[192];
                perms[0] = 0;
                path[0] = 0;
                int r = sscanf(ln, "%lx-%lx %7s %*s %*s %*s %191s", &s, &e, perms, path);
                if (r >= 4 && e > s && path[0] == '/') {
                    maps_[maps_n].s = s;
                    maps_[maps_n].e = e;
                    strncpy(maps_[maps_n].name, path, 191);
                    maps_[maps_n].name[191] = 0;
                    maps_n++;
                    if (strstr(path, "anogs")) {
                        if (!anogs_s || s < anogs_s) anogs_s = s;
                        if (e > anogs_e) anogs_e = e;
                    }
                }
                if (!nl) break;
                ln = nl + 1;
            }
        }
    }
    in_log = 0;
}
static const char *anogs_syms[] = {
    "AnoSDKGetReportData1", "AnoSDKGetReportData2",
    "AnoSDKGetReportData3", "AnoSDKGetReportData4",
    "AnoSDKDelReportData", "AnoSDKInit", "AnoSDKStart",
    "tdm_report", "ReportComplaint", NULL
};
struct symEnt { unsigned long a; char name[64]; };
static struct symEnt asym_[2048];
static int asym_n = 0;
static int cmpSym(const void *x, const void *y) {
    unsigned long a = ((const struct symEnt *)x)->a;
    unsigned long b = ((const struct symEnt *)y)->a;
    return a < b ? -1 : a > b ? 1 : 0;
}
static int readFull(int fd, unsigned char *o, int n) {
    int got = 0;
    while (got < n) {
        int r = (int)old_read(fd, o + got, n - got);
        if (r <= 0) break;
        got += r;
    }
    return got;
}
static unsigned char sh_[4096];
static char shst_[8192];
static char dst_[262144];
static void loadAnogsSyms(const char *path) {
    asym_n = 0;
    if (!path || !old_open || !old_read || !old_close || !old_dlsym) return;
    int fd = old_open(path, 0, 0);
    if (fd < 0) return;
    unsigned char eh[64];
    if (readFull(fd, eh, 64) != 64 || eh[0] != 0x7f || eh[1] != 'E' || eh[2] != 'L' || eh[3] != 'F' || eh[4] != 2) { old_close(fd); return; }
    unsigned long shoff;
    unsigned short shentsz, shnum, shstr;
    memcpy(&shoff, eh + 40, 8);
    memcpy(&shentsz, eh + 58, 2);
    memcpy(&shnum, eh + 60, 2);
    memcpy(&shstr, eh + 62, 2);
    if (shentsz != 64 || shnum == 0 || shnum > 64 || shstr >= shnum) { old_close(fd); return; }
    lseek(fd, (off_t)shoff, SEEK_SET);
    if (readFull(fd, sh_, shnum * 64) != shnum * 64) { old_close(fd); return; }
    unsigned char *sn = sh_ + (unsigned long)shstr * 64;
    unsigned long sbo, sbs;
    memcpy(&sbo, sn + 24, 8);
    memcpy(&sbs, sn + 32, 8);
    if (sbs == 0 || sbs > 8192) { old_close(fd); return; }
    lseek(fd, (off_t)sbo, SEEK_SET);
    if (readFull(fd, (unsigned char *)shst_, (int)sbs) != (int)sbs) { old_close(fd); return; }
    unsigned long symoff = 0, symsz = 0, syment = 24, stroff = 0, strsz = 0;
    for (unsigned i = 0; i < shnum; i++) {
        unsigned char *s = sh_ + (unsigned long)i * 64;
        unsigned type;
        unsigned nm;
        unsigned long off, sz, esz;
        memcpy(&nm, s, 4);
        memcpy(&type, s + 4, 4);
        memcpy(&off, s + 24, 8);
        memcpy(&sz, s + 32, 8);
        memcpy(&esz, s + 56, 8);
        const char *sname = nm < sbs ? shst_ + nm : "";
        if (type == 11) { symoff = off; symsz = sz; if (esz) syment = esz; }
        else if (type == 3 && !strcmp(sname, ".dynstr")) { stroff = off; strsz = sz; }
    }
    if (!symoff || !stroff || !strsz || strsz > 262144) { old_close(fd); return; }
    lseek(fd, (off_t)stroff, SEEK_SET);
    if (readFull(fd, (unsigned char *)dst_, (int)strsz) != (int)strsz) { old_close(fd); return; }
    lseek(fd, (off_t)symoff, SEEK_SET);
    unsigned long count = symsz / syment;
    if (count > 8192) count = 8192;
    for (unsigned long k = 0; k < count && asym_n < 2048; k++) {
        unsigned char en[32];
        int want = syment > 32 ? 32 : (int)syment;
        if (readFull(fd, en, want) != want) break;
        unsigned nm;
        unsigned char info;
        unsigned short shndx;
        unsigned long val;
        memcpy(&nm, en, 4);
        info = en[4];
        memcpy(&shndx, en + 6, 2);
        memcpy(&val, en + 8, 8);
        if ((info & 15) != 2 || shndx == 0 || val == 0) continue;
        if (nm >= strsz) continue;
        const char *sname = dst_ + nm;
        int l = 0;
        while (l < 63 && sname[l]) { asym_[asym_n].name[l] = sname[l]; l++; }
        asym_[asym_n].name[l] = 0;
        asym_[asym_n].a = val;
        asym_n++;
    }
    old_close(fd);
    if (!asym_n) return;
    qsort(asym_, (size_t)asym_n, sizeof(asym_[0]), cmpSym);
    unsigned long bias = 0;
    for (int i = 0; anogs_syms[i]; i++) {
        void *r = old_dlsym(RTLD_DEFAULT, anogs_syms[i]);
        if (!r) continue;
        for (int k = 0; k < asym_n; k++) {
            if (!strcmp(asym_[k].name, anogs_syms[i])) { bias = (unsigned long)r - asym_[k].a; break; }
        }
        if (bias) break;
    }
    if (!bias && anogs_s) bias = anogs_s;
    if (bias) {
        for (int k = 0; k < asym_n; k++) asym_[k].a += bias;
    }
}
static void setupAnogs(void) {
    refreshMaps();
    for (int j = 0; j < maps_n; j++) {
        if (strstr(maps_[j].name, "anogs")) { loadAnogsSyms(maps_[j].name); break; }
    }
}
static void modTag(unsigned long a, char *out, size_t outn) {
    if (!out || outn < 8) return;
    out[0] = 0;
    if (a < 4096) return;
    const char *lib = NULL;
    for (int j = 0; j < maps_n; j++) {
        if (a >= maps_[j].s && a < maps_[j].e) { lib = baseName(maps_[j].name); break; }
    }
    if (!lib) return;
    if (anogs_s && a >= anogs_s && a < anogs_e) {
        int lo = 0, hi = asym_n - 1, best = -1;
        while (lo <= hi) {
            int m = (lo + hi) / 2;
            if (asym_[m].a <= a) { best = m; lo = m + 1; } else hi = m - 1;
        }
        if (best >= 0) snprintf(out, outn, "%s!%s+0x%lx", lib, asym_[best].name, a - asym_[best].a);
        else snprintf(out, outn, "%s!?+0x%lx", lib, a - anogs_s);
        return;
    }
    snprintf(out, outn, "%s", lib);
}
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wframe-address"
static __attribute__((noinline)) void attrTag(char *out, size_t outn) {
    if (!out || outn < 8) return;
    out[0] = 0;
    if (in_log) return;
    in_log = 1;
    void *pcs[6];
    pcs[0] = __builtin_return_address(0);
    pcs[1] = __builtin_return_address(1);
    pcs[2] = __builtin_return_address(2);
    pcs[3] = __builtin_return_address(3);
    pcs[4] = __builtin_return_address(4);
    pcs[5] = __builtin_return_address(5);
    for (int i = 0; i < 6; i++) {
        unsigned long a = (unsigned long)pcs[i];
        char mb[160];
        modTag(a, mb, sizeof(mb));
        if (!mb[0]) continue;
        if (strstr(mb, "SignatureKiller")) continue;
        if (!strncmp(mb, "libc.so", 7) || !strncmp(mb, "libm.so", 7) || !strncmp(mb, "libart", 6) || !strncmp(mb, "linker", 6)) continue;
        if (anogs_s && a >= anogs_s && a < anogs_e) snprintf(out, outn, " anogs=%s", mb);
        else snprintf(out, outn, " via=%s", mb);
        break;
    }
    in_log = 0;
}
#pragma GCC diagnostic pop


static void dumpAnogsSegs(void) {
    if (!old_fopen) return;
    FILE *f = old_fopen("/proc/self/maps", "r");
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, "anogs")) {
            size_t n = strlen(line);
            if (n && line[n - 1] == '\n') line[n - 1] = 0;
            char msg[640];
            snprintf(msg, sizeof(msg), "anogs_seg=%s", line);
            LOGE("%s", msg);
            file_append(msg);
        }
    }
    fclose(f);
}

FILE *(*old_fopen)(const char *, const char *);

static void file_append(const char *line) {
    if (!old_fopen) return;
    FILE *f = old_fopen("/sdcard/Download/ffk_native.txt", "a");
    if (!f) return;
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    long long ms = (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
    fprintf(f, "t=%lld %s\n", ms, line);
    fclose(f);
}

static void nlog(const char *kind, const char *path) {
    char buf[512];
    snprintf(buf, sizeof(buf), "%s %s", kind, path ? path : "NULL");
    LOGE("%s", buf);
    file_append(buf);
}

static unsigned pkt_n = 0;
static void pktlog(const char *dir, int fd, const char *peer, long n,
        const unsigned char *data, int withHex) {
    if ((++pkt_n % 2000) == 0) refreshMaps();
    char hx[33];
    char msg[416];
    char at[128];
    at[0] = 0;
    if (withHex && data && n > 0) hex16(data, n, hx);
    else hx[0] = 0;
    attrTag(at, sizeof(at));
    snprintf(msg, sizeof(msg), "%s fd=%d %s n=%ld hx=%s%s",
        dir, fd, (peer && peer[0]) ? peer : "?", n, hx, at);
    LOGE("%s", msg);
    file_append(msg);
}

static int sockfmt(const struct sockaddr *sa, socklen_t sl, char *out, size_t outn) {
    if (!sa || !out || outn < 8) return 0;
    if (sa->sa_family == AF_INET && sl >= (socklen_t)sizeof(struct sockaddr_in)) {
        const struct sockaddr_in *a = (const struct sockaddr_in *)sa;
        const unsigned char *b = (const unsigned char *)&a->sin_addr.s_addr;
        snprintf(out, outn, "%d.%d.%d.%d:%d",
            b[0], b[1], b[2], b[3], (int)ntohs(a->sin_port));
        return 1;
    }
    if (sa->sa_family == AF_INET6 && sl >= (socklen_t)sizeof(struct sockaddr_in6)) {
        const struct sockaddr_in6 *a = (const struct sockaddr_in6 *)sa;
        const unsigned char *b = a->sin6_addr.s6_addr;
        snprintf(out, outn, "[%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x]:%d",
            b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7],
            b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15],
            (int)ntohs(a->sin6_port));
        return 1;
    }
    return 0;
}

static int selfnoise(const unsigned char *d, long n) {
    if (!d || n <= 0) return 0;
    long m = n > 128 ? 128 : n;
    static const char *marks[] = {"FFKX", "FFKN", "pkt ", "close fd=",
        "socket fd=", "connect ", "sendto ", "sendmsg ", "dns ", "dlopen"};
    for (int k = 0; k < 10; k++) {
        const char *mk = marks[k];
        size_t ml = strlen(mk);
        for (long i = 0; i + (long)ml <= m; i++) {
            if (memcmp(d + i, mk, ml) == 0) return 1;
        }
    }
    return 0;
}

int (*old_open)(const char *, int, mode_t);
static int openImpl(const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_open(repPath__, flags, mode);
    if (interesting(pathname)) nlog("open", pathname);
    return old_open(pathname, flags, mode);
}

int (*old_open64)(const char *, int, mode_t);
static int open64Impl(const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_open64(repPath__, flags, mode);
    if (interesting(pathname)) nlog("open64", pathname);
    return old_open64(pathname, flags, mode);
}

int (*old_openat)(int, const char *, int, mode_t);
static int openatImpl(int fd, const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_openat(fd, repPath__, flags, mode);
    if (interesting(pathname)) nlog("openat", pathname);
    return old_openat(fd, pathname, flags, mode);
}

int (*old_openat64)(int, const char *, int, mode_t);
static int openat64Impl(int fd, const char *pathname, int flags, mode_t mode) {
    if (pathname && apkPath__ && repPath__ && strcmp(pathname, apkPath__) == 0)
        return old_openat64(fd, repPath__, flags, mode);
    if (interesting(pathname)) nlog("openat64", pathname);
    return old_openat64(fd, pathname, flags, mode);
}

int (*old_access)(const char *, int);
static int accessImpl(const char *pathname, int mode_) {
    if (interesting(pathname)) nlog("access", pathname);
    return old_access(pathname, mode_);
}

static FILE *fopenImpl(const char *pathname, const char *mode_) {
    if (interesting(pathname)) nlog("fopen", pathname);
    return old_fopen(pathname, mode_);
}

int (*old_stat)(const char *, struct stat *);
static int statImpl(const char *pathname, struct stat *buf) {
    if (interesting(pathname)) nlog("stat", pathname);
    return old_stat(pathname, buf);
}

int (*old_stat64)(const char *, void *);
static int stat64Impl(const char *pathname, void *buf) {
    if (interesting(pathname)) nlog("stat64", pathname);
    return old_stat64(pathname, buf);
}

int (*old_lstat)(const char *, struct stat *);
static int lstatImpl(const char *pathname, struct stat *buf) {
    if (interesting(pathname)) nlog("lstat", pathname);
    return old_lstat(pathname, buf);
}

int (*old_lstat64)(const char *, void *);
static int lstat64Impl(const char *pathname, void *buf) {
    if (interesting(pathname)) nlog("lstat64", pathname);
    return old_lstat64(pathname, buf);
}

int (*old_fstatat)(int, const char *, struct stat *, int);
static int fstatatImpl(int fd, const char *pathname, struct stat *buf, int flag) {
    if (interesting(pathname)) nlog("fstatat", pathname);
    return old_fstatat(fd, pathname, buf, flag);
}

int (*old_fstatat64)(int, const char *, void *, int);
static int fstatat64Impl(int fd, const char *pathname, void *buf, int flag) {
    if (interesting(pathname)) nlog("fstatat64", pathname);
    return old_fstatat64(fd, pathname, buf, flag);
}

int (*old_unlink)(const char *);
static int unlinkImpl(const char *pathname) {
    if (interesting(pathname)) nlog("unlink", pathname);
    return old_unlink(pathname);
}

int (*old_unlinkat)(int, const char *, int);
static int unlinkatImpl(int fd, const char *pathname, int flag) {
    if (interesting(pathname)) nlog("unlinkat", pathname);
    return old_unlinkat(fd, pathname, flag);
}

int (*old_rename)(const char *, const char *);
static int renameImpl(const char *oldp, const char *newp) {
    if (interesting(oldp) || interesting(newp)) {
        char buf[512];
        snprintf(buf, sizeof(buf), "rename %s -> %s", oldp ? oldp : "NULL", newp ? newp : "NULL");
        LOGE("%s", buf);
        file_append(buf);
    }
    return old_rename(oldp, newp);
}

int (*old_mkdir)(const char *, mode_t);
static int mkdirImpl(const char *pathname, mode_t mode) {
    if (interesting(pathname)) nlog("mkdir", pathname);
    return old_mkdir(pathname, mode);
}

static void dumpAnogsApi(void) {
    if (!old_dlsym || in_log) return;
    in_log = 1;
    for (int i = 0; anogs_syms[i]; i++) {
        void *a = old_dlsym(RTLD_DEFAULT, anogs_syms[i]);
        if (a) {
            char buf[256];
            snprintf(buf, sizeof(buf), "anogs_api %s=%p", anogs_syms[i], a);
            LOGE("%s", buf);
            file_append(buf);
        }
    }
    in_log = 0;
}
void *(*old_dlopen)(const char *, int);
static void *dlopenImpl(const char *filename, int flags) {
    nlog("dlopen", filename ? filename : "NULL");
    if (filename && strstr(filename, "anogs")) {
        dumpAnogsSegs();
        dumpAnogsApi();
        setupAnogs();
    }
    return old_dlopen(filename, flags);
}

void *(*old_android_dlopen_ext)(const char *, int, const void *);
static void *android_dlopen_extImpl(const char *filename, int flags, const void *extinfo) {
    (void)extinfo;
    nlog("dlopen_ext", filename ? filename : "NULL");
    if (filename && strstr(filename, "anogs")) {
        dumpAnogsSegs();
        dumpAnogsApi();
        setupAnogs();
    }
    return old_android_dlopen_ext(filename, flags, extinfo);
}

int (*old_socket)(int, int, int);
static int socketImpl(int domain, int type, int proto) {
    int fd = old_socket(domain, type, proto);
    if (fd >= 0) {
        trackAdd(fd);
        char buf[80];
        snprintf(buf, sizeof(buf), "socket fd=%d dom=%d type=%d", fd, domain, type);
        LOGE("%s", buf);
        file_append(buf);
    }
    return fd;
}

int (*old_close)(int);
static int closeImpl(int fd) {
    int r = old_close(fd);
    if (trackHas(fd)) {
        char buf[160];
        snprintf(buf, sizeof(buf), "close fd=%d pkts=%u peer=%s",
            fd, sockcnt[fd], sockpeer[fd][0] ? sockpeer[fd] : "?");
        LOGE("%s", buf);
        file_append(buf);
        trackDel(fd);
    }
    return r;
}

int (*old_connect)(int, const struct sockaddr *, socklen_t);
static int connectImpl(int fd, const struct sockaddr *addr, socklen_t len) {
    char peer[96];
    if (sockfmt(addr, len, peer, sizeof(peer))) {
        char buf[224];
        snprintf(buf, sizeof(buf), "connect fd=%d %s", fd, peer);
        LOGE("%s", buf);
        file_append(buf);
        trackPeer(fd, peer);
    }
    return old_connect(fd, addr, len);
}

ssize_t (*old_sendto)(int, const void *, size_t, int, const struct sockaddr *, socklen_t);
static ssize_t sendtoImpl(int fd, const void *buf_, size_t len, int flags,
        const struct sockaddr *addr, socklen_t alen) {
    char peer[96];
    if (sockfmt(addr, alen, peer, sizeof(peer))) {
        trackPeer(fd, peer);
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)len))
            pktlog("pkt out", fd, peer, (long)len, (const unsigned char *)buf_, c <= 30);
    } else if (trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)len))
            pktlog("pkt out", fd, sockpeer[fd], (long)len, (const unsigned char *)buf_, c <= 30);
    }
    return old_sendto(fd, buf_, len, flags, addr, alen);
}

ssize_t (*old_sendmsg)(int, const struct msghdr *, int);
static ssize_t sendmsgImpl(int fd, const struct msghdr *msg, int flags) {
    if (trackHas(fd) || (msg && msg->msg_name)) {
        size_t total = 0;
        if (msg) {
            size_t n = msg->msg_iovlen > 8 ? 8 : msg->msg_iovlen;
            if (msg->msg_iov) for (size_t i = 0; i < n; i++) total += msg->msg_iov[i].iov_len;
        }
        const char *peer = sockpeer[fd];
        char tmp[96];
        if (msg && msg->msg_name &&
                sockfmt((const struct sockaddr *)msg->msg_name, msg->msg_namelen, tmp, sizeof(tmp))) {
            trackPeer(fd, tmp);
            peer = tmp;
        }
        unsigned c = trackBump(fd);
        if (c <= 30 || c % 50 == 0)
            pktlog("pkt out", fd, peer, (long)total, NULL, 0);
    }
    return old_sendmsg(fd, msg, flags);
}

ssize_t (*old_send)(int, const void *, size_t, int);
static ssize_t sendImpl(int fd, const void *buf_, size_t len, int flags) {
    if (trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)len))
            pktlog("pkt out", fd, sockpeer[fd], (long)len, (const unsigned char *)buf_, c <= 30);
    }
    return old_send(fd, buf_, len, flags);
}

ssize_t (*old_recv)(int, void *, size_t, int);
static ssize_t recvImpl(int fd, void *buf_, size_t len, int flags) {
    ssize_t r = old_recv(fd, buf_, len, flags);
    if (r > 0 && trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)r))
            pktlog("pkt in", fd, sockpeer[fd], (long)r, (const unsigned char *)buf_, c <= 30);
    }
    return r;
}

ssize_t (*old_recvfrom)(int, void *, size_t, int, struct sockaddr *, socklen_t *);
static ssize_t recvfromImpl(int fd, void *buf_, size_t len, int flags,
        struct sockaddr *addr, socklen_t *alen) {
    ssize_t r = old_recvfrom(fd, buf_, len, flags, addr, alen);
    if (r > 0 && trackHas(fd)) {
        char tmp[96];
        const char *peer = sockpeer[fd];
        if (addr && alen && sockfmt(addr, *alen, tmp, sizeof(tmp)))
            peer = tmp;
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)r))
            pktlog("pkt in", fd, peer, (long)r, (const unsigned char *)buf_, c <= 30);
    }
    return r;
}

ssize_t (*old_recvmsg)(int, struct msghdr *, int);
static ssize_t recvmsgImpl(int fd, struct msghdr *msg, int flags) {
    ssize_t r = old_recvmsg(fd, msg, flags);
    if (r > 0 && trackHas(fd)) {
        const char *peer = sockpeer[fd];
        char tmp[96];
        if (msg && msg->msg_name &&
                sockfmt((const struct sockaddr *)msg->msg_name, msg->msg_namelen, tmp, sizeof(tmp)))
            peer = tmp;
        const unsigned char *sample = NULL;
        if (msg && msg->msg_iovlen > 0 && msg->msg_iov) sample = (const unsigned char *)msg->msg_iov[0].iov_base;
        unsigned c = trackBump(fd);
        if (c <= 30 || c % 50 == 0)
            pktlog("pkt in", fd, peer, (long)r, sample, c <= 30);
    }
    return r;
}

ssize_t (*old_read)(int, void *, size_t);
static ssize_t readImpl(int fd, void *buf_, size_t n) {
    ssize_t r = old_read(fd, buf_, n);
    if (r > 0 && trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)r))
            pktlog("pkt in", fd, sockpeer[fd], (long)r, (const unsigned char *)buf_, c <= 30);
    }
    return r;
}

ssize_t (*old_write)(int, const void *, size_t);
static ssize_t writeImpl(int fd, const void *buf_, size_t n) {
    if (trackHas(fd)) {
        unsigned c = trackBump(fd);
        if ((c <= 30 || c % 50 == 0) && !selfnoise((const unsigned char *)buf_, (long)n))
            pktlog("pkt out", fd, sockpeer[fd], (long)n, (const unsigned char *)buf_, c <= 30);
    }
    return old_write(fd, buf_, n);
}

int (*old_getaddrinfo)(const char *, const char *, const struct addrinfo *, struct addrinfo **);
static int getaddrinfoImpl(const char *node, const char *service,
        const struct addrinfo *hints, struct addrinfo **res) {
    if (node) {
        char buf[448];
        char at[128];
        at[0] = 0;
        attrTag(at, sizeof(at));
        snprintf(buf, sizeof(buf), "dns %s%s", node, at);
        LOGE("%s", buf);
        file_append(buf);
    }
    return old_getaddrinfo(node, service, hints, res);
}

static void *dlsymImpl(void *handle, const char *sym) {
    if (dlsymInteresting(sym) && !in_log) nlog("dlsym", sym);
    void *r = old_dlsym(handle, sym);
    if (r && dlsymInteresting(sym) && !in_log) {
        char mb[160];
        modTag((unsigned long)r, mb, sizeof(mb));
        char buf[448];
        snprintf(buf, sizeof(buf), "dlsym_ret %s -> %p %s", sym, r, mb[0] ? mb : "?");
        LOGE("%s", buf);
        file_append(buf);
    }
    return r;
}

int (*old_pthread_create)(void *, const void *, void *(*)(void *), void *);
static int pthread_createImpl(void *t, const void *a, void *(*fn)(void *), void *arg) {
    char buf[320];
    char mb[192];
    mb[0] = 0;
    if (fn) {
        char tmp[160];
        modTag((unsigned long)fn, tmp, sizeof(tmp));
        if (tmp[0]) snprintf(mb, sizeof(mb), " mod=%s", tmp);
    }
    snprintf(buf, sizeof(buf), "thread start=%p%s", (void *)fn, mb);
    LOGE("%s", buf);
    file_append(buf);
    return old_pthread_create(t, a, fn, arg);
}

void (*old_exit)(int);
static void exitImpl(int code) {
    char buf[320];
    char at[128];
    at[0] = 0;
    attrTag(at, sizeof(at));
    snprintf(buf, sizeof(buf), "proc_exit exit code=%d%s", code, at);
    LOGE("%s", buf);
    file_append(buf);
    old_exit(code);
}
void (*old__exit)(int);
static void _exitImpl(int code) {
    char buf[160];
    snprintf(buf, sizeof(buf), "proc_exit _exit code=%d", code);
    LOGE("%s", buf);
    old__exit(code);
}
void (*old_abort)(void);
static void abortImpl(void) {
    LOGE("proc_exit abort");
    file_append("proc_exit abort");
    old_abort();
}
int (*old_kill)(pid_t, int);
static int killImpl(pid_t pid, int sig) {
    char buf[320];
    char at[128];
    at[0] = 0;
    attrTag(at, sizeof(at));
    snprintf(buf, sizeof(buf), "kill pid=%d sig=%d%s", (int)pid, sig, at);
    LOGE("%s", buf);
    file_append(buf);
    return old_kill(pid, sig);
}
static void reg_all(void) {
    xhook_register(".*\\.so$", "openat64", (void *)openat64Impl, (void **)&old_openat64);
    xhook_register(".*\\.so$", "openat", (void *)openatImpl, (void **)&old_openat);
    xhook_register(".*\\.so$", "open64", (void *)open64Impl, (void **)&old_open64);
    xhook_register(".*\\.so$", "open", (void *)openImpl, (void **)&old_open);
    xhook_register(".*\\.so$", "access", (void *)accessImpl, (void **)&old_access);
    xhook_register(".*\\.so$", "fopen", (void *)fopenImpl, (void **)&old_fopen);
    xhook_register(".*\\.so$", "stat", (void *)statImpl, (void **)&old_stat);
    xhook_register(".*\\.so$", "stat64", (void *)stat64Impl, (void **)&old_stat64);
    xhook_register(".*\\.so$", "lstat", (void *)lstatImpl, (void **)&old_lstat);
    xhook_register(".*\\.so$", "lstat64", (void *)lstat64Impl, (void **)&old_lstat64);
    xhook_register(".*\\.so$", "fstatat", (void *)fstatatImpl, (void **)&old_fstatat);
    xhook_register(".*\\.so$", "fstatat64", (void *)fstatat64Impl, (void **)&old_fstatat64);
    xhook_register(".*\\.so$", "unlink", (void *)unlinkImpl, (void **)&old_unlink);
    xhook_register(".*\\.so$", "unlinkat", (void *)unlinkatImpl, (void **)&old_unlinkat);
    xhook_register(".*\\.so$", "rename", (void *)renameImpl, (void **)&old_rename);
    xhook_register(".*\\.so$", "mkdir", (void *)mkdirImpl, (void **)&old_mkdir);
    xhook_register(".*\\.so$", "dlopen", (void *)dlopenImpl, (void **)&old_dlopen);
    xhook_register(".*\\.so$", "android_dlopen_ext", (void *)android_dlopen_extImpl, (void **)&old_android_dlopen_ext);
    xhook_register(".*\\.so$", "socket", (void *)socketImpl, (void **)&old_socket);
    xhook_register(".*\\.so$", "close", (void *)closeImpl, (void **)&old_close);
    xhook_register(".*\\.so$", "connect", (void *)connectImpl, (void **)&old_connect);
    xhook_register(".*\\.so$", "sendto", (void *)sendtoImpl, (void **)&old_sendto);
    xhook_register(".*\\.so$", "sendmsg", (void *)sendmsgImpl, (void **)&old_sendmsg);
    xhook_register(".*\\.so$", "send", (void *)sendImpl, (void **)&old_send);
    xhook_register(".*\\.so$", "recv", (void *)recvImpl, (void **)&old_recv);
    xhook_register(".*\\.so$", "recvfrom", (void *)recvfromImpl, (void **)&old_recvfrom);
    xhook_register(".*\\.so$", "recvmsg", (void *)recvmsgImpl, (void **)&old_recvmsg);
    xhook_register(".*\\.so$", "read", (void *)readImpl, (void **)&old_read);
    xhook_register(".*\\.so$", "write", (void *)writeImpl, (void **)&old_write);
    xhook_register(".*\\.so$", "getaddrinfo", (void *)getaddrinfoImpl, (void **)&old_getaddrinfo);
    xhook_register(".*\\.so$", "dlsym", (void *)dlsymImpl, (void **)&old_dlsym);
    xhook_register(".*\\.so$", "pthread_create", (void *)pthread_createImpl, (void **)&old_pthread_create);
    xhook_register(".*\\.so$", "exit", (void *)exitImpl, (void **)&old_exit);
    xhook_register(".*\\.so$", "_exit", (void *)_exitImpl, (void **)&old__exit);
    xhook_register(".*\\.so$", "abort", (void *)abortImpl, (void **)&old_abort);
    xhook_register(".*\\.so$", "kill", (void *)killImpl, (void **)&old_kill);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)vm;
    (void)reserved;
    reg_all();
    xhook_refresh(0);
    LOGE("ffkn on");
    file_append("ffkn on");
    refreshMaps();
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_ff_killer_Killer_hookApkPath(JNIEnv *env, __attribute__((unused)) jclass clazz, jstring apkPath, jstring repPath) {
    apkPath__ = (*env)->GetStringUTFChars(env, apkPath, 0);
    repPath__ = (*env)->GetStringUTFChars(env, repPath, 0);
    LOGE("ffkn paths set");
    reg_all();
    xhook_refresh(0);
    refreshMaps();
}
